/**
 * 
 */
package ss.week6;

import java.util.Scanner;
/**
 * @author Zarimir
 * @version 3.0
 */
public class Hello {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("What is your name? >");
		Scanner in = new Scanner(System.in);
		String name = in.nextLine();
		
		while (!name.equals("")) {
			System.out.println("Hello " + name);
			System.out.print("What is your name? >");
			
			name = in.nextLine();
		}
	}

}
