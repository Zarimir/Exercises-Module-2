/**
 * 
 */
package ss.week6.voteMachine;

import java.util.List;
import java.util.Map;
import java.util.Observable;
import java.util.Scanner;

/**
 * @author Zarimir
 * @version 3.0
 */
public class VoteTUIView implements VoteView {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	// ------------------------  Instance Variables  ------------------------
	
	private VoteMachine controller;

	
	// ------------------------ Constructor ------------------------
	
	public VoteTUIView(VoteMachine machine) {
		assert machine != null;
		
		this.controller = machine;
	}
	
	// ------------------------ Queries ------------------------
	
	public List<String> getParties() {
		return this.controller.getParties();
	}
	
	public Map<String, Integer> getVotes() {
		return this.controller.getVotes();
	}
	
	// ------------------------ Commands ------------------------
	
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		System.out.println("A " + arg.toString() + " has been added.");
	}
	
	public void start() {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("What's your input?\n> ");
		while (true) {
			
			
			String c = keyboard.nextLine();
			//System.out.println(c);
			String[] upper = c.toUpperCase().split("\\s");
			String[] choice = c.split("\\s");
			if (upper[0].equals("VOTES")) {
				this.showVotes(this.getVotes());
			} else if (upper[0].equals("PARTIES")) {
				this.showParties(this.getParties());
			} else if (upper.length >= 3 && upper[0].equals("ADD") && upper[1].equals("PARTY")) {
				this.controller.addParty(choice[2]);
			} else if (upper.length > 1 && upper[0].equals("VOTE")) {
				this.controller.vote(choice[1]);
			} else if (upper[0].equals("EXIT")) {
				keyboard.close();
				break;
			} else if (upper[0].equals("HELP")) {
				System.out.println("NOT YET IMPLEMENTED");
			} else {
				System.out.println("Invalid Input, please try again...\n> ");
			}
			
		}
		keyboard.close();
	}
	
	public void showVotes(Map<String, Integer> map) {
		System.out.println(map);
	}
	public void showParties(List<String> list) {
		System.out.println(list);
	}
	public void showError(String s) {
		System.out.println(s);
	}

	
}
