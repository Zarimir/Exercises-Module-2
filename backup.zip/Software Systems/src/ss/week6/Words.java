/**
 * 
 */
package ss.week6;
import java.util.Scanner;

/**
 * @author Zarimir
 * @version 3.0
 */
public class Words {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner in = new Scanner(System.in);
		String sentence = in.nextLine();
		sentence = ("Line (or 'end'): The quick brown fox jumps over the lazy dog.");
		String[] words = sentence.split("\\s");
		String out = "";
		String end = "";
		int index = 0;
		for (int i = 0; i < words.length; i++) {
			end += words[i] + " ";
			if (words[i].contains("end")) {
				end += "end"; 
				index = i + 1;
				break;
			}
		}
		
		for (int i = index; i < words.length; i++) {
			out += "Word " + (i - index + 1) + ": " + words[i] + "\n";

		}
		out += end;
		System.out.println(out);
	}

}

