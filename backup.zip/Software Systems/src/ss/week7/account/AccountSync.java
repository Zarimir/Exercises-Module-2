/**
 * 
 */
package ss.week7.account;

/**
 * @author Zarimir
 * @version 3.0
 */
public class AccountSync {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double amount = 10;
		/*
			int freq = 10;
			Account acc = new Account();
			while (true) {
			Thread obj1 = new MyThread(amount, freq, acc, "A");
			Thread obj2 = new MyThread(-amount, freq, acc, "B");
			obj1.start();
			//System.out.println(acc.getBalance());
			obj2.start();
			//System.out.println(acc.getBalance());
			try {
				obj1.join();
				obj2.join();
			} catch (Exception e) {
				//System.out.println(e.getMessage());
			}
			double balance =acc.getBalance(); 
			System.out.println(balance);
			//break;
			if (balance != 0) {
				break;
			}
		
		}
		*/	
	}

	
}
