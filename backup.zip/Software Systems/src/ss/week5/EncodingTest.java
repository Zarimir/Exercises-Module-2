package ss.week5;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

/**
 * A simple class that experiments with the Hex encoding
 * of the Apache Commons Codec library.
 *
 */
public class EncodingTest {
    public static void main(String[] args) throws DecoderException {
        String input;
        String hex;
        //String hexHolder;
        //String inputHolder;
        //byte[] bytes;
    	
    	EncodingTest obj = new EncodingTest();
        // 5.11
        obj.prnt("5.11");
    	input = "Hello World";
        obj.prnt(input, false);
        
        input = "Hello Big World";
        obj.prnt(input, false);
        
        //5.12
        obj.prnt("5.12");
        hex = "4d6f64756c652032";
        obj.prnt(hex, false);
        
        //5.13
        //1
        obj.prnt("5.13.1");
        input = "Hello World";
        obj.prnt(input, true);
        
        //2
        obj.prnt("5.13.2");
        hex = "010203040506";
        obj.prnt(hex, true);;
        
        //3
        obj.prnt("5.13.3");
        input = "U29mdHdhcmUgU3lzdGVtcw==";
        obj.prnt(input, true);;
        
        //4
        System.out.println("5.13.4");
        for (int i = 1; i < 11; i++) {
        	input = "";
        	
        	for (int j = 0; j < i; j++) {
        		input += "a";
        	}
        	
        	obj.prnt(input, true);
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        /*
        // 5.11
        System.out.println("5.11");
    	input = "Hello World";
        
        System.out.println(Hex.encodeHexString(input.getBytes()));
        
        input = "Hello Big World";
        System.out.println(Hex.encodeHexString(input.getBytes()));
        
        //5.12
        System.out.println("5.12");
        hex = "4d6f64756c652032";
        bytes = hex.getBytes();
        hexHolder = new String(Hex.encodeHexString(bytes));
        System.out.println(hexHolder);
        
        //5.13
        //1
        System.out.println("5.13.1");
        input = "Hello World";
        bytes = input.getBytes();
        inputHolder = new String(Base64.encodeBase64(bytes));
        System.out.println(inputHolder);
        
        //2
        System.out.println("5.13.2");
        hex = "010203040506";
        bytes = hex.getBytes();
        hexHolder = new String(Base64.encodeBase64(bytes));
        System.out.println(hexHolder);
        
        //3
        System.out.println("5.13.3");
        input = "U29mdHdhcmUgU3lzdGVtcw==";
        bytes = input.getBytes();
        inputHolder = new String(Base64.encodeBase64(bytes));
        System.out.println(inputHolder);
        
        //4
        System.out.println("5.13.4");
        for (int i = 1; i < 11; i++) {
        	input = "";
        	
        	for (int j = 0; j < i; j++) {
        		input += "a";
        	}
        	
        	bytes = input.getBytes();
        }
        
        */
        
        
        /*
        Hex obj = new Hex();
        
        
        for (int i = 0; i < data.length; i++) {
        	System.out.print(obj.decodeHex(arg0)data[i]);
        }
        char[] encoded = Hex.encodeHex(data);
        for (int i = 0; i < encoded.length; i++) {
        	System.out.print(encoded[i]);
        }
        //System.out.println(obj.decodeHex(data));
        */
    }
    
    private void prnt(String input, boolean encoder) {
    	if (encoder) {
    		System.out.println(new String(Base64.encodeBase64(input.getBytes())));
    	} else {
    		System.out.println(Hex.encodeHexString(input.getBytes()));
    	}
    }
    
    private void prnt(String input) {
    	System.out.println(input);
    }
}
