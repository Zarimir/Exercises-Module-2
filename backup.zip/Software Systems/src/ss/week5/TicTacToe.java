package ss.week5;

/**
 * Executable class for the game Tic Tac Toe. The game can be played against the
 * computer. Lab assignment Module 2
 * 
 * @author Theo Ruys
 * @version $Revision: 1.4 $
 */
public class TicTacToe {
    public static void main(String[] args) {
        // TODO: implement, see P-4.21
    	Player[] players;
    	int min = args.length;
    	if (min > 2) {
    		min = 2;
    	}
    	players = new Player[2];
    	///*
    	for (int i = 0; i < args.length; i++) {
    		if (args[i].equals("-N")) {
    			players[1] = new ComputerPlayer(Mark.XX);
    		}
    		if (args[i].equals("-S")) {
    			players[0] = new ComputerPlayer(new SmartStrategy(), Mark.OO);
    		}
    	}
    	/*
    	for (int i = 0; i < args.length; i++) {
    		players[i] = new HumanPlayer(args[i], Mark.XX);
    	}
    	*/
    	
    	//*/
    	/*
    	for (int i = 0; i < min; i++) {
    		players[i] = new HumanPlayer(args[i], Mark.XX);
    	}
    	for (int i = min; i < 2; i++) {
    		players[i] = new ComputerPlayer(Mark.OO);
    	}
    	*/
    	//players[0] = new ComputerPlayer(Mark.XX);
    	//players[1] = new ComputerPlayer(Mark.OO);
    	//*/
    	Game game = new Game(players[0], players[1]);
    	game.start();
    }
}
