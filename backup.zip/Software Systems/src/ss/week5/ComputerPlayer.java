/**
 * 
 */
package ss.week5;

/**
 * @author Zarry
 *
 */
public class ComputerPlayer extends Player {
	
	Strategy strategy;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public ComputerPlayer(Mark mark) {
        this(new NaiveStrategy(), mark);
    }
	
	public ComputerPlayer(Strategy str, Mark mark) {
        super(str.getName(), mark);
        this.strategy = str;
    }
	
	public Strategy getStrategy() {
		return this.strategy;
	}
	
	public int determineMove(Board b) {
		return this.getStrategy().determineMove(b, this.getMark());
	}
	
	public int determineMove(Board b, Strategy str) {
		this.strategy = str;
		return this.determineMove(b);
	}
}
