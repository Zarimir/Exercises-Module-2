/**
 * 
 */
package home.exercises;
import java.util.*;
/**
 * @author Zarry
 *
 */
public class ArrayListExrc {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<String>();
		System.out.println("Hi");
	}

}
