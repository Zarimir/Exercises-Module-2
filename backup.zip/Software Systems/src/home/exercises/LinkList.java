package home.exercises;

public class LinkList {
	
	public Link firstLink;
	
	LinkList() {
		this.firstLink = null;
	}
	
	public boolean isEmpty() {
		return firstLink == null;
	}
	
	public void insertLink(String bookName, int millionsSold) {
		Link newLink = new Link(bookName, millionsSold);
		
		newLink.next = firstLink;
		
		firstLink = newLink;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
