package ss.week5;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.*;

public class MapUtil {
    //@ ensures map == null ==> \result == false;
	/*@pure */ public static <K, V> boolean isOneOnOne(Map<K, V> map) {
        // TODO: implement, see exercise P-5.1
		if (map != null) {
	    	List<V> list = new ArrayList<V>();
	    	for (Map.Entry<K, V> entry : map.entrySet()) {
	    		list.add(entry.getValue());
	    	}
	    	Set<V> duplicateLess = new HashSet<V>(list);
	        return duplicateLess.size() == list.size();
		} else {
			return false;
		}
    }
	
	//@ ensures map == null ==> \result == false;
    public static <K, V> 
           boolean isSurjectiveOnRange(Map<K, V> map, Set<V> range) {
        // TODO: implement, see exercise P-5.2
    	if (map != null) {
	    	List<V> list = new ArrayList<V>();
	    	for (Map.Entry<K, V> entry : map.entrySet()) {
	    		list.add(entry.getValue());
	    	}
	    	
	    	for (Iterator<V> it = range.iterator(); it.hasNext();) {
	    		V val = it.next();
	    		if (!list.contains(val)) {
	    			return false;
	    		}
	    	}
	    	return true;
		} else {
			return false;
		}
    }
    
    //@ ensures this.
    //@ ensures map == null ==> \result == null;
    public static <K, V> Map<V, Set<K>> inverse(Map<K, V> map) {
        // TODO: implement, see exercise P-5.3
    	Map<V, Set<K>> result = new HashMap<V, Set<K>>();
    	
    	Set<K> keys;
    	for (V value : map.values()) {
    		keys = new HashSet<K>();
    		for (K key : map.keySet()) {
    			if (map.get(key).equals(value)) {
    				keys.add(key);
    			}
    		}
    		result.put(value, (Set<K>) keys);
    	}
    	
        return result;
	}
    
    //@ ensures map == null ==> \result == null;
	public static <K, V> Map<V, K> inverseBijection(Map<K, V> map) {
        // TODO: implement, see exercise P-5.3
		if (map == null) {
			return null;
		}
		Set<V> range = new HashSet<V>();
		for (V value : map.values()) {
			range.add(value);
		}
		if (MapUtil.isOneOnOne(map) && MapUtil.isSurjectiveOnRange(map, (HashSet<V>) map.values())) {
			Map<V, K> result = new HashMap<V, K>();
			for (Map.Entry<K, V> entry : map.entrySet()) {
				result.put(entry.getValue(), entry.getKey());
			}
	        return result;
		} else {
			return null;
		}
	}
	
	//@ ensures f == null || g == null ==> \result == false;;
	public static <K, V, W> boolean compatible(Map<K, V> f, Map<V, W> g) {
        // TODO: implement, see exercise P-5.4
		Set<V> keysG = g.keySet();
		for (V val : f.values()) {
			if (!keysG.contains(val)) {
				return false;
			}
		}
        return true;
	}
	
	//@ ensures this.compatible(f, g) == false ==> \result == null;
	///*
	public static <K, V, W> Map<K, W> compose(Map<K, V> f, Map<V, W> g) {
        // TODO: implement, see exercise P-5.4
		if (!compatible(f, g)) {
			return null;
		} else {
			/*
			Map<K, W> result = new HashMap<K, W>();
			for (Map.Entry<K, V> e : f.entrySet()) {
				result.put(e.getKey(), g.get(e.getValue()));
			}
			*/
			/*
			DualMap<K, V, W> result = new DualMap<K, V, W>();
			for (Map.Entry<K, V> e : f.entrySet()) {
				result.put(e.getKey(), e.getValue(), g.get(e.getValue()));
			}
			*/
			
		}
		//return result;
		return null;
	}
	/*
	public static <K, V, W> Map<K, W> compose(Map<K, V> f, Map<V, W> g) {
        // TODO: implement, see exercise P-5.4
		if (!compatible(f, g)) {
			return null;
		} else {
			Table<K, V, W> result = new HashTable<K, V, W>();
			for (Entry<K, V> entry : f.entry)
		}
		return null;
	}
	*/
	//*/
}
