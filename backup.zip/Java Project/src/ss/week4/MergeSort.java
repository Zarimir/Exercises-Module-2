package ss.week4;

import java.util.*;

public class MergeSort {
	public static <Elem extends Comparable<Elem>> void main(String[] args) {
		//System.out.println();
		MergeSort obj = new MergeSort();
		List<Elem> list = new ArrayList<Elem>();
		MergeSort.putting(list, 1);
		MergeSort.putting(list, 2);
		MergeSort.putting(list, 3);
		//MergeSort.printList(list);
		MergeSort.printList(MergeSort.cutting(list).get(0));
		MergeSort.printList(MergeSort.cutting(list).get(1));
	}
	
	
	public static <Elem extends Comparable<Elem>>
    	void mergesort(List<Elem> list) {
		list = MergeSort.sort(list);
	}
	
	public static <Elem extends Comparable<Elem>>
           List<Elem> sort(List<Elem> list) {
    	// TODO: implement, see exercise P-4.16
		if (list.size() == 0 || list.size() == 1) {
			return list;
		} else {
			List<Elem> result = new ArrayList<Elem>();
			List<Elem> fst = MergeSort.cutting(list).get(0);
			List<Elem> snd = MergeSort.cutting(list).get(1);
			int fi = 0;
			int si = 0;
			while (fi < fst.size() && si < snd.size()) {
				if (fst.get(fi).compareTo(snd.get(si)) < 0) {
					result.add(fst.get(fi));
					fi++;
				} else {
					result.add(snd.get(si));
					si++;
				}
			}
			
			for (int i = fi; i < fst.size(); i++) {
				result.add(fst.get(i));
			}
			
			for (int i = si; i < snd.size(); i++) {
				result.add(snd.get(i));
			}
			return result;
		}
	}
	
	public static <Elem extends Comparable<Elem>> void putting(List<Elem> l, int a) {
		l.add((Elem) new Integer(a));
	}
	
	public static <Elem extends Comparable<Elem>> List<Elem> cut (List<Elem> list, int half) {
		List<Elem> result = new ArrayList<Elem>();
		if (half == 0) {
			int splitAt = list.size() / 2;
			for (int i = 0; i <= splitAt; i++) {
				result.add(list.get(i));
			}
		} else if (half == 1) {
			int splitAt = list.size() / 2;
			for (int i = splitAt + 1; i < list.size(); i++) {
				result.add(list.get(i));
			}
		}
		return result;
	}
	
	public static <Elem extends Comparable<Elem>> List<List<Elem>>
			cutting (List<Elem> list) {
		List<Elem> l1 = new ArrayList<Elem>();
		List<Elem> l2 = new ArrayList<Elem>();
		int splitAt = list.size() / 2;
		if (list.size() > 0) {
			for (int i = 0; i < splitAt; i++) {
				l1.add(list.get(i));
			}
		
			for (int i = splitAt; i < list.size(); i++) {
				l2.add(list.get(i));
			}
		}
		List<List<Elem>> result = new ArrayList<List<Elem>>();
		result.add(l1);
		result.add(l2);
		return result;
	}
	
	public static <Elem extends Comparable<Elem>> void printList (List<Elem> list) {
		for (Elem i : list) {
			System.out.print(i.toString());
		}
		System.out.println();
	}
}