/**
 * 
 */
package ss.week5;

import java.util.Map;

/**
 * @author Zarry
 *
 */
public interface IDualMap<K, W, V> {

	/**
	    * @return Unmodifiable version of underlying map1
	    */
	    Map<K, V> getMap1();

	    /**
	    * @return Unmodifiable version of underlying map2
	    */
	    Map<W, V> getMap2();

	    void put(K key1, W key2, V value);
}
