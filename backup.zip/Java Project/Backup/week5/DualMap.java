/**
 * 
 */
package ss.week5;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Zarry
 *
 */
public final class DualMap<K, V, W>
	implements IDualMap<K, V, W> {

	private final Map<K, W> map1 = new HashMap<K, W>();

    private final Map<V, W> map2 = new HashMap<V, W>();

    @Override
    public Map<K, W> getMap1() {
        return Collections.unmodifiableMap(map1);
    }

    @Override
    public Map<V, W> getMap2() {
        return Collections.unmodifiableMap(map2);
    }

    @Override
    public void put(K key1, V key2, W value) {
        map1.put(key1, value);
        map2.put(key2, value);
    }

}
