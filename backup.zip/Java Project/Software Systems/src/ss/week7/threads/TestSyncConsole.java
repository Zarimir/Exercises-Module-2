/**
 * 
 */
package ss.week7.threads;

import java.util.Scanner;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author Zarimir
 * @version 3.0
 */
public class TestSyncConsole extends Thread {
	private ReentrantLock lock;
	
	public static void main(String[] args) {
		Thread obj1 = new TestSyncConsole("Thread 1");
		Thread obj2 = new TestSyncConsole("Thread 2");
		Thread obj3 = new TestSyncConsole("Thread 3");
		obj1.start();
		obj2.start();
		obj3.start();
	}
	
	private String name;
	
	public TestSyncConsole(String n) {
		super(n);
		this.lock = new ReentrantLock();
	}
	
	public synchronized void run() {
		this.lock.lock();
		try {
			this.sum();
		} finally {
			this.lock.unlock();
		}
	}
	
	private synchronized void sum() {	
		Scanner in = new Scanner(System.in);
		//int num1 = Integer.parseInt(choice);
		//int num2 = Integer.parseInt(choice);
		//lock.lock();
		int num1 = SyncConsole.readInt(this.getName() + " num1: ");
		//System.out.println("Num1 is : " + num1);
		int num2 = SyncConsole.readInt(this.getName() + " num2: ");
		String s = this.getName() + " : " + num1 + " + " + num2 + " = " + (num1 + num2);
		SyncConsole.println(s);
		//lock.unlock();
		
	}
}
