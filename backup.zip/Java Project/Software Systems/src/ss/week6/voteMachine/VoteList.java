/**
 * 
 */
package ss.week6.voteMachine;

import java.util.HashMap;
import java.util.Map;
import java.util.Observable;

/**
 * @author Zarimir
 * @version 3.0
 */
public class VoteList extends Observable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VoteList obj = new VoteList();
		obj.addVote("zarry");
		obj.addVote("zarry");
		obj.addVote("Pesho");
		obj.addVote("Pesho");
		obj.addVote("Pesho");
		obj.it();
		
	}
	
	// ------------------------ Instance Variables ------------------------
	
	private Map<String, Integer> votes;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Constructor initializes new HashMap<String, Integer>().
	 */
	public VoteList() {
		this.votes = new HashMap<String, Integer>();
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Get the whole party/votes HashMap query.
	 * @return Map<String, Integer>
	 */
	public Map<String, Integer> getVotes() {
		return this.votes;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Adds a vote to a party.
	 * @param p String party
	 */
	public void addVote(String p) {
		
		if (this.votes.containsKey(p)) {
			Integer old = this.votes.get(p);
			this.votes.replace(p, old, new Integer(old.intValue() + 1));
		} else {
			this.votes.put(p, new Integer(1));
		}
		this.setChanged();
		this.notifyObservers("vote");
	}
	
	/**
	 * prints this.toString().
	 */
	public void it() {
		System.out.print(this);
	}
	
	/**
	 * toString() returns each entry in an "key : value" format.
	 */
	public String toString() {
		String result = "";
		for (Map.Entry<String, Integer> e : this.votes.entrySet()) {
			result += e.getKey() + " : " + e.getValue() + "\n";
		}
		
		return result;
	}
}
