package test;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] s = {"123", "5", "10s"};
		try {
			System.out.println(Integer.parseInt(s[0]) + Integer.parseInt(s[1]) + Integer.parseInt(s[2]));
		} catch (NumberFormatException e) {
			System.out.println("The game has experienced an error; the server has given coordinates which do not correspond to the local copy of the game");
		}
	}

}
