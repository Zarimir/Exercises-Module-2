package game.network;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.geometry.Coordinate;
import game.logic.Player;
import game.ui.NetworkUI;

/**
 * Handles the Network Player of the Game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class NetworkPlayer extends Player implements NetworkProtocol {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param handler the ClientHandler of this NetworkPlayer
	 * @param ready is a boolean denoting whether the Client has already chosen a valid point
	 */
	private ClientHandler handler;
	private Lock lock = new ReentrantLock();
	private Condition condition = lock.newCondition();
	private boolean ready = false;
	private static final int SECONDS_READY_CHECK = NetworkUI.SECONDS_READY_CHECK;
	//private status;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Constructs a Computer Player with a given strategy and a mark arguments.
	 * @param strategy of this ComputerPlayer
	 * @param mark of this ComputerPlayer
	 */
	public NetworkPlayer(ClientHandler handler) {
        super(handler.getClientName());
        this.handler = handler;
    }
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Returns the clientHandler of this networkPlayer.
	 * @return ClientHandler
	 */
	//@ ensures \result != null;
	public ClientHandler getHandler() {
		return this.handler;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Prompts client to make a move and waits for a response.
	 * @param board of the Game
	 */
	public void determinePoint() {
		lock.lock();
		//getHandler().requestMove();
		try {
			ready = false;
			Set<String> commands = ConcurrentHashMap.newKeySet();
			commands.add(MAKEMOVE);
			handler.requestCommands(commands);
			//handler.sendMessage(REQUESTMOVE);
			this.setChanged();
			this.notifyObservers(REQUESTMOVE);
			condition.await(SECONDS_READY_CHECK, TimeUnit.SECONDS);
			this.getHandler().unlockCommands();
			if (ready) {
				String message = SETMOVE + DELIMITER + this.getName();
				for (Coordinate coord : this.getFromCube().getCoordinates()) {
					message += DELIMITER + coord.getValue();
				}
				this.setChanged();
				this.notifyObservers(message);
			} else {
				exit();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		lock.unlock();
	}
	
	/**
	 * Checks whether player is ready.
	 * @return
	 */
	public boolean isReady() {
		return this.ready;
	}
	
	/**
	 * Signals if point is ready.
	 */
	public void pointIsReady() {
		ready = true;
		lock.lock();
		condition.signal();
		lock.unlock();
	}
	
	/**
	 * Messages the client.
	 * @param message
	 */
	public void message(String message) {
		if (this.handler != null) {
			this.handler.sendMessage(message);
		}
	}
	
	/**
	 * Makes a readyCheck.
	 * @param command
	 */
	public void checkReady(String command) {
		if (command.equals(READY)) {
			this.ready = true;
		}
		setChanged();
		notifyObservers(command);
	}
	
	/**
	 * Exits game.
	 */
	public void exit() {
    	this.setChanged();
		this.notifyObservers(ERROR_USER_QUIT);
    }
	
	/**
	 * Sets the player to be ready.
	 * @param value
	 */
	public void setReady(boolean value) {
		this.ready = value;
	}
}