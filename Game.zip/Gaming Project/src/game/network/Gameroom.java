package game.network;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.ai.ComputerPlayer;
import game.logic.Game;
import game.logic.Player;
import game.ui.NetworkUI;

public class Gameroom extends Observable implements Runnable, Observer, NetworkProtocol {
	private static final int NUMBER_OF_PLAYERS = 2;
	
	private Map<NetworkPlayer, String> queue = new ConcurrentHashMap<NetworkPlayer, String>();
	private Set<Game> lobbies = ConcurrentHashMap.newKeySet();
	private Set<Game> games = ConcurrentHashMap.newKeySet();
	
	public void update(Observable o, Object obj) {
		if (o instanceof Game) {
			Game game = (Game) o;
			if (obj.equals(READY)) {
				games.add(game);
				lobbies.remove(game);
			} else if (obj.equals(ERROR_USER_QUIT)) {
				lobbies.add(game);
				games.remove(game);
				deleteIfIrrelevant(game);
			}
		}
	}
	
	public void deleteIfIrrelevant(Game game) {
		for (Player player : game.getPlayers()) {
			if (player instanceof ComputerPlayer) {
				lobbies.remove(game);
				games.remove(game);
				game.exit();
				break;
			}
		}
	}
	
	public void goToQueue(NetworkPlayer player, String opponent) {
		queue.put(player, opponent);
	}
	
	public void run() {
		try {
		    synchronized(this) {
		        while(true) {
		        	if (queue.size() > 0) {
						Entry<NetworkPlayer, String> entry;
						for (Iterator<Map.Entry<NetworkPlayer, String>> it = queue.entrySet().iterator();
								it.hasNext();) {
							entry = it.next();
							update(entry.getKey(), entry.getValue());
							it.remove();
						}
					} else {
						this.wait(1);
					}
		        }
		    }
		} catch (InterruptedException e) {
		    System.out.println(e.getMessage());
		}
	}
	
	public Game newGame(NetworkPlayer player) {
		Game game = new Game(new NetworkUI(), NUMBER_OF_PLAYERS);
		game.addObserver(this);
		(new Thread(game)).start();
		addPlayer(player, game);
		return game;
	}
	
	public void update(NetworkPlayer player, String opponent) {
		if (opponent.equals(COMPUTER)) {
			Game game = newGame(player);
			addPlayer(new ComputerPlayer(), game);
		} else {
			if (lobbies.size() > 0) {
				for (Game lobby : lobbies) {
					if (!lobby.isFull()) {
						addPlayer(player, lobby);
						break;
					}
				}
			} else {
				Game game = newGame(player);
				lobbies.add(game);
			}
		}
	}
	
	public void addPlayer(Player player, Game game) {
		while (!game.isAvailable());
		game.setCurrentPlayer(player);
	}
}
