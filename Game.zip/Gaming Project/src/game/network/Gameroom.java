package game.network;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.ai.ComputerPlayer;
import game.logic.Game;
import game.logic.Player;
import game.ui.NetworkUI;

public class Gameroom extends Observable implements Runnable, Observer, NetworkProtocol {
	
	// ------------------------ Instance Variables ------------------------
	
	
	/**
	 * Instance Variables.
	 * @param NUMBER_OF_PLAYERS is the currently supported number of players per Game in Gameroom
	 * @param queue is a list of NetworkPlayers who have not yet been processed
	 * @param lobbies is a list of games who are still not full and are waiting for new Players
	 * @param games is a list of games who are full and are active
	 */
	private static final int NUMBER_OF_PLAYERS = 2;
	private Map<NetworkPlayer, String> queue = new ConcurrentHashMap<NetworkPlayer, String>();
	private Set<Game> lobbies = ConcurrentHashMap.newKeySet();
	private Set<Game> games = ConcurrentHashMap.newKeySet();
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Manages games and lobbies lists via the observant-observable pattern.
	 */
	public void update(Observable o, Object obj) {
		if (o instanceof Game) {
			Game game = (Game) o;
			if (obj.equals(READY)) {
				games.add(game);
				lobbies.remove(game);
			} else if (obj.equals(ERROR_USER_QUIT)) {
				lobbies.add(game);
				games.remove(game);
				deleteIfIrrelevant(game);
			} else if (obj.equals(GAMEOVER)) {
				lobbies.remove(game);
				games.remove(game);
			}
		}
	}
	
	/**
	 * Makes and starts new games in separate threads depending on the queue,
	 * as well as processes each player in the queue one by one.
	 */
	public void run() {
		try {
		    synchronized(this) {
		        while(true) {
		        	if (queue.size() > 0) {
						Entry<NetworkPlayer, String> entry;
						for (Iterator<Map.Entry<NetworkPlayer, String>> it = queue.entrySet().iterator();
								it.hasNext();) {
							entry = it.next();
							update(entry.getKey(), entry.getValue());
							it.remove();
						}
					} else {
						this.wait(1);
					}
		        }
		    }
		} catch (InterruptedException e) {
		    System.out.println(e.getMessage());
		}
	}
	
	/**
	 * Deletes game if a user has quit and the other user is a ComputerPlayer.
	 * @param game
	 */
	public void deleteIfIrrelevant(Game game) {
		for (Player player : game.getPlayers()) {
			if (player instanceof ComputerPlayer) {
				deleteGame(game);
				break;
			}
		}
	}
	
	/**
	 * Deletes a Game by removing it from the lobbies and games lists, exitting it and deleting its observers.
	 * @param game
	 */
	public void deleteGame(Game game) {
		lobbies.remove(game);
		games.remove(game);
		game.exit();
		game.deleteObservers();
	}
	
	/**
	 * Adds a new Player to the queue.
	 * @param player
	 * @param opponent
	 */
	public void goToQueue(NetworkPlayer player, String opponent) {
		queue.put(player, opponent);
	}
	
	/**
	 * Creates a new Game and adds a NetworkPlayer to it.
	 * @param player
	 * @return
	 */
	public Game newGame(NetworkPlayer player) {
		Game game = new Game(new NetworkUI(), NUMBER_OF_PLAYERS);
		game.addObserver(this);
		(new Thread(game)).start();
		addPlayer(player, game);
		return game;
	}
	
	/**
	 * Updates the lobbies and the games lists based on a new NetworkPlayer whose turn is to join from the queue.
	 * @param player
	 * @param opponent
	 */
	public void update(NetworkPlayer player, String opponent) {
		if (opponent.equals(COMPUTER)) {
			Game game = newGame(player);
			addPlayer(new ComputerPlayer(), game);
		} else {
			if (lobbies.size() > 0) {
				for (Game lobby : lobbies) {
					if (!lobby.isFull()) {
						addPlayer(player, lobby);
						break;
					}
				}
			} else {
				Game game = newGame(player);
				lobbies.add(game);
			}
		}
	}
	
	/**
	 * Adds a Player to the game, waits until the previous Player has been processed as to not overwrite it.
	 * @param player
	 * @param game
	 */
	public void addPlayer(Player player, Game game) {
		while (!game.isAvailable());
		game.setCurrentPlayer(player);
	}
}