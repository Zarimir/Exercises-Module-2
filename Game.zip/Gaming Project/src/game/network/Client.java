package game.network;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Observable;
import java.util.Scanner;

import game.logic.Game;
import game.logic.HumanPlayer;
import game.ui.ClientTUI;


public class Client extends Observable implements Runnable, NetworkProtocol {
	private static final String USAGE = "usage: " + Client.class.getName() + " <name> <address>";
	
	/**
	 * Start Client.
	 */
	public static void main(String[] argss) {
		Scanner scan = new Scanner(System.in);
		System.out.print("- What is your name?\n- ");
		String[] args = {scan.nextLine(), "localhost"};
		//String[] args = {"Pesho", "localhost"};
		if (args.length != 2) {
			System.out.println(USAGE);
			System.exit(0);
		}
		InetAddress host = null;
		try {
			host = InetAddress.getByName(args[1]);
		} catch (UnknownHostException e) {
			print("ERROR: no valid hostname!");
			System.exit(0);
		}
		
		try {
			Client client = new Client(args[0], host, PORTNUMBER);
			//client.sendMessage(HELLO + DELIMITER + args[0]);
			client.sendMessage(HELLO + DELIMITER + args[0] + DELIMITER + EXT_CHAT);
			(new Thread(client)).start();
			do {
				client.sendMessage(client.readString(""));
			} while(true);
		} catch (IOException e) {
			print("ERROR: couldn�t construct a client object!");
			System.exit(0);
		}
		//scan.close();
	}
	
	private String name;
	private Socket sock;
	private BufferedReader in;
	private BufferedWriter out;
	private String state;
	
	/**
	 * Constructs a Client-object and tries to make a socket connection
	 */
	public Client(String name, InetAddress host, int port) throws IOException {
		sock = new Socket(host, port);
		in = new BufferedReader (new InputStreamReader(sock.getInputStream()));
		out = new BufferedWriter (new OutputStreamWriter(sock.getOutputStream()));
	}
	
	/**
	 * Reads the messages in the socket connection. Each message will
	 * be forwarded to the MessageUI
	 */
	public void run() {
		try {
			String msg = in.readLine();
			while (msg != null) {
				print(msg);
				String[] split = msg.split(DELIMITER);
				if (split.length == 3 && split[0].equals(READY)) { // it is not made to work for more than 2 players
					ClientTUI ui = new ClientTUI();
					Game game = new Game(ui, 2);
					this.addObserver(ui);
					for (int i = 1; i < split.length; i++) {
						if (!split[i].equals(this.name)) {
							game.addPlayer(new HumanPlayer(split[i]));
							game.addPlayer(new HumanPlayer(this.name));
						}
					}
				} else {
					this.setChanged();
					this.notifyObservers(split);
					if (split.length > 1 &&
							split[0].equals(REQUESTMOVE) &&
							split[1].equals(this.name)) {
						this.state = MAKEMOVE;
						System.out.println("Your turn");
					} else if (split.length > 1 &&
							split[0].equals(SETMOVE) &&
							split[1].equals(this.name)) {
						this.state = null;
					} else if (split.length > 0 && split[0].equals(GAMEOVER)) {
						
					}
				}
				msg = in.readLine();
			}
			
			shutdown();
		} catch (IOException e) {
			System.out.println(e.getMessage());
			shutdown();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			shutdown();
		}
	}
	
	
	/**
	 * send a message to a ClientHandler.
	 */
	public void sendMessage(String msg) {
		try {
			out.write(msg);
			out.newLine();
			out.flush();
			if (msg.split(DELIMITER)[0].equals(HELLO)) {
				this.name = msg.split(DELIMITER)[1];
			}
		} catch (IOException e) {
			shutdown();
		}
	}
	
	/**
	 * close the socket connection.
	 */
	public void shutdown() {
		print("Closing socket connection...");
		try {
			sock.close();
			print("Done!");
		} catch (IOException e) {
			print("ERROR: error closing the socket connection!");
		}
	}
	
	/**
	 * returns the client name
	 */
	public String getClientName() {
		return name;
	}
	
	private static void print(String message) {
		System.out.println(message);
	}
	
	public String readString(String text) {
		System.out.print(text);
		if (state != null && state.equals(MAKEMOVE)) {
			System.out.println("You need to write a " + 3 + " dimensional point's coordinates separated by a " + DELIMITER + " like this - 1" + DELIMITER + "2" + DELIMITER +"3");
		}
		String antw = null;
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			antw = in.readLine();
		} catch (IOException e) {
			
		}
		if (state != null && state.equals(MAKEMOVE)) {
			antw = MAKEMOVE + DELIMITER + antw;
		}
		return (antw == null) ? "" : antw;
	}
}
