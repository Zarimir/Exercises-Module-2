package game.network.exception;

import game.network.NetworkProtocol;

public class CommandNotRecognizedException extends Exception implements NetworkProtocol {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6658938257339035915L;

	public CommandNotRecognizedException() {
		super(ERROR_COMMAND_NOT_RECOGNIZED);
	}
}
