package game.network.exception;

import game.network.NetworkProtocol;

public class NotYourTurnException extends Exception implements NetworkProtocol {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7960327311567775857L;

	public NotYourTurnException() {
		super();
	}
}
