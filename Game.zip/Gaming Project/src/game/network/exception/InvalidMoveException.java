package game.network.exception;

import game.geometry.Point;
import game.network.NetworkProtocol;

public class InvalidMoveException extends Exception implements NetworkProtocol {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2992471290598694020L;

	public InvalidMoveException() {
		super(ERROR_INVALID_MOVE);
	}
	
	public InvalidMoveException(Point point) {
		this(point.strip());
	}
	
	public InvalidMoveException(int[] coords) {
		super(constructMessage(coords));
	}
	
	public static String constructMessage(int[] coords) {
		String message = ERROR_INVALID_MOVE;
		message = ERROR_INVALID_MOVE;
		for (int coord : coords) {
			message += DELIMITER + coord;
		}
		return message;
	}
}
