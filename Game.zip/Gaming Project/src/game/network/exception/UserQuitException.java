package game.network.exception;

import game.network.NetworkProtocol;

public class UserQuitException extends Exception implements NetworkProtocol {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1789432484297823448L;

	public UserQuitException() {
		super(ERROR_USER_QUIT);
	}
}
