package game.network.exception;

import game.network.NetworkProtocol;

public class NotInGameException extends Exception implements NetworkProtocol {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4031726478398374763L;

	public NotInGameException() {
		super(ERROR_NOT_IN_GAME);
	}
}
