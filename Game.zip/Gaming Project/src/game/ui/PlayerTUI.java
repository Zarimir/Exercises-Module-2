/**
 * 
 */
package game.ui;

import java.util.Observable;
import java.util.Scanner;

import game.geometry.Point;
import game.logic.Game;
import game.logic.GameProtocol;
import game.logic.HumanPlayer;
import game.logic.Mark;
import game.logic.Player;

/**
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public class PlayerTUI implements View, GameProtocol {
	
	// ------------------------  Instance Variables  ------------------------
	
	private static final String EXIT = "EXIT";	
	private static final Scanner INPUT = new Scanner(System.in);
	private String forcedCommand;
	private Player currentPlayer;
	private boolean exit = false;
	
	//private Map<String, Integer> commands;
	
	private Game game;
	
	// ------------------------ Constructor ------------------------
	
	public void setGame(Game game) {
		this.game = game;
	}
	
	// ------------------------ Queries ------------------------
	
	// ------------------------ Commands ------------------------
	
	public void run() {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("What's your input?\n> ");
		String command;
		while (!exit) {
			command = keyboard.nextLine();
			executeCommand(command.split(" "));
		}
		keyboard.close();
	}
	
	
	public void executeCommand(String[] args) {
		String command = args[0];
		if (forcedCommand != null && command.equals(forcedCommand) || forcedCommand == null) {
			switch (command) {
			case REQUESTMOVE:
				requestMove();
				break;
			case EXIT:
				System.out.println("Currently Exiting");
				exit();
				break;
			}
		} else {
			showError(ERROR_ENFORCED_COMMAND + " " + forcedCommand);
		}
	}
	
	/*
	public void determineMove(args) {
		
	}
	*/
	
	public void update(Observable o, Object obj) {
		if (o instanceof HumanPlayer) {
			if (obj.equals(REQUESTMOVE)) {
				showGame();
				currentPlayer = (HumanPlayer) o;
				forcedCommand = REQUESTMOVE;
				System.out.println("Your turn...");
			}
		} else if (o instanceof Game) {
			if (obj instanceof HumanPlayer) {
				//Human
			}
		}
	}
	
	public void signal() {
		
	}
	
	public void exit() {
		inform("Done!");
		System.out.println("quit");
		game.exit();
		exit = true;
	}
	
	public void showCommands(String[] args) {
		inform(this.toString());
	}
	
	public void showWinner(Player player) {
        if (player == null) {
        	System.out.println("Draw. There is no winner!");
        } else {
        	String name = player.getName();
        	System.out.println(name + " has won!");
        }
    }
	
	public void showGame() {
		System.out.println(game.getHyperCube());
	}
	
	public void printSquare(Mark[] marks) {
		
		System.out.println();
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				System.out.print("|" + marks[i] + "|");
			}
			System.out.println();
		}
		for (int i = 0; i < marks.length; i++) {
			System.out.print("___");
		}
	}
	
	public void requestMove() {
		if (currentPlayer instanceof HumanPlayer) {
			HumanPlayer human = (HumanPlayer) currentPlayer;
			Point attempt = new Point(readCoordinates(human));
			while (true) {
			human.setPoint(attempt);
				if (human.getFromCube() == null) {
					System.out.println("The point is invalid.");
					attempt = new Point(readCoordinates(human));
				} else {
					human.setPoint(human.getFromCube());
					human.moveReady();
					break;
				}
			}
		}
		
	}
	
	public int[] readCoordinates(Player player) {
		int dimension = game.getHyperCube().getDimension();
		int[] result;
		String choice;
		String[] cut;
		while(true) {
			inform("You need to write a " + dimension + " dimensional point's coordinates separated by a whitespace!");
			choice = INPUT.nextLine();
			cut = choice.split("[^0-9]+");
			if (cut.length == 1 || cut.length == dimension) {
				break;
			} else if (choice.equals(EXIT)) {
				exit();
				break;
			} else {
				showError("Invalid index or coordinates");
			}
		}
		result = new int[dimension];
		for (int i = 0; i < cut.length; i++) {
			result[i] = Integer.parseInt(cut[i]);
		}
		return result;
	}
	
	public void showError(String error) {
		System.out.println(error);
	}
	
	public void inform(String message) {
		System.out.println(message);
	}
}
