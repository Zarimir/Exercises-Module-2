/**
 * 
 */
package game.ui;

import java.util.Observable;
import java.util.Scanner;

import game.geometry.Point;
import game.logic.Game;
import game.logic.GameProtocol;
import game.logic.HumanPlayer;
import game.logic.Player;

/**
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public class PlayerTUI implements View, GameProtocol {
	
	// ------------------------  Instance Variables  ------------------------
	
	private static final String EXIT = "EXIT";	
	private static final Scanner INPUT = new Scanner(System.in);
	private String forcedCommand;
	private Player currentPlayer;
	private boolean exit = false;
	//private boolean running = false;
	
	//private Map<String, Integer> commands;
	
	private Game game;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Sets the Game of this view.
	 */
	public void setGame(Game game) {
		this.game = game;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Updates based on the observer observant pattern.
	 * Used for prompting humanPlayer to decide on a move.
	 */
	public void update(Observable o, Object obj) {
		if (o instanceof HumanPlayer) {
			if (obj.equals(REQUESTMOVE)) {
				showGame();
				currentPlayer = (HumanPlayer) o;
				forcedCommand = REQUESTMOVE;
				System.out.println("Your turn...");
			}
		} else if (o instanceof Game) {
			if (obj instanceof HumanPlayer) {
				//Human
			}
		}
	}
	
	/**
	 * Parallel runner takes care of user input.
	 */
	public void run() {
		//running = true;
		Scanner keyboard = new Scanner(System.in);
		System.out.println("What's your input?\n> ");
		String command;
		while (!exit) {
			command = keyboard.nextLine();
			executeCommand(command.split(" "));
		}
		this.game = null;
		keyboard.close();
		//running = false;
	}
	
	/**
	 * Determines input and executes appropriate command.
	 * @param args
	 */
	public void executeCommand(String[] args) {
		String command = args[0];
		if (forcedCommand != null && command.equals(forcedCommand) || forcedCommand == null) {
			switch (command) {
			case REQUESTMOVE:
				requestMove();
				break;
			case EXIT:
				System.out.println("Currently Exiting");
				game.exit();
				break;
			}
		} else {
			showError(ERROR_ENFORCED_COMMAND + " " + forcedCommand);
		}
	}
	
	/**
	 * Shows possible commands.
	 * @param args
	 */
	public void showCommands(String[] args) {
		inform(this.toString());
	}
	
	/**
	 * Shows the winner of the Game.
	 */
	public void showWinner(Player player) {
        if (player == null) {
        	System.out.println("Draw. There is no winner!");
        } else {
        	String name = player.getName();
        	System.out.println(name + " has won!");
        }
        this.game.getHyperCube().initialize();
    }
	
	/**
	 * Shows the current state of the Game
	 */
	public void showGame() {
		System.out.println(game.getHyperCube());
	}
	
	/**
	 * Requests a move from the HumanPlayer and verifies if it is a correct point.
	 */
	public void requestMove() {
		if (currentPlayer instanceof HumanPlayer) {
			HumanPlayer human = (HumanPlayer) currentPlayer;
			Point attempt = new Point(readCoordinates(human));
			while (true) {
			human.setPoint(attempt);
				if (human.getFromCube() == null) {
					System.out.println("The point is invalid.");
					attempt = new Point(readCoordinates(human));
				} else {
					human.setPoint(human.getFromCube());
					human.moveReady();
					break;
				}
			}
		}
		
	}
	
	/**
	 * Reads user input and if appropriate, formats it into coordinates, otherwise requires new input.
	 * @param player
	 * @return
	 */
	public int[] readCoordinates(Player player) {
		int dimension = game.getHyperCube().getDimension();
		int[] result;
		String choice;
		String[] cut;
		while(true) {
			inform("You need to write a " + dimension + " dimensional point's coordinates separated by a whitespace!");
			choice = INPUT.nextLine();
			cut = choice.split("[^0-9]+");
			if (cut.length == 1 || cut.length == dimension) {
				break;
			} else if (choice.equals(EXIT)) {
				game.exit();
				break;
			} else {
				showError("Invalid index or coordinates");
			}
		}
		result = new int[dimension];
		for (int i = 0; i < cut.length; i++) {
			result[i] = Integer.parseInt(cut[i]);
		}
		return result;
	}
	
	public void showError(String error) {
		System.out.println(error);
	}
	
	public void inform(String message) {
		System.out.println(message);
	}
	
	/**
	 * Deletes UI and Game.
	 */
	public void exit() {
		inform("Quit!");
		exit = true;
	}
	
	/*
	public void determineMove(args) {
		
	}
	*/
	
	
	
	/*
	public void signal() {
		
	}
	*/
}
