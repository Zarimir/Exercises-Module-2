package game.ui;

//import java.util.Iterator;
import java.util.Observable;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.ai.ComputerPlayer;
import game.logic.Game;
import game.logic.Player;
import game.network.ClientHandler;
import game.network.NetworkPlayer;

public class NetworkUI implements View {
	
	/**
	 * Instance Variables.
	 * @param players is a list of networkPlayers
	 * @param game holds a reference to the Game itself
	 * @param lock is a ReentrantLock
	 * @param condition is a Condition from lock
	 * @param exit is a boolean which keeps the thread alive as long as it's false
	 * @param SECONDS_READY_CHECK is the number of seconds to be waited for each ready check
	 */
	private Set<NetworkPlayer> players = ConcurrentHashMap.newKeySet();
	private Game game;
	private int waitForPlayers = 0;
	private Lock lock = new ReentrantLock();
	private Condition condition = lock.newCondition();
	private boolean exit = false;
	public static final int SECONDS_READY_CHECK = 20;
	public boolean running = false;
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Observant update.
	 * If Game updates, add the new player from game.
	 * If ComputerPlayer updates with SETMOVE, notify players
	 * If NetworkPlayer updates with Ready, wait for 1 player less
	 * If a NetworkPlayer has quit, execute quit game method
	 * If a NetworkPlayer has setMove, notify all players
	 * If NetworkPlayer is requested a move, broadcast
	 */
	public void update(Observable o, Object obj) {
		if (o instanceof NetworkPlayer) {
			NetworkPlayer player = (NetworkPlayer) o;
			if ((obj instanceof String)) {
				String flag = (String) obj;
				if (flag.equals(READY)) {
					waitForPlayers -= 1;
					//broadcast("" + waitForPlayers);
					if (waitForPlayers == 0) {
						unlockCommands();
						this.signal();
					}
				} else if (flag.equals(ERROR_USER_QUIT)) {
					quitGame(player);
					boolean deleteGame = true;
					for (Player p : game.getPlayers()) {
						if (!(p instanceof ComputerPlayer)) {
							deleteGame = false;
						}
					}
					if (deleteGame) {
						game.exit();
					} else if (game.isPlayed()) {
						unlockCommands();
					} else {
						waitForPlayers -= 1;
						//System.out.println("WAIT FOR PLAYERS IS : " + waitForPlayers);
						if (!(waitForPlayers > 0)) {
							this.signal();
						}
					}
				} else if (flag.indexOf(SETMOVE) >= 0) {
					broadcast((String) obj);
				} else if (flag.equals(REQUESTMOVE)) {
					broadcast(REQUESTMOVE + DELIMITER + player.getName());
				}
			}
		} else if (o instanceof ComputerPlayer) {
			if ((obj instanceof String) && ((String) obj).indexOf(SETMOVE) >= 0) {
				broadcast((String) obj);
			}
		} else if (o instanceof Game) {
			if (obj instanceof NetworkPlayer) {
				this.players.add((NetworkPlayer) obj);
			}
		}
	}
	
	/**
	 * If Game is Full and is waiting for a ready check, make a ready check
	 * Otherwise block
	 */
	public void run() {
		running = true;
		try {
		    synchronized(this) {
		    	
		        while(!exit) {
		        	if (this.game.isFull() && this.game.waitsForCheck()) {
		        		System.out.println("Check Ready");
		        		checkReady();
		        		boolean waits = (this.game.isFull()) ? false : true;
		        		this.game.setCheck(waits);
		        	} else {
		        		wait(1);
		        	}
		        }
		    }
		} catch (InterruptedException e) {
		    System.out.println(e.getMessage());
		
		}
		running = false;
	}
	
	/**
	 * Signal for the ready check if all players are ready before timer expires.
	 */
	public void signal() {
		lock.lock();
		condition.signal();
		lock.unlock();
	}
	
	/**
	 * Set this Game.
	 */
	public void setGame(Game game) {
		this.game = game;
	}
	
	/**
	 * Broadcasts winner.
	 */
	public void showWinner(Player winner) {
		String winnerName = "";
		if (winner != null) {
			winnerName = winner.getName();
		}
		broadcast(GAMEOVER + DELIMITER + winnerName);
	}
	
	/**
	 * Determines a NetworkPlayer's move.
	 * @param player
	 */
	public void determineMove(NetworkPlayer player) {
		Set<String> commands = ConcurrentHashMap.newKeySet();
		commands.add(MAKEMOVE);
		player.getHandler().requestCommands(commands);
		player.getHandler().sendMessage(REQUESTMOVE);
	}
	
	/**
	 * Handles UserQuit error, by freeing space in the game and broadcasting to other users.
	 * @param player
	 */
	
	public void quitGame(NetworkPlayer player) {
		System.out.println("Deleting : " + player);
		ClientHandler handler = player.getHandler();
		players.remove(player);
		game.removePlayer(player);
		broadcast(ERROR_USER_QUIT + DELIMITER + player.getName());
		game.notify(ERROR_USER_QUIT);
		handler.deletePlayer();
		handler.unlockCommands();
	}
	
	/**
	 * Constructs move message.
	 * @param player
	 */
	public void constructMoveMessage(NetworkPlayer player) {
		player.setPoint(player.getFromCube());
		int[] coords = player.getPoint().strip();
		String message = SETMOVE + DELIMITER + player.getName();
		for (int coord : coords) {
			message += DELIMITER + coord;
		}
		player.pointIsReady();
		broadcast(message);
		
	}
	
	/**
	 * Broadcasts a message to all players.
	 * @param message
	 */
	public void broadcast(String message) {
		try {
			for (NetworkPlayer player : players) {
				player.message(message);
			}
		} catch (Exception e) {
			System.out.println("NetworkUI broadcast failed...");
		}
	}
	
	/**
	 * Unlocks commands of networkPlayers after they have executed an enforced command.
	 */
	public void unlockCommands() {
		for (NetworkPlayer player : players) {
			player.getHandler().unlockCommands();
		}
	}
	/**
	 * Prompts networkPlayers to say they are ready and then waits for response.
	 */
	public void checkReady() {
		waitForPlayers = players.size();
		Set<String> commands = ConcurrentHashMap.newKeySet();
		commands.add(READY);
		commands.add(DECLINE);
		String message = READY;
		for (Player player : game.getPlayers()) {
			message += DELIMITER + player.getName();
		}
		broadcast(message);
		for (NetworkPlayer player : players) {
			player.setReady(false);
			player.getHandler().requestCommands(commands);
		}
		
		lock.lock();
		try {
			condition.await(SECONDS_READY_CHECK, TimeUnit.SECONDS);
			if (!exit) {
				/*
				for (NetworkPlayer player : players) {
					System.out.println(player);
				}
				*/
				for (NetworkPlayer player : players) {
					if (!player.isReady()) {
						System.out.println(player + " is not ready!");
						quitGame(player);
					}
				}
				unlockCommands();
			}
			if (game.getPlayers().size() == 0) {
				game.exit();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		lock.unlock();
	}
	
	/**
	 * Deletes UI and game.
	 */
	public void exit() {
		this.exit = true;
		this.signal();
		System.out.println("NetworkUI thread killed");
	}
}