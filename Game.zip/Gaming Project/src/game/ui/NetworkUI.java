package game.ui;

import java.util.Observable;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.ai.ComputerPlayer;
import game.logic.Game;
import game.logic.Player;
import game.network.ClientHandler;
import game.network.NetworkPlayer;

public class NetworkUI implements View {
	
	private Set<NetworkPlayer> players = ConcurrentHashMap.newKeySet();;
	private Game game;
	private int waitForPlayers = 0;
	private Lock lock = new ReentrantLock();
	private Condition condition = lock.newCondition();
	private boolean exit = false;
	
	public void setGame(Game game) {
		this.game = game;
	}
	
	public void update(Observable o, Object obj) {
		if (o instanceof NetworkPlayer) {
			NetworkPlayer player = (NetworkPlayer) o;
			if ((obj instanceof String)) {
				String flag = (String) obj;
				if (flag.equals(READY)) {
					waitForPlayers -= 1;
					//broadcast("" + waitForPlayers);
					if (waitForPlayers == 0) {
						unlockCommands();
						this.signal();
					}
				} else if (flag.equals(ERROR_USER_QUIT)) {
					quitGame(player);
				} else if (flag.indexOf(SETMOVE) >= 0) {
					broadcast((String) obj);
				} else if (flag.equals(REQUESTMOVE)) {
					broadcast(REQUESTMOVE + DELIMITER + player.getName());
				}
			}
		} else if (o instanceof ComputerPlayer) {
			if ((obj instanceof String) && ((String) obj).indexOf(SETMOVE) >= 0) {
				broadcast((String) obj);
			}
		} else if (o instanceof Game) {
			if (obj instanceof NetworkPlayer) {
				this.players.add((NetworkPlayer) obj);
			}
		}
	}
	
	public void signal() {
		lock.lock();
		condition.signal();
		lock.unlock();
	}
	
	public void run() {
		while (!exit) {
			while (!exit && !this.game.isFull());
			lock.lock();
			checkReady();
			try {
				condition.await(600, TimeUnit.SECONDS);
				System.out.println("ELAPSED!");
				if (waitForPlayers > 0) {
					System.out.println("Iterating");
					for (NetworkPlayer player : players) {
						System.out.println(player);
					}
					for (NetworkPlayer player : players) {
						if (!player.isReady()) {
							System.out.println(player + " is not ready!");
							quitGame(player);
							break;
						}
					}
				}
				if (exit) {
					break;
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			lock.unlock();
			game.signal();
			System.out.println("Movign on");
			while(!this.game.isPlayed());
			while (!exit && this.game.isFull() && this.game.isPlayed());
		}
	}
	
	public void showWinner(Player winner) {
		String winnerName = "";
		if (winner != null) {
			winnerName = winner.getName();
		}
		broadcast(GAMEOVER + DELIMITER + winnerName);
	}
	
	public void determineMove(NetworkPlayer player) {
		Set<String> commands = ConcurrentHashMap.newKeySet();
		commands.add(MAKEMOVE);
		player.getHandler().requestCommands(commands);
		player.getHandler().sendMessage(REQUESTMOVE);
	}
	
	public void quitGame(NetworkPlayer player) {
		System.out.println("Deleting : " + player);
		ClientHandler handler = player.getHandler();
		players.remove(player);
		game.removePlayer(player);
		unlockCommands();
		broadcast(ERROR_USER_QUIT + DELIMITER + player.getName());
		game.notify(ERROR_USER_QUIT);
		handler.deletePlayer();
		handler.unlockCommands();
		this.signal();
	}
	
	public void exit() {
		this.exit = true;
		this.signal();
		this.players = null;
		this.game = null;
	}
	
	public void constructMoveMessage(NetworkPlayer player) {
		player.setPoint(player.getFromCube());
		int[] coords = player.getPoint().strip();
		String message = SETMOVE + DELIMITER + player.getName();
		for (int coord : coords) {
			message += DELIMITER + coord;
		}
		player.pointIsReady();
		broadcast(message);
		
	}
	
	public void broadcast(String message) {
		try {
			for (NetworkPlayer player : players) {
				player.message(message);
			}
		} catch (Exception e) {
			System.out.println("NetworkUI broadcast failed...");
		}
	}
	
	public void unlockCommands() {
		for (NetworkPlayer player : players) {
			player.getHandler().unlockCommands();
		}
	}
	
	public void checkReady() {
		waitForPlayers = players.size();
		Set<String> commands = ConcurrentHashMap.newKeySet();
		commands.add(READY);
		commands.add(DECLINE);
		String message = READY;
		for (Player player : game.getPlayers()) {
			message += DELIMITER + player.getName();
		}
		broadcast(message);
		for (NetworkPlayer player : players) {
			player.setReady(false);
			player.getHandler().requestCommands(commands);
		}
	}
}