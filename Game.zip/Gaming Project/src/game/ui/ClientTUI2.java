package game.ui;

import java.util.Iterator;
import java.util.Observable;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.logic.Game;
import game.logic.Player;
import game.network.Client;
import game.network.ClientPlayer;

public class ClientTUI2 implements View {
	private Set<String> commands = ConcurrentHashMap.newKeySet();
	private boolean exit = false;
	private String command;
	private Game game;
	private Client client;
	private Lock lock = new ReentrantLock();
	private Condition condition = lock.newCondition();
	
	public void setGame(Game game) {
		this.game = game;
	}
	
	public void setClient(Client client) {
		this.client = client;
	}
	
	public void update(Observable o, Object obj) {
		if (o instanceof ClientPlayer) {
			//ClientPlayer player = (ClientPlayer) o;
			if (obj.equals(DECLINE)) {
				exit();
			}
		}
	}
	
	public void commandToQueue(String command) {
		commands.add(command);
	}
	
	public void run() {
		while (!exit) {
			if (commands.size() > 0) {
				for (Iterator<String> it = commands.iterator(); it.hasNext();) {
					command = it.next();
					execute();
					it.remove();
				}
			}
		}
		signal();
	}
	
	public void execute() {
		String head = command.split(DELIMITER)[0];
		switch (head) {
		case REQUESTMOVE:
			setMove();
		case SETMOVE:
			
			break;
		case GAMEOVER:
			showWinner(game.getPlayer(game.getHyperCube().getWinner()));
		}
	}
	
	public void showWinner(Player player) {
		String announce = GAMEOVER;
		if (player != null) {
			announce += " " + player.getName();
		}
		System.out.println(announce);
		exit();
	}
	
	public void setMove() {
		String[] args = command.split(DELIMITER);
		for (int i = 1; i < args.length; i++) {
			
		}
	}
	
	public void signal() {
		lock.lock();
		condition.signal();
		lock.unlock();
	}
	
	public void exit() {
		this.exit = true;
		lock.lock();
		try {
			condition.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.client = null;
		this.game = null;
		lock.unlock();
	}
}
