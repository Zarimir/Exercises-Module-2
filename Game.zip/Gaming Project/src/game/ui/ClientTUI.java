package game.ui;

import java.util.Iterator;
import java.util.Observable;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.geometry.Coordinate;
import game.geometry.HyperCube;
import game.geometry.Point;
import game.logic.Game;
import game.logic.Player;
import game.network.Client;

public class ClientTUI implements View {
	
	private HyperCube cube;
	
	private boolean exit = false;
	private String[] command;
	private Lock lock = new ReentrantLock();
	private Condition condition = lock.newCondition();
	private Client client;
	private Game game;
	private Scanner in = new Scanner(System.in);
	
	public ClientTUI(Client client) {
		this.client = client;
	}
	
	public void setGame(Game game) {
		this.game = game;
		this.cube = this.game.getHyperCube();
	}
	
	public void update(Observable o, Object obj) {
		
		if (o instanceof Client) {
			if (obj instanceof String) {
				chopCommand((String) obj);
				signal();
			}
			/*
			System.out.println("Commands:");
			System.out.print("[");
			for(String s : command) {
				System.out.print(s);
			}
			System.out.println("]");
			*/
			
		}
	}
	
	public void chopCommand(String command) {
		while(this.command != null);
		this.command = command.split(DELIMITER);
	}
	
	public void run() {
		while (!exit) {
			lock.lock();
			try {
				condition.await();
				if (exit) {
					break;
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			lock.unlock();
			if (command != null) {
				switch (command[0]) {
				case PLAY:
					command[0].equals(PLAY);
					break;
				case SETMOVE:
					if (command.length > (1 + this.cube.getDimension())) {
						setMove();
					}
					break;
				case REQUESTMOVE:
					System.out.println(cube);
					break;
				case ERROR_INVALID_MOVE:
					break;
				case GAMEOVER:
					
					showWinner();
					break;
				}
				command = null;
			}
		}
	}
	
	
	
	public void showWinner() {
		String announce = GAMEOVER;
		for (int i = 1; i < command.length; i++) {
			announce += DELIMITER + command[i];
		}
		System.out.println(announce);
		exit();
	}
	
	public void showWinner(Player player) {
		String announce = GAMEOVER;
		for (int i = 1; i < command.length; i++) {
			announce += DELIMITER + command[i];
		}
		System.out.println(announce);
		exit();
	}
	
	public void setMove() {
		Player current = this.game.getPlayer(command[1]);
		Point point = new Point(cube.getDimension());
		String coords = "";
		for (int i = 2; i < command.length; i++) {
			coords += command[i] + " ";
		}
		updatePoint(point, coords);
		point = cube.getPoint(point);
		if (point == null) {
			System.out.println("Mismatch between server game and local game");
		} else {
			if (current.getCube() == null) {
				this.game.setCubes();
			}
			current.makeMove(point);
		}
		
	}
	
	public void updatePoint(Point point, String input) {
		String[] cut = input.split("[^0-9]+");
		if (cut.length == cube.getDimension()) {
			for (int i = 0; i < cube.getDimension(); i++) {
				point.getCoordinates()[i].setValue(Integer.parseInt(cut[i]));
			}
		}
	}
	/*
	public void checkPoint() {
		Point point = new Point(this.cube.getDimension());
		updatePoint(point, command[1]);
		
		if (cube.getPoint(point) != null) {
			String msg = MAKEMOVE;
			for (Coordinate coord : point.getCoordinates()) {
				msg += DELIMITER + coord.getValue();
			}
			client.sendMessage(msg);
			
		} else {
			//client.enforce(MAKEMOVE);
		}
		
		command = null;
	}
	*/
	
	public void signal() {
		lock.lock();
		condition.signal();
		lock.unlock();
	}
	
	public void exit() {
		this.exit = true;
		signal();
		this.client.deleteObserver(this);
		this.client = null;
		this.game = null;
	}
}
