package game.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;

import game.geometry.HyperCube;
import game.geometry.Point;
import game.logic.Game;
import game.logic.Player;
import game.network.Client;

public class ClientTUI implements View {
	
	private HyperCube cube;
	private List<String[]> commands = Collections.synchronizedList(new ArrayList<String[]>());
	private boolean exit = false;
	private String[] currentCommand;
	private Game game;
	
	public void signal() {
	}
	
	public void setGame(Game game) {
		this.game = game;
		this.cube = this.game.getHyperCube();
	}
	
	public void update(Observable o, Object obj) {
		if (o instanceof Client && obj instanceof String[]) {
			String[] meta = (String[]) obj;
			String[] command = new String[meta.length];
			for (int i = 0; i < meta.length; i++) {
				command[i] = meta[i];
			}
			commands.add(command);
		}
	}
	
	public boolean isBusy() {
		return this.currentCommand != null;
	}
	
	public void setCommand(String[] command) {
		this.currentCommand = command.clone();
	}
	
	public void run() {
		try {
		    synchronized(this) {
		        while(!exit) {
		        	if (this.commands.size() > 0) {
		        		synchronized(commands) {
							for (Iterator<String[]> it = commands.iterator(); it.hasNext();) {
								currentCommand = it.next();
								commandDeterminer();
								if (exit) {
									break;
								}
								it.remove();
							}
		        		}
		        	} else {
		        		wait(1);
		        	}
		        }
		    }
		} catch (InterruptedException e) {
		    System.out.println(e.getMessage());
		
		}
	}
	
	public void commandDeterminer() {
		switch (currentCommand[0]) {
		case PLAY:
			currentCommand[0].equals(PLAY);
			break;
		case SETMOVE:
			if (currentCommand.length > (1 + this.cube.getDimension())) {
				setMove();
			}
			break;
		case REQUESTMOVE:
			System.out.println(cube);
			break;
		case ERROR_INVALID_MOVE:
			break;
		case GAMEOVER:
			System.out.println(cube);
			exit();
			break;
		}
		this.currentCommand = null;
	}
	
	public void showWinner(Player player) {
		
	}
	
	public void setMove() {
		Player current = this.game.getPlayer(currentCommand[1]);
		Point point = new Point(cube.getDimension());
		String coords = "";
		for (int i = 2; i < currentCommand.length; i++) {
			coords += currentCommand[i] + " ";
		}
		updatePoint(point, coords);
		point = cube.getPoint(point);
		if (point == null) {
			System.out.println("Mismatch between server game and local game");
		} else {
			if (current.getCube() == null) {
				this.game.setCubes();
			}
			current.makeMove(point);
		}
		
	}
	
	public void updatePoint(Point point, String input) {
		String[] cut = input.split("[^0-9]+");
		if (cut.length == cube.getDimension()) {
			for (int i = 0; i < cube.getDimension(); i++) {
				point.getCoordinates()[i].setValue(Integer.parseInt(cut[i]));
			}
		}
	}
	
	public void exit() {
		this.exit = true;
		this.cube = null;
		this.game = null;
	}
}
