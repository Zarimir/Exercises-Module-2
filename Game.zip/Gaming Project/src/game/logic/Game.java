package game.logic;

import java.util.Observable;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.ai.ComputerPlayer;
import game.geometry.HyperCube;
import game.network.NetworkProtocol;
import game.ui.PlayerTUI;
import game.ui.View;

/**
 * The controller of the game according to the MVC model.
 * Unifies the model, view and networking aspects of the game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class Game extends Observable implements Runnable, NetworkProtocol, GameProtocol {

	public static void main(String[] args) {
		Player human = new HumanPlayer("Pesho");
		Player bot = new ComputerPlayer();
		Game game = new Game(new PlayerTUI(), 2, 3, 4);
		game.addPlayer(human);
		game.addPlayer(bot);
		game.play();
	}
	// ------------------------ Instance Variables ------------------------

    /**
     * Instance Variables.
     * @param cube of this <code>Game</code>
     * @param players of this <code>Game</code>
     * @param current the index of the current <code>Player</code>
     * @param view of this Game
     */
    //@ private invariant board != null;
	//@ private invariant (\forall int i; 0 <= i && i < NUMBER_PLAYERS; players[i] != null);
	//@ private invariant 0 <= current  && current < NUMBER_PLAYERS;
	private HyperCube cube;
	private Set<Player> players = ConcurrentHashMap.newKeySet();
    private View view;
    private static final Mark DEFAULT = Mark.XX;
    private Player currentPlayer = null;
    
    /**
     * @param gameSize how many players is this Game for
     * @param playing denotes whether players are currently playing
     * @param wait denotes whether the Game is waiting for players to notify they are ready
     * @param exit denotes whether this Game is not going to be played anymore
     */
    //@ private invariant gameSize > 0;
    private int gameSize;
    private boolean playing = false;
    private boolean wait = true;
    private boolean exit = false;

    // ------------------------ Constructor ------------------------

    //@ requires s0 != null;
    //@ requires s1 != null;
    public Game(View view, int gameSize) {
        this(view, gameSize, 3,4);
    }
    
    //@ requires dimension > 1;
    //@ requires length > 1;
    public Game(View view, int gameSize, int dimension, int length) {
    	this.gameSize = gameSize;
        cube = new HyperCube(dimension, length);
        cube.initialize();
    	this.view = view;
        this.addObserver(view);
        view.setGame(this);
        (new Thread(view)).start();
    }
    
    // ------------------------ Queries ------------------------
    
    /**
     * Gets the HyperCube of this Game.
     * @return this.cube
     */
    public HyperCube getHyperCube() {
    	return this.cube;
    }
    
    /**
     * Gets the Players list of this Game.
     * @return this.players
     */
    public Set<Player> getPlayers() {
    	return this.players;
    }
    
    @Override
    public boolean equals(Object obj) {
    	if (obj instanceof Game) {
    		Game game = (Game) obj;
    		Set<Player> myPlayers = this.getPlayers();
    		Set<Player> otherPlayers = game.getPlayers();
    		if (myPlayers != null && otherPlayers != null) {
    			return myPlayers.containsAll(otherPlayers) && otherPlayers.containsAll(myPlayers);
    		}
    	}
    	return false;
    }
    
    /**
     * Gets the availability state of this Game.
     * @return true if currentPlayer == null; false otherwise
     */
    public boolean isAvailable() {
    	return currentPlayer == null;
    }
    
    /**
     * Gets the playing state of this game.
     * @return true if this.playing == true; false otherwise
     */
    public boolean isPlayed() {
    	return this.playing;
    }
    
    /**
     * Gets the ready check state of this Game.
     * @return true if wait == true; false otherwise
     */
    public boolean waitsForCheck() {
    	return this.wait;
    }
    
    /**
     * Gets the fullness state of this Game.
     * @return this.players.size() == gameSize
     */
    public boolean isFull() {
    	return players.size() == gameSize;
    }
    
    /**
     * Gets a Player of this Game by his name.
     * @param name
     * @return Player
     */
    public Player getPlayer(String name) {
    	for (Player player : players) {
    		if (player.getName().equals(name)) {
    			return player;
    		}
    	}
    	return null;
    }
    
    /**
     * Gets a Player of this Game based on his mark.
     * @param mark
     * @return Player
     */
    public Player getPlayer(Mark mark) {
    	if (mark == null) {
    		return null;
    	} else {
    		for (Player player : players) {
    			if (player.getMark() == mark) {
    				return player;
    			}
    		}
    		return null;
    	}
    }
    
    // ------------------------ Commands ------------------------
    
    /**
     * Starts the Tic Tac Toe game. <br>
     * Asks after each ended game if the user wants to continue. Continues until
     * the user does not want to play anymore.
     */
    /*
    public void start() {
        boolean again = true;
        while (again) {
            cube.initialize();
            play();
        }
    }
    */
    
    /**
     * Sets a new value for the wait state.
     * @param state is to be the new value of this.wait
     */
    //@ ensures this.waitsForCheck() == state;
    public void setCheck(boolean state) {
    	this.wait = state;
    }
    
    /**
     * Adds new Players, then it starts and handles new Game rounds as long as players want to.
     */
    public void run() {
    	while (!exit) {
    		// While there is still room, wait for players
	    	while (!isFull() && !exit) {
	    		if (currentPlayer != null) {
		    		addPlayer(currentPlayer);
		    		currentPlayer = null;
	    		}
	    	}
	    	try {
			    synchronized(this) {
			    	// While full, make a check and play if players are ready and it is still full, otherwise kick a player
			        while(isFull() && !exit) {
			        	if (this.wait) {
			        		wait(1);
			        	} else {
			        		play();
			        		this.wait = true;
			        	}
			        }
			        checkForHumanPlayers();
			    }
			} catch (InterruptedException e) {
			    System.out.println(e.getMessage());
			    exit();
			}
    	}
    }
    


    /**
     * Plays the Tic Tac Toe game. <br>
     * First the (still empty) board is shown. Then the game is played until it
     * is over. Players can make a move one after the other. After each move,
     * the changed game situation is printed.
     */
    public void play() {
    	//Thread monitor = new Thread(view);
    	setCubes();
    	//smonitor.start();
    	cube.initialize();
    	playing = true;
    	while (!exit && isFull() && cube.getWinner() == null) {
    		
    		for (Player player : players) {
        		player.makeMove(); //update game
        		if (!isFull() || exit) {
        			break;
        		} else if (cube.getWinner() != null) {
        			view.showWinner(getPlayer(cube.getWinner()));
        			break;
        		}
    		}
    	}
    	playing = false;
    }
    
    /**
     * Sets the currentPlayer to be equal to a different value.
     * @param player is to be the new value of this.currentPlayer
     */
    //@ ensures player != null => this.isAvailable() == false;
    public void setCurrentPlayer(Player player) {
    	this.currentPlayer = player;
    }
    
    /**
     * Adds a new Player to game and assigns him automatically an unused mark, also adds him to the view.
     * @param newPlayer
     */
    public void addPlayer(Player newPlayer) {
    	if (players.size() == 0) {
    		newPlayer.setMark(DEFAULT);
    	} else {
    		newPlayer.setMark(DEFAULT.other());
    	}
    	newPlayer.addObserver(view);
    	this.setChanged();
    	this.notifyObservers(newPlayer);
    	players.add(newPlayer);
    }
    
    /**
     * Removes Player from this Game.
     * @param player
     */
    //@ ensures this.getPlayer(player.getName()) == null;
    public void removePlayer(Player player)  {
    	this.players.remove(player);
    }
    
    /**
     * Sets the same cube to all Players.
     */
    public void setCubes() {
    	for (Player player : players) {
    		player.setCube(this.cube);
    	}
    }
    
    /**
     * Notifies observers of a message.
     * @param message
     */
    public void notify(String message) {
    	this.setChanged();
    	this.notifyObservers(message);
    }
    
    /**
     * Checks whether there is at least 1 non ComputerPlayer.
     * Exits if there isn't.
     */
    public void checkForHumanPlayers() {
    	boolean onlyComputers = true;
    	for (Player player : players) {
    		if (!(player instanceof ComputerPlayer)) {
    			onlyComputers = false;
    		}
    	}
    	exit = onlyComputers;
    }
    
    /**
     * Deletes Game.
     */
    public void exit() {
    	this.exit = true;
    	this.view.exit();
    	notify(GAMEOVER);
    	this.deleteObservers();
    }
}