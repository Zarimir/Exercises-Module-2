package game.logic;

import java.util.Observable;

import game.ai.NaiveStrategy;
import game.ai.Strategy;
import game.geometry.HyperCube;
import game.geometry.Point;
import game.network.NetworkProtocol;

/**
 * Abstract class for keeping a player in the Tic Tac Toe game.
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public abstract class Player extends Observable implements NetworkProtocol, GameProtocol {
	
	// ------------------------ Instance Variables ------------------------

	/**
	 * Instance Variables.
	 * @param name of the Player
	 * @param mark of the Player
	 * @param point Point of the Player
	 * @param cube HyperCube of the player
	 * @param currentTurn boolean is true when it's this player's turn, false otherwise
	 */
    private String name;
    private Mark mark;
    private Point point;
    private HyperCube cube; 
    
    private Strategy strategy = new NaiveStrategy();
    private boolean currentTurn;
    
	// ------------------------ Constructor ------------------------
    
    /**
     * Constructs a player with a given name and mark arguments.
     * @param name of the player
     * @param mark of the player
     */
    //@ requires name != null;
    //@ requires mark == Mark.XX || mark== Mark.OO;
    //@ ensures this.getName() == name;
    //@ ensures this.getMark() == mark;
    public Player(String name) {
        this.name = name;
    }

	// ------------------------ Queries ------------------------

    /**
     * Gets the name of the player.
     * @return this.name
     */
    /*@ pure */ public String getName() {
        return name;
    }

    /**
     * Gets the mark of the player.
     * @return this.mark
     */
    /*@ pure */ public Mark getMark() {
        return mark;
    }
    
    /**
     * Gets the Point of the player.
     * @return
     */
    /*@ pure */ public Point getPoint() {
    	return this.point;
    }
    
    /**
     * Returns true if player has turn; false otherwise.
     * @return
     */
    public boolean hasTurn() {
    	return this.currentTurn;
    }
    
    /**
     * Determines the field for the next move.
     * @param board the current game board
     * @return the player's choice
     */
    //@ requires board != null && board.getWinner() == null;
    //@ ensures \result != null;
    public abstract void determinePoint();
    
	// ------------------------ Commands ------------------------
    
    /**
     * Prints a possible move to the screen.
     */
    public Point hint() {
    	return this.strategy.determineMove(this.cube);
    	//return new Point(3);
    }
    
    /**
     * Sets this player's cube.
     * @param cube
     */
    public void setCube(HyperCube cube) {
    	this.cube = cube;
    }
    
    /**
     * Assigns a mark to this player.
     * @param mark
     */
    public void setMark(Mark mark) {
    	this.mark = mark;
    }
    
    /**
     * Sets a new Point to this player.
     * @param Point
     */
    //@ ensures this.getPoint().equals(point);
    public void setPoint(Point point) {
    	this.setChanged();
    	this.notifyObservers(MAKEMOVE);
    	this.point = point;
    }
    
    /**
     * Returns a Point from the cube with the same if such points exists and is not marked already.
     * @return Point
     */
    public Point getFromCube() {
    	return cube.getPoint(point);
    }
    
    /**
     * Returns this player's cube.
     * @return this.cube
     */
    public HyperCube getCube() {
    	return this.cube;
    }
    
    public String toString() {
    	return this.name;
    }
    
    //@ requires board != null && board.getWinner() == null;
    /**
     * Makes a move on the board.
     * @param board the current board
     */
    public void makeMove() {
    	currentTurn = true;
    	determinePoint();
		cube.mark(point, this.mark);
		currentTurn = false;
    }
    
    /**
     * Makes a move with a point created from outside.
     * @param point
     */
    public void makeMove(Point point) {
    	currentTurn = true;
		cube.mark(point, this.mark);
		currentTurn = false;
    }
    
    public abstract void exit();
    
    @Override
    public boolean equals(Object obj) {
    	if (obj instanceof Player) {
    		Player player = (Player) obj;
    		return this.getName().equals(player.getName());
    	}
		return false;
    	
    }
}