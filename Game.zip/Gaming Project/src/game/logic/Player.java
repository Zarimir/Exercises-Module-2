package game.logic;

import java.util.Observable;

import game.geometry.HyperCube;
import game.geometry.Point;
import game.network.NetworkProtocol;

/**
 * Abstract class for keeping a player in the Tic Tac Toe game.
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public abstract class Player extends Observable implements NetworkProtocol, GameProtocol {
	
	// ------------------------ Instance Variables ------------------------

	/**
	 * Instance Variables.
	 * @param name of the Player
	 * @param mark of the Player
	 */
    private String name;
    private Mark mark;
    private Point point;
    private boolean currentTurn;
    private HyperCube cube; 

	// ------------------------ Constructor ------------------------
    
    /**
     * Constructs a player with a given name and mark arguments.
     * @param name of the player
     * @param mark of the player
     */
    //@ requires name != null;
    //@ requires mark == Mark.XX || mark== Mark.OO;
    //@ ensures this.getName() == name;
    //@ ensures this.getMark() == mark;
    public Player(String name) {
        this.name = name;
    }

	// ------------------------ Queries ------------------------

    /**
     * Gets the name of the player.
     * @return this.name
     */
    /*@ pure */ public String getName() {
        return name;
    }

    /**
     * Gets the mark of the player.
     * @return this.mark
     */
    /*@ pure */ public Mark getMark() {
        return mark;
    }
    
    public Point getPoint() {
    	return this.point;
    }
    
    public boolean hasTurn() {
    	return this.currentTurn;
    }
    
    /**
     * Determines the field for the next move.
     * @param board the current game board
     * @return the player's choice
     */
    //@ requires board != null && board.getWinner() == null;
    //@ ensures \result != null;
    public abstract void determinePoint();

	// ------------------------ Commands ------------------------
    
    //public abstract void constructPoint(int[] ints);
    
    public void setCube(HyperCube cube) {
    	this.cube = cube;
    }
    
    public void setMark(Mark mark) {
    	this.mark = mark;
    }
    
    public void setPoint(Point point) {
    	this.setChanged();
    	this.notifyObservers(MAKEMOVE);
    	this.point = point;
    }
    
    public Point getFromCube() {
    	return cube.getPoint(point);
    }
    
    public HyperCube getCube() {
    	return this.cube;
    }
    
    public String toString() {
    	return this.name;
    }
    
    //@ requires board != null && board.getWinner() == null;
    /**
     * Makes a move on the board.
     * @param board the current board
     */
    public void makeMove() {
    	currentTurn = true;
    	determinePoint();
		cube.mark(point, this.mark);
		currentTurn = false;
    }
    
    public void makeMove(Point point) {
    	currentTurn = true;
		cube.mark(point, this.mark);
		currentTurn = false;
    }
    
    public abstract void exit();
    
    @Override
    public boolean equals(Object obj) {
    	if (obj instanceof Player) {
    		Player player = (Player) obj;
    		return this.getName().equals(player.getName());
    	}
		return false;
    	
    }
    
    /*
    public void signalToMark() {
    	validPoint.signal();
    }
    */
}