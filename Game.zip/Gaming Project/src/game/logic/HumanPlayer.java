package game.logic;

import java.util.Scanner;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.network.NetworkProtocol;

/**
 * Class for maintaining a human player in Tic Tac Toe.
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public class HumanPlayer extends Player implements NetworkProtocol {

	public static void main(String[] args) {
		String str = "123, 1904, paosdkpao qwpoeq wpek 12 k 4";
		String[] s = str.split("[^0-9]+");
		int temp;
		for(int i = 0; i < s.length; i++) {
			temp = Integer.parseInt(s[i]);
			System.out.println(temp+1);
		}
	}
	
	private Lock lock = new ReentrantLock();
	private Condition condition = lock.newCondition();
	
	// ------------------------ Constructor ------------------------
	
	/**
     * Constructs a human player with a given name and mark.
     * @param name of the player
     * @param mark of the player
     */
    //@ requires name != null;
    //@ requires mark != null;
    //@ requires mark != Mark.EMPTY;
    //@ ensures this.getName() == name;
    //@ ensures this.getMark() == mark;
    public HumanPlayer(String name) {
        super(name);
    }

	// ------------------------ Commands ------------------------

    /**
     * Asks the user to input the field where to place the next mark. This is
     * done using the standard input/output.
     * 
     * @param board the game board
     * @return the player's chosen point
     */
    //@ requires board != null;
    //@ ensures \result != null;
    public void determinePoint() {
    	lock.lock();
    	try {
    		this.setChanged();
    		this.notifyObservers(REQUESTMOVE);
    		condition.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	lock.unlock();
    }
    	
	public void moveReady() {
		lock.lock();
		condition.signal();
		lock.unlock();
	}

    /**
     * Writes a prompt to standard out and tries to read an int value from
     * standard in. This is repeated until an int value is entered.
     * 
     * @param prompt the question to prompt the user
     * @return the first int value which is entered by the user
     */
    public int readInt(String prompt) {
        int value = 0;
        boolean intRead = false;
        @SuppressWarnings("resource")
        Scanner line = new Scanner(System.in);
        do {
            System.out.print(prompt);
            try (Scanner scannerLine = new Scanner(line.nextLine());) {
                if (scannerLine.hasNextInt()) {
                    intRead = true;
                    value = scannerLine.nextInt();
                }
            }
        } while (!intRead);
        return value;
    }
    
    public void exit() {
    	
    }
}
