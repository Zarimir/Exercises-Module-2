package game.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import game.geometry.Point;
import game.logic.Mark;

public class TestPoint {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 */
	private static final int ZERO = 0;
	private static final int DIM = 3;
	private static final int VAL = 7;

	private static final Mark EMPTY = Mark.EMPTY;
	private static final Mark NOT_EMPTY = Mark.XX;
	
	private Point point;
	private Point point1;
	
	// ------------------------ Setup ------------------------
	
	/**
	 * Sets two identical points.
	 */
	@Before
	public void setUp() {
		point = new Point(DIM);
		point1 = new Point(DIM);
	}
	
	// ------------------------ Test Queries ------------------------
	
	/**
	 * Expected to return a copy point with the same coordinates and mark,
	 * which could be modified separately from the original point.
	 */
	@Test
	public void testCopy() {
		point = new Point(DIM);
		point1 = null;
		point.setMark(NOT_EMPTY);
		assertEquals(false, point.equals(point1));
		
		point1 = point.copy();
		assertEquals(true, point.equals(point1));
		
		point1.getCoordinates()[ZERO].setValue(VAL);
		assertEquals(false, point.equals(point1));
		
		assertEquals(true, point.getMark() == point1.getMark());
		point1.setMark(EMPTY);
		assertEquals(false, point.getMark() == point1.getMark());
	}
	
	/**
	 * Expected to return true if two points have equal coordinates.
	 */
	@Test
	public void testEquals() {
		assertEquals(true, point.equals(point1));
		
		point1.setMark(NOT_EMPTY);
		assertEquals(true, point.equals(point1));
		
		point1.getCoordinates()[ZERO].setValue(VAL);
		assertEquals(false, point.equals(point1));
		
		point.getCoordinates()[ZERO].setValue(VAL);
		assertEquals(true, point.equals(point1));	
	}
	
	// ------------------------ Test Commands ------------------------
	
	/**
	 * Expected to change the mark of a point.
	 */
	@Test
	public void testSetMark() {
		assertEquals(EMPTY, point.getMark());
		
		point.setMark(NOT_EMPTY);
		assertEquals(NOT_EMPTY, point.getMark());
	}
	
	// ------------------------ Test Static Commands ------------------------
	
	/**
	 * Expected to return a copy point list with the same points, coordinates and mark,
	 * which could be modified separately from the original point list.
	 */
	@Test
	public void testPointCopy() {
		Point[] points = {point, point1};
		point.setMark(NOT_EMPTY);
		Point[] copies = Point.copy(points);
		
		assertEquals(true, point.getMark() == copies[ZERO].getMark());
		
		point.setMark(EMPTY);
		for (int i = 0; i < points.length; i++) {
			assertEquals(true, points[i].equals(copies[i]));
		}
		
		assertEquals(true, point.equals(copies[ZERO]));
		
		point.getCoordinates()[ZERO].setValue(VAL);
		assertEquals(false, point.equals(copies[ZERO]));
	}
}