package game.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import game.geometry.HyperCube;
import game.geometry.Line;
import game.geometry.Point;
import game.logic.Mark;

public class TestHyperCube {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 */
	private static final int ZERO = 0;
	private static final int DIM = 3;
	private static final int LENGTH = 4;
	private static final int VAL = 7;
	
	private static final Mark EMPTY = Mark.EMPTY;
	private static final Mark NOT_EMPTY = Mark.XX;
	
	
	private HyperCube cube;
	private HyperCube cube1;
	
	// ------------------------ Setup ------------------------
	
	/**
	 * Sets two identical cubes and initializes them.
	 */
	@Before
	public void setUp() {
		cube = new HyperCube(DIM, LENGTH);
		cube1 = new HyperCube(DIM, LENGTH);
		cube.initialize();
		cube1.initialize();
	}
	
	// ------------------------ Test Queries ------------------------
	
	/**
	 * Expected to return a copy HyperCube containing copies of
	 * all the metaPoints and metaLines of the original HyperCube.
	 * It is also expected that the new HyerCube could be modified separately.
	 */
	@Test
	public void testCopy() {
		cube1 = null;
		cube1 = cube.copy();
		cube.initializeValidLines();
		assertEquals(true, cube.equals(cube1));
		
		cube1.getPoints().get(ZERO).setMark(NOT_EMPTY);
		assertEquals(false, cube.equals(cube1));
		
		cube1.getPoints().get(ZERO).setMark(EMPTY);
		assertEquals(true, cube.equals(cube1));
		
		cube1.getValidLines().remove(ZERO);
		assertEquals(false, cube.equals(cube1));
		
		cube1.initialize();
		for (int i = 0; i < cube.getPoints().size(); i++) {
			assertEquals(true,
					cube.getPoints().get(i).equals(cube1.getPoints().get(i)));
		}
		
		for (int i = 0; i < cube.getLines().size(); i++) {
			assertEquals(true,
					cube.getLines().get(i).equals(cube1.getLines().get(i)));
		}
	}
	
	/**
	 * Expected to return a point from the cube with the same coordinates as a point argument.
	 * Expected to return null if the point is not empty or is not from the cube.
	 */
	@Test
	public void testGetPoint() {
		Point choice = null;
		assertEquals(null, cube.getPoint(choice));
		
		Point target = cube.getPoints().get(ZERO);
		choice = target.copy();
		choice.setMark(EMPTY);
		Point found = cube.getPoint(choice);
		assertEquals(true, choice.equals(found));
		
		choice.setMark(NOT_EMPTY);
		target.setMark(NOT_EMPTY.other());
		found = cube.getPoint(choice);
		assertEquals(null, found);
		
		target.setMark(EMPTY);
		found = cube.getPoint(choice);
		assertEquals(true, found.equals(target) &&
				found.getMark() == target.getMark());
		
		int index = -VAL;
		found = cube.getPoint(index);
		assertEquals(null, found);
		
		index = cube.getPoints().size();
		found = cube.getPoint(index);
		assertEquals(null, found);
		
		for (int i = 0; i < LENGTH * LENGTH; i++) {
			index = i;
			target = cube.getPoints().get(index);
			found = cube.getPoint(index);
			assertEquals(true, found.equals(target) &&
					found.getMark() == target.getMark());
		}
	}
	
	/**
	 * Expected to return true if the lines are of equal length and all their points are equal
	 * as well as all the marks are equal.
	 * Expected to return false otherwise.
	 */
	@Test
	public void testEquals() {
		cube1 = cube.copy();
		cube.initializeValidLines();
		Point point1 = cube1.getPoints().get(ZERO);
		assertEquals(true, cube.equals(cube1));
		 
		point1.setMark(NOT_EMPTY);
		assertEquals(false, cube.equals(cube1));
		
		point1.setMark(EMPTY);
		assertEquals(true, cube.equals(cube1));
		
		point1.getCoordinates()[ZERO].setValue(VAL * VAL);
		assertEquals(false, cube.equals(cube1));
	}
	
	// ------------------------ Test Commands ------------------------
	
	/**
	 * Tests whether Synchronize method actually sets the Points of each Line in the list of Lines to be a pointer to the same address to its
	 * equivalent Point in the list of Points. The idea is that once you change a Point it is automatically updated for all lines, even though
	 * the lines were constructed with different points initially.
	 */
	@Test
	public void testSynchronize() {
		Point target = cube.getPoints().get(ZERO);
		cube.mark(target, NOT_EMPTY);
		assertEquals(true, cube.getPoints().get(ZERO).getMark() == NOT_EMPTY);
		
		boolean check = false;
		Point current;
		for (Line line : cube.getLines()) {
			current = line.getPoint(target);
			if (current != null) {
				assertEquals(true, current.getMark() == NOT_EMPTY);
				check = true;
			}
		}
		assertEquals(true, check);
	}
	
	/**
	 * Expected to reset the metaPoints and metaLines of a cube,
	 * by making a copy from points and lines ArrayLists.
	 * Expected to also copy the point marks.
	 */
	@Test
	public void testInitialize() {
		cube.setParameter(null, null);
		assertEquals(true, cube.getPoints().size() == ZERO);
		assertEquals(true, cube.getLines().size() == ZERO);
		
		Point point;
		Point metaPoint;
		cube.initialize();
		for (int i = 0; i < cube.getLines().size(); i++) {
			if (i < cube.getPoints().size()) {
				point = cube.getPoints().get(i);
				metaPoint = cube.getPoints().get(i);
				
				assertEquals(true, point.equals(metaPoint));
				assertEquals(true, point.getMark() == metaPoint.getMark());
			}
			assertEquals(true, cube.getLines().get(i).equals(cube.getLines().get(i)));
		}
	}
	
	/**
	 * Expected to makes copies of given ArrayLists of points and lines,
	 * and sets the metaPoints and metaLines to be equal to these copies.
	 * Expected to also copy the point marks.
	 */
	@Test
	public void testSetStatus() {
		cube.setParameter(null, null);
		assertEquals(true, cube.getPoints().size() == ZERO);
		assertEquals(true, cube.getLines().size() == ZERO);
		
		cube.setParameter(cube.getPoints(), cube.getLines());
		
		Point point;
		Point metaPoint;
		for (int i = 0; i < cube.getLines().size(); i++) {
			if (i < cube.getPoints().size()) {
				point = cube.getPoints().get(i);
				metaPoint = cube.getPoints().get(i);
				
				assertEquals(true, point.equals(metaPoint));
				assertEquals(true, point.getMark() == metaPoint.getMark());
			}
			assertEquals(true, cube.getLines().get(i).equals(cube.getLines().get(i)));
		}
	}
	
	/**
	 * Expected to mark a point from the cube given as an argument
	 * with a mark which is also an argument.
	 * Expected to mark it only if the point is not already marked.
	 */
	@Test
	public void testMark() {
		List<Line> newMetaLines = new ArrayList<Line>();
		newMetaLines.add(cube.getLines().get(ZERO));
		//Set<Integer> validLines = new HashSet<Integer>();
		cube.setParameter(cube.getPoints(), newMetaLines);
		cube.initialize();
		assertEquals(true, cube.getLines().size() == VAL / VAL);
		
		Point target = cube.getLines().get(ZERO).getPoints()[ZERO];
		Point choice = cube.getPoint(target.copy());
		assertEquals(true, choice != null);
		
		cube.mark(choice, null);
		assertEquals(true, target.getMark() == EMPTY);
		
		cube.mark(choice, EMPTY);
		assertEquals(true, target.getMark() == EMPTY);
		
		cube.mark(choice, NOT_EMPTY);
		assertEquals(true, target.getMark() == NOT_EMPTY);
		
		cube.mark(choice, null);
		assertEquals(true, target.getMark() == NOT_EMPTY);
		
		cube.mark(choice, EMPTY);
		assertEquals(true, target.getMark() == NOT_EMPTY);
		
		cube.mark(choice, NOT_EMPTY.other());
		assertEquals(true, target.getMark() == NOT_EMPTY);
		
		target.setMark(EMPTY);
		cube = cube1.copy();
		for (int i = 0; i < LENGTH; i++) {
			assertEquals(null, cube.getWinner());
			target = cube.getPoints().get(i * LENGTH * LENGTH);
			choice = cube.getPoint(ZERO);
			cube.mark(choice, NOT_EMPTY);
			assertEquals(true, choice.equals(target));
			assertEquals(true, target.getMark() == NOT_EMPTY);
		}
		assertEquals(NOT_EMPTY, cube.getWinner());
	}
	
	/**
	 * Expected to update the list of metaLines depending on the new move.
	 * Expected to remove a line from metaLines if it has 2 or more points owned by different players.
	 * Expected to set winner = mark if there is a winner.
	 * Expected to set winner = Mark.EMPTY if there aren't any relevant lines left.
	 */
	@Test
	public void testUpdateLines() {
		List<Line> newMetaLines = new ArrayList<Line>();
		newMetaLines.add(cube.getLines().get(ZERO));
		cube.setParameter(cube.getPoints(), newMetaLines);
		assertEquals(true, cube.getLines().size() == VAL / VAL);
		assertEquals(null, cube.getWinner());
		
		Point[] points = cube.getLines().get(ZERO).getPoints();
		Point target;
		Point choice;
		for (int i = 0; i < points.length - 1; i++) {
			target = points[i];
			choice = cube.getPoint(target.copy());
			cube.mark(choice, NOT_EMPTY);
			assertEquals(null, cube.getWinner());
		}
		
		target = points[points.length - 1];
		choice = cube.getPoint(target.copy());
		cube.mark(choice, NOT_EMPTY);
		assertEquals(NOT_EMPTY, cube.getWinner());
		
		cube.initialize();
		cube.setParameter(cube.getPoints(), newMetaLines);
		assertEquals(VAL / VAL, cube.getLines().size());
		assertEquals(null, cube.getWinner());
		
		target = points[ZERO];
		choice = cube.getPoint(target.copy());
		cube.mark(choice, NOT_EMPTY);
		assertEquals(null, cube.getWinner());
		
		target = points[VAL/VAL];
		choice = cube.getPoint(target.copy());
		cube.mark(choice, NOT_EMPTY.other());
		assertEquals(ZERO, cube.getValidLines().size());
		assertEquals(EMPTY, cube.getWinner());
	}
	
	// ------------------------ Test Static Commands ------------------------
	
	/**
	 * Expected to make a complete copy of an ArrayList of points.
	 * Expected to also copy the marks.
	 */
	@Test
	public void testHyperCubeCopyPoints() {
		List<Point> points = new ArrayList<Point>();
		List<Point> points1 = new ArrayList<Point>();
		
		assertEquals(true, points.size() == ZERO);
		assertEquals(true, points1.size() == ZERO);
		
		points1.add(new Point(DIM));
		assertEquals(true, points.size() == ZERO);
		assertEquals(false, points1.size() == ZERO);
		
		points1 = HyperCube.copyPoints(points);
		assertEquals(true, points.size() == ZERO);
		assertEquals(true, points1.size() == ZERO);
		
		points1.add(new Point(DIM));
		points.add(new Point(VAL));
		points1.get(ZERO).setMark(NOT_EMPTY);
		points = HyperCube.copyPoints(points1);
		
		assertEquals(true, points.size() == points1.size());
		for (int i = 0; i < points.size(); i++) {
			assertEquals(true, points.get(i).equals(points1.get(i)));
			assertEquals(true, points.get(i).getMark() == points1.get(i).getMark());
		}
		
		points1.get(ZERO).getCoordinates()[ZERO].setValue(VAL);
		assertEquals(false, points.get(ZERO).equals(points1.get(ZERO)));
	}
	
	/**
	 * Expected to make a complete copy of an ArrayList of lines.
	 * Expected to also copy the point marks.
	 */
	@Test
	public void testHyperCubeCopyLines() {
		List<Line> lines = new ArrayList<Line>();
		List<Line> lines1 = new ArrayList<Line>();
		
		assertEquals(true, lines.size() == ZERO);
		assertEquals(true, lines.size() == ZERO);
		
		lines1.add(new Line(DIM, LENGTH));
		assertEquals(true, lines.size() == ZERO);
		assertEquals(false, lines1.size() == ZERO);
		
		lines1 = HyperCube.copyLines(lines);
		assertEquals(true, lines.size() == ZERO);
		assertEquals(true, lines1.size() == ZERO);
		
		lines1.add(new Line(DIM, LENGTH));
		lines.add(new Line(VAL, LENGTH));
		lines1.get(ZERO).getPoints()[ZERO].setMark(NOT_EMPTY);
		lines = HyperCube.copyLines(lines1);
		
		assertEquals(true, lines.size() == lines1.size());
		for (int i = 0; i < lines.size(); i++) {
			assertEquals(true, lines.get(i).equals(lines1.get(i)));
			assertEquals(true,
					lines.get(i).getPoints()[ZERO].getMark() == lines1.get(i).getPoints()[ZERO].getMark());
		}
		
		lines1.get(ZERO).getPoints()[ZERO].getCoordinates()[ZERO].setValue(VAL);
		assertEquals(false,
				lines.get(ZERO).getPoints()[ZERO].equals(lines1.get(ZERO).getPoints()[ZERO]));
	}
}