/**
 * 
 */
package ss.week7.threads;

/**
 * @author Zarimir
 * @version 3.0
 */
public class SynchronizedIntCell implements IntCell {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	private int value = 0;

	public void setValue(int valueArg) {
		this.value = valueArg;
	}

	public int getValue() {
		return value;
	}
	
}
