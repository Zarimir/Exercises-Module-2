/**
 * 
 */
package ss.week7.threads;

import java.util.Scanner;

/**
 * @author Zarimir
 * @version 3.0
 */
public class TestConsole extends Thread {
	
	public static void main(String[] args) {
		Thread obj1 = new TestConsole("Thread 1");
		Thread obj2 = new TestConsole("Thread 2");
		Thread obj3 = new TestConsole("Thread 3");
		obj1.start();
		obj2.start();
		obj3.start();
	}
	
	private String name;
	
	public TestConsole(String n) {
		super(n);
		System.out.println(this.getName());
	}
	
	public void run() {
		this.sum();
	}
	
	private void sum() {
		Scanner in = new Scanner(System.in);
		//int num1 = Integer.parseInt(choice);
		//int num2 = Integer.parseInt(choice);
		int num1 = Console.readInt("First number: ");
		//System.out.println("Num1 is : " + num1);
		int num2 = Console.readInt("Second number: ");
		String s = num1 + " + " + num2 + " = " + (num1 + num2);
		Console.println(s);
		
	}
}
