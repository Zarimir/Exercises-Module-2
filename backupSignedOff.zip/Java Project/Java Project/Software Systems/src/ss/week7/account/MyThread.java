/**
 * 
 */
package ss.week7.account;

import java.util.concurrent.locks.ReentrantLock;

/**
 * @author Hendrike
 *
 */
public class MyThread extends Thread {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	private double theAmount;
	private int theFrequency;
	private Account theAccount;
	ReentrantLock lock = new ReentrantLock();
	
	public MyThread(double amount, int frequency, Account account, String n) {
		super(n);
		this.theAmount = amount;
		this.theFrequency = frequency;
		this.theAccount = account;
	}
	
	public void run() {
		lock.lock();
		this.transact();
		lock.unlock();
	}
	
	public void transact() {
		for (int i = 0; i < this.theFrequency; i++) {
			System.out.println(this.getName() + this.lock.isHeldByCurrentThread());
			this.theAccount.transaction(theAmount);
		}
	}
}
