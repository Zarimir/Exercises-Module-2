/**
 * 
 */
package ss.week6;

/**
 * @author Zarimir
 * @version 3.0
 */
public class TooFewArgumentsException extends WrongArgumentException {
	private final String MESSAGE = "error: must pass two command line arguments";
	
	public TooFewArgumentsException () {
		super("error: must pass two command line arguments");
	}
}
