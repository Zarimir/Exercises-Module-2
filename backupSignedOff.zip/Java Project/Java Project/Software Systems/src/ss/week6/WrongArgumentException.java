/**
 * 
 */
package ss.week6;

/**
 * @author Zarimir
 * @version 3.0
 */
public class WrongArgumentException extends Exception {
	public WrongArgumentException() {
		
	}
	public WrongArgumentException(String msg) {
		super(msg);
	}
}
