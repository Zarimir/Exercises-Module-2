/**
 * 
 */
package ss.week6.voteMachine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;
import java.util.Set;

//------------------------  ------------------------

/**
 * @author Zarimir
 * @version 3.0
 */
public class PartyList extends Observable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	// ------------------------ Instance Variables ------------------------
	
	private Set<String> parties;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Constructor, initializes new HashSet<String>;
	 */
	public PartyList() {
		 this.parties = new HashSet<String>();
	}
	
	public String toString() {
		String result = "";
		for (String p : this.parties) {
			result += p + "\n";
		}
		return result;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Get all the parties query.
	 * @return ArrayList<String>
	 */
	public List<String> getParties() {
		List<String> result = new ArrayList<String>();
		for (String s : this.parties) {
			result.add(s);
		}
		return result;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Adds a new party to the set.
	 * @param p String party
	 */
	public void addParty(String p) {
		this.parties.add(p);
		this.setChanged();
		this.notifyObservers("party");
	}
	
	/**
	 * Checks whether a party is in the set.
	 * @param p String party
	 * @return boolean
	 */
	public boolean hasParty(String p) {
		Iterator<String> i = this.parties.iterator();
		while (i.hasNext()) {
			if (i.next().equals(p)) {
				return true;
			}
		}
		return false;
	}
}
