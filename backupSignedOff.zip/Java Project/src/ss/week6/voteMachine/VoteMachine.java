/**
 * 
 */
package ss.week6.voteMachine;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import ss.week6.voteMachine.gui.VoteGUIView;

/**
 * @author Zarimir
 * @version 3.0
 */
public class VoteMachine {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VoteMachine machine = new VoteMachine();
		machine.start();
	}
	
	// ------------------------ Instance Variables ------------------------
	
	private PartyList parties;
	private VoteList votes;
	private List<String> errors;
	private VoteView view;
	private final String ERR_PARTYALREADYEXISTS = "ERROR! The following party already exists -> ";
	
	
	// ------------------------ Constructor ------------------------
	
	public VoteMachine() {
		this.parties = new PartyList();
		this.votes = new VoteList();
		this.errors = new ArrayList<String>();
		this.view = new VoteTUIView(this);
		//this.view = new VoteGUIView(this);
		//this.start();
		this.parties.addObserver(this.view);
		this.votes.addObserver(this.view);
		
	}
	
	// ------------------------ Queries ------------------------
	
	public List<String> getParties() {
		//return this.parties;
		return this.parties.getParties();
	}
	
	public Map<String, Integer> getVotes() {
		//return this.votes;
		return this.votes.getVotes();
	}
	
	// ------------------------ Commands ------------------------

	public void addParty(String party) {
		if (!this.parties.hasParty(party)) {
			this.parties.addParty(party);
		} else {
			errors.add(ERR_PARTYALREADYEXISTS + party);
		}
	}
	
	public void vote(String party) {
		this.votes.addVote(party);
	}
	
	public void start() {
		this.view.start();
	}

}
