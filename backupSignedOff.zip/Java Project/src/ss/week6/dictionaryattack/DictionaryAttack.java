package ss.week6.dictionaryattack;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class DictionaryAttack {
	
	private Map<String, String> passwordMap;
	private Map<String, String> hashDictionary;

	public DictionaryAttack() {
		this.passwordMap = new HashMap<String, String>();
		this.hashDictionary = new HashMap<String, String>();
	}
	
	/**
	 * Reads a password file. Each line of the password file has the form:
	 * username: encodedpassword
	 * 
	 * After calling this method, the passwordMap class variable should be
	 * filled withthe content of the file. The key for the map should be
	 * the username, and the password hash should be the content.
	 * @param filename
	 */
	public void readPasswords(String filename) throws IOException {
		// To implement
		try (BufferedReader in = new BufferedReader(new FileReader(filename))) {
			while(in.ready()) {
				String line = in.readLine();
				//System.out.println(line);
				String u = line.split(": ")[0];
				String p = line.split(": ")[1];
				this.passwordMap.put(u, p);
				/*
				String username = line.split(": ")[0];
				String password = line.split(": ")[1];
				System.out.println(username + " : " + password);
				this.passwordMap.put(username, password);
				System.out.println("What is happening !?");
				*/
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		
	}

	/**
	 * Given a password, return the MD5 hash of a password. The resulting
	 * hash (or sometimes called digest) should be hex-encoded in a String.
	 * @param password
	 * @return
	 */
	public String getPasswordHash(String password) {
    	// To implement
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			md.reset();
			byte[] messageBytes = password.getBytes("UTF-8");
			byte[] digest = md.digest(messageBytes);
			BigInteger bigInt = new BigInteger(1, digest);
			String hashtext = bigInt.toString(16);
			return hashtext;
		} catch (NoSuchAlgorithmException e) {
			System.out.println("Myerror");
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println("Myerror");
			System.out.println(e.getMessage());
		}
    	return null;
	}
	/**
	 * Checks the password for the user the password list. If the user
	 * does not exist, returns false.
	 * @param user
	 * @param password
	 * @return whether the password for that user was correct.
	 */
	public boolean checkPassword(String user, String password) {
        //System.out.println("What is going on?");
		// To implement
		if (user == null || password == null || !this.passwordMap.containsKey(user)) {
			return false;
		}
		String attempt = this.getPasswordHash(password);
		String realPass = this.passwordMap.get(user);
		return attempt.equals(realPass);
	}

	/**
	 * Reads a dictionary from file (one line per word) and use it to add
	 * entries to a dictionary that maps password hashes (hex-encoded) to
     * the original password.
	 * @param filename filename of the dictionary.
	 */
    public void addToHashDictionary(String filename) throws IOException {
        // To implement
		try (BufferedReader in = new BufferedReader(new FileReader(filename))) {
			while(in.ready()) {
				String pass = in.readLine();
				//System.out.println(line);
				String hash = this.getPasswordHash(pass);
				this.hashDictionary.put(hash, pass);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
    }
	/**
	 * Do the dictionary attack.
	 */
	public void doDictionaryAttack() {
		// To implement
		for (Map.Entry<String, String> e : this.passwordMap.entrySet()) {
			for (Map.Entry<String, String> p : this.hashDictionary.entrySet()) {
				if (e.getValue().equals(p.getKey())) {
					System.out.println(e.getKey() + " : " + p.getValue());
				}
			}
		}
		System.out.println("Done!");
	}
	public static void main(String[] args) {
		DictionaryAttack da = new DictionaryAttack();
		// To implement
		String pathDict = 
				"C:\\Users\\Zarry\\workspace\\Java Project\\Software Systems\\bin\\ss\\week6\\test\\Dict.txt";
		String pathLeak = 
				
				"C:\\Users\\Zarry\\workspace\\Java Project\\Software Systems\\bin\\ss\\week6\\test\\LeakedPasswords.txt";
		try {
			da.readPasswords(pathLeak);
			//System.out.println("Wat");
			da.addToHashDictionary(pathDict);
			da.doDictionaryAttack();
		} catch (Exception e) {
			System.out.println("Hello");
			System.out.println(e.getMessage());
		}
	}
	
	public String toString() {
		String result = "";
		for (Map.Entry<String, String> e : this.passwordMap.entrySet()) {
			result += e.getKey() + " : " + e.getValue() + "\n";
		}
		
		return result;
	}

}
