package game.network.exception;

import game.network.NetworkProtocol;

public class UsernameTakenException extends Exception implements NetworkProtocol {
	/**
	 * 
	 */
	private static final long serialVersionUID = 93872506521032913L;

	public UsernameTakenException() {
		super(ERROR_USERNAME_TAKEN);
	}
}
