package game.network.exception;

import game.network.NetworkProtocol;

public class UnexpectedException extends Exception implements NetworkProtocol {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2504546100615753987L;

	public UnexpectedException() {
		super(ERROR_UNEXPECTED);
	}
}
