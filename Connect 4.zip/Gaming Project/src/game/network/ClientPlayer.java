package game.network;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.logic.Player;

public class ClientPlayer extends Player {
	private Client client;
	private Lock lock = new ReentrantLock();
	private Condition condition = lock.newCondition();
	
	public ClientPlayer(Client client, String name) {
		super(name);
		this.client = client;
	}
	
	public void determinePoint() {
		lock.lock();
		try {
			condition.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		lock.unlock();
	}
	
	public void signalPointDetermined() {
		this.lock.lock();
		this.condition.signal();
		this.lock.unlock();
	}
	
	public void exit() {
		
	}
}
