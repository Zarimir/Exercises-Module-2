package game.ui;

import java.util.Observer;

import game.logic.Game;
import game.logic.Player;
import game.network.NetworkProtocol;

public interface View extends NetworkProtocol, Observer, Runnable {
    //public void start();
    public void showWinner(Player mark);
    public void signal();
    public void exit();
    public void setGame(Game game);
}