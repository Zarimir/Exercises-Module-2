package game.logic;

import java.util.Observable;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.ai.ComputerPlayer;
import game.geometry.HyperCube;
import game.network.NetworkProtocol;
import game.ui.PlayerTUI;
import game.ui.View;

/**
 * The controller of the game according to the MVC model.
 * Unifies the model, view and networking aspects of the game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class Game extends Observable implements Runnable, NetworkProtocol, GameProtocol {

	public static void main(String[] args) {
		Player human = new HumanPlayer("Pesho");
		Player bot = new ComputerPlayer();
		Game game = new Game(new PlayerTUI(), 2, 3, 4);
		game.addPlayer(human);
		game.addPlayer(bot);
		game.play();
	}
	// ------------------------ Instance Variables ------------------------

    /**
     * Instance Variables.
     * @param cube of this <code>Game</code>
     * @param platers of this <code>Game</code>
     * @param current the index of the current <code>Player</code>
     */
    //@ private invariant board != null;
	//@ private invariant (\forall int i; 0 <= i && i < NUMBER_PLAYERS; players[i] != null);
	//@ private invariant 0 <= current  && current < NUMBER_PLAYERS;
	private HyperCube cube;
	private Set<Player> players = ConcurrentHashMap.newKeySet();
    private View view;
    private static final Mark DEFAULT = Mark.XX;
    private Player currentPlayer = null;
    private boolean exit = false;
    private int gameSize;
    private boolean on = false;
    private Lock lock = new ReentrantLock();
    private Condition condition = lock.newCondition();

    // ------------------------ Constructor ------------------------

    //@ requires s0 != null;
    //@ requires s1 != null;
    public Game(View view, int gameSize) {
        this(view, gameSize, 3,4);
    }
    
    //@ requires dimension > 1;
    //@ requires length > 1;
    public Game(View view, int gameSize, int dimension, int length) {
    	this.gameSize = gameSize;
    	this.view = view;
        this.addObserver(view);
        view.setGame(this);
        (new Thread(view)).start();
        cube = new HyperCube(dimension, length);
        cube.initialize();
    }
    
    // ------------------------ Queries ------------------------
    
    public HyperCube getHyperCube() {
    	return this.cube;
    }
    
    public Set<Player> getPlayers() {
    	return this.players;
    }
    
    @Override
    public boolean equals(Object obj) {
    	if (obj instanceof Game) {
    		Game game = (Game) obj;
    		Set<Player> myPlayers = this.getPlayers();
    		Set<Player> otherPlayers = game.getPlayers();
    		if (myPlayers != null && otherPlayers != null) {
    			return myPlayers.containsAll(otherPlayers) && otherPlayers.containsAll(myPlayers);
    		}
    	}
    	return false;
    }
    
    // ------------------------ Commands ------------------------
    
    /**
     * Starts the Tic Tac Toe game. <br>
     * Asks after each ended game if the user wants to continue. Continues until
     * the user does not want to play anymore.
     */
    /*
    public void start() {
        boolean again = true;
        while (again) {
            cube.initialize();
            play();
        }
    }
    */
    
    public void signal() {
    	lock.lock();
    	condition.signal();
    	lock.unlock();
    }
    
    public void run() {
    	while (!exit) {
	    	while (!isFull()) {
	    		if (currentPlayer != null) {
		    		addPlayer(currentPlayer);
		    		currentPlayer = null;
			    	setChanged();
			    	notifyObservers(ACCEPT);
	    		}
	    	}
	    	while (isFull()) {
	    		notify(READY);
		    	lock.lock();
		    	try {
					condition.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		    	lock.unlock();
		    	if (isFull()) {
					play();
				}
	    	}
	    	if (exit) {
	    		break;
	    	}
    	}
    	
    }
    
    public boolean isFull() {
    	return players.size() == gameSize;
    }

    /**
     * Plays the Tic Tac Toe game. <br>
     * First the (still empty) board is shown. Then the game is played until it
     * is over. Players can make a move one after the other. After each move,
     * the changed game situation is printed.
     */
    public void play() {
    	//Thread monitor = new Thread(view);
    	setCubes();
    	//smonitor.start();
    	//System.out.println("START");
    	cube.initialize();
    	on = true;
    	while (isFull() && cube.getWinner() == null) {
    		
    		for (Player player : players) {
        		player.makeMove(); //update game
        		if (!isFull()) {
        			break;
        		} else if (cube.getWinner() != null) {
        			view.showWinner(getPlayer(cube.getWinner()));
        			break;
        		}
    		}
    	}
    	on = false;
    }
    
    public void setCurrentPlayer(Player player) {
    	this.currentPlayer = player;
    }
    
    public void addPlayer(Player newPlayer) {
    	if (players.size() == 0) {
    		newPlayer.setMark(DEFAULT);
    	} else {
    		newPlayer.setMark(DEFAULT.other());
    	}
    	newPlayer.addObserver(view);
    	this.setChanged();
    	this.notifyObservers(newPlayer);
    	players.add(newPlayer);
    }
    
    public void removePlayer(Player player)  {
    	this.players.remove(player);
    }
    
    public void setCubes() {
    	for (Player player : players) {
    		player.setCube(this.cube);
    	}
    }
    
    public Player getPlayer(Mark mark) {
    	if (mark == null) {
    		return null;
    	} else {
    		for (Player player : players) {
    			if (player.getMark() == mark) {
    				return player;
    			}
    		}
    		return null;
    	}
    }
    
    public boolean isAvailable() {
    	return currentPlayer == null;
    }
    
    public void notify(String message) {
    	this.setChanged();
    	this.notifyObservers(message);
    }
    
    public void exit() {
    	this.exit = true;
    	this.signal();
    	this.view.exit();
    	this.players = null;
    	this.cube = null;
    	this.setChanged();
    }
    
    public boolean isPlayed() {
    	return this.on;
    }
}