package junk;

/**
 * Executable class for the game Tic Tac Toe. The game can be played against the
 * computer. Lab assignment Module 2
 * 
 * @author Theo Ruys
 * @version $Revision: 1.4 $
 */
public class TicTacToe {
    public static void main(String[] args) {
        // TODO: implement, see P-4.21
    	Player[] players;
    	int min = args.length;
    	if (min > 2) {
    		min = 2;
    	}
    	players = new Player[2];
    	if (args.length >= 2) {
	    	players[0] = new HumanPlayer(args[0], Mark.OO);
	    	players[1] = new HumanPlayer(args[1], Mark.XX);
    	} else {
    		players[0] = new HumanPlayer("Test1", Mark.OO);
	    	players[1] = new HumanPlayer("Test2", Mark.XX);
    	}
    	Game game = new Game(players[0], players[1]);
    	game.start();
    }
}
