/**
 * 
 */
package junk;

import java.util.ArrayList;
import java.util.List;


/**
 * @author Zarry
 *
 */
public class SmartStrategy implements Strategy {
	private final String NAME = "Smart";
	private Board board;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	/**
	 * Naive strategy.
	 * @return "Smart"
	 */
	public String getName() {
		return this.NAME;
	}
	
	/**
	 * Determines the next legal move.
	 */
	public int determineMove(Board b, Mark m) {
		// If the middle is empty, choose it
		if (b.isEmptyField(4)) {
			return 4;
		}
		
		// initialize values
		this.board = b.deepCopy();
		Mark enemyMark = null;
		int index;
		List<Integer> emptyFields = new ArrayList<Integer>();
		
		// store empty fields indexes
		for (int i = 0; i < Board.DIM * Board.DIM; i++) {
			if (this.board.isEmptyField(i)) {
				emptyFields.add(i);
			} else if (enemyMark == null && !this.board.getField(i).equals(m)) {
				// fetch enemy mark
				enemyMark = this.board.getField(i);
			}
		}
		
		// if there is a winning move, place mark there
		for (int i = 0; i < emptyFields.size(); i++) {
			index = emptyFields.get(i);
			this.board.setField(emptyFields.get(i), m);
			if (this.board.hasWinner()) {
				this.board.setField(index, Mark.EMPTY);
				return emptyFields.get(i);
			}
			this.board.setField(index, Mark.EMPTY);
		}
		
		// if the enemy has a winning move, place mark there
		if (enemyMark != null) {
			for (int i = 0; i < emptyFields.size(); i++) {
				index = emptyFields.get(i);
				this.board.setField(index, enemyMark);
				if (this.board.hasWinner()) {
					this.board.setField(index, Mark.EMPTY);
					return emptyFields.get(i);
				}
				this.board.setField(index, Mark.EMPTY);
			}
		}
		
		// else make a random move
		index = (int) (Math.random() * (emptyFields.size()));
		index = emptyFields.get(index);
		return index;
	}

}
