/**
 * 
 */
package junk;
import java.util.Set;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.List;
/**
 * @author Zarry
 * @version 3.0
 */
public class NaiveStrategy implements Strategy {

	private final String NAME = "Naive";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
	
	/**
	 * Naive strategy.
	 * @return "Naive"
	 */
	public String getName() {
		return this.NAME;
	}
	
	/**
	 * Determines the next legal move.
	 */
	public int determineMove(Board b, Mark m) {
		List<Integer> emptyFields = new ArrayList<Integer>();
		for (int i = 0; i < Board.DIM * Board.DIM; i++) {
			if (b.isEmptyField(i)) {
				emptyFields.add(i);
			}
		}
		int random = (int) (Math.random() * (emptyFields.size()));
		
		return emptyFields.get(random);
	}
}
