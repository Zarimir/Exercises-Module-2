package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import game.Coordinate;
import game.HyperCube;
import game.Point;
import game.Math;

public class testPoint {
	private Point point;
	private Point point1;
	private HyperCube cube;
	private HyperCube cube1;
	private Point[] points;
	private Point[] points1;
	private static final int DIM = 3;
	private static final int VAL = 7;
	private static final int[] INTS = {5,3,7,5};
	private static final int[] INTS1 = {3,3,4,2};
	private static final Coordinate[] COORDINATE_VECTOR = Coordinate.extractCoordinates(INTS);
	private static final Coordinate[] COORDINATE_VECTOR1 = Coordinate.extractCoordinates(INTS1);
	
	
	@Before
	public void setUp() {
		this.cube = new HyperCube(DIM, DIM);
		this.cube1 = new HyperCube(DIM + DIM / DIM, DIM * DIM);
		this.point = new Point(cube, COORDINATE_VECTOR);
		this.point1 = new Point(cube1, COORDINATE_VECTOR1);
	}
	
	@Test
	public void testToString() {
		String string = point.toString();
		for (int i = 0; i < point.getCoordinates().length; i++) {
			assertEquals(true, point.toString().contains(
					new Integer(point.getCoordinates()[i].getValue()).toString()));
		}
	}
	
	@Test
	public void testEquals() {
		assertEquals(true, point.equals(INTS));
		assertEquals(true, point.equals(COORDINATE_VECTOR));
		assertEquals(true, point.equals(new Point(cube, COORDINATE_VECTOR)));
		assertEquals(false, point.equals(INTS1));
		assertEquals(false, point.equals(COORDINATE_VECTOR1));
		assertEquals(false, point.equals(new Point(cube, COORDINATE_VECTOR1)));
	}
	
	@Test
	public void testCollectPoints() {
		points = Point.collectPoints(cube);
		assertEquals(Math.pow(cube.getLength(), cube.getDimension()), points.length);
		for (int i = 0; i < points.length; i++) {
			assertEquals(false, points[i] == null);
		}
		
		points1 = Point.collectPoints(cube1);
		assertEquals(Math.pow(cube1.getLength(), cube1.getDimension()), points1.length);
		for (int i = 0; i < points1.length; i++) {
			assertEquals(false, points1[i] == null);
		}
		
	}
}
