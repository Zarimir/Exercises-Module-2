package test.prototype;

import org.junit.Before;
import org.junit.Test;

import game.prototype.Matrix;

public class testMatrix {
	private static final int DIMENSION = 3;
	private static final int LENGTH = 2;
	private Matrix matrix;
	
	@Before
	public void setUp() {
		matrix = new Matrix(DIMENSION, LENGTH);
	}
	
	@Test
	public void testConstruct2DimensionalDiagonals() {
		matrix.extractDiagonals();
		//matrix.check();
		//System.out.println(matrix);
	}
}
