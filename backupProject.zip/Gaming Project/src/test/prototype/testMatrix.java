package test.prototype;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import game.prototype.Line;
import game.prototype.Point;
import game.prototype.MatrixPrimitive;

public class testMatrix {
	
	@Test
	public void testIterate() {
		int[] ints = {1,2,3,-1,-1,-1};
		MatrixPrimitive m = new MatrixPrimitive(ints);
		for (int i = 0; i < 19; i++) {
			m.iterate();
			System.out.println(m.getFreeIndexes());
			System.out.println(m);
		}
	}
}
