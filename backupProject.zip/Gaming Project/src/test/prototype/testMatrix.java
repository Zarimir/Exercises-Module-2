package test.prototype;

import org.junit.Before;
import org.junit.Test;

import game.prototype.Matrix;

public class testMatrix {
	private static final int DIMENSION = 4;
	private static final int LENGTH = 3;
	private Matrix matrix;
	
	@Before
	public void setUp() {
		matrix = new Matrix(DIMENSION, LENGTH);
	}
	
	@Test
	public void testConstruct2DimensionalDiagonals() {
		matrix.extractPoints();
		System.out.println(matrix.getPoints());
		//System.out.println(matrix);
	}
}
