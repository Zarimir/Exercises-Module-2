package test.prototype;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import game.prototype.Math;
import game.prototype.*;

public class testMatrix {
	private static final int DIMENSION = 4;
	private static final int LENGTH = 2;
	private int number;
	private Matrix matrix;
	
	@Before
	public void setUp() {
		matrix = new Matrix(DIMENSION, LENGTH);
	}
	
	@Test
	public void testExtractPoints() {
		matrix.extractPoints();
		number = Math.pow(LENGTH, DIMENSION);
		assertEquals(number, matrix.getPoints().size());
	}
	
	@Test
	public void testExtractNonDiagonals() {
		matrix.extractNonDiagonals();
		number = DIMENSION * Math.pow(LENGTH, DIMENSION - 1);
		assertEquals(number, matrix.getLines().size());
	}
	
	@Test
	public void testExtractDiagonals() {
		matrix.extractDiagonals();
		number = DIMENSION * Math.pow(LENGTH, DIMENSION - 1);
		number = 8 + 4 * 2 * 4 + 2 * 2 * 6;
		//matrix.getLines().add(matrix.getLines().get(matrix.getLines().size() - 1));
		//assertEquals(false, Line.checkForDuplicates(matrix.getLines()));
		System.out.println(matrix.getLines());
		assertEquals(number, matrix.getLines().size());
		
		
	}
}
