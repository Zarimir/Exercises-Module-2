package test.prototype;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import game.prototype.Math;
import game.prototype.*;

public class testMatrix {
	private static final int DIMENSION = 5;
	private static final int LENGTH = 5;
	private int number;
	private Matrix matrix;
	
	@Before
	public void setUp() {
		matrix = new Matrix(DIMENSION, LENGTH);
	}
	
	@Test
	public void testExtractPoints() {
		matrix.extractPoints();
		number = Math.pow(LENGTH, DIMENSION);
		assertEquals(number, matrix.getPoints().size());
		System.out.println(matrix.getPoints());
	}
	
	@Test
	public void testExtractNonDiagonals() {
		matrix.extractNonDiagonals();
		number = DIMENSION * Math.pow(LENGTH, DIMENSION - 1);
		assertEquals(number, matrix.getLines().size());
	}
	
	@Test
	public void testExtractDiagonals() {
		matrix.extractDiagonals(); 
		assertEquals(Math.calculateNumberOfDiagonals(DIMENSION, LENGTH),
				matrix.getLines().size());
		assertEquals(false, Line.checkForDuplicates(matrix.getLines()));
	}
	
	@Test
	public void testExtract() {
		matrix.extract();
		int points = Math.pow(LENGTH, DIMENSION);
		int lines = DIMENSION * Math.pow(LENGTH, DIMENSION - 1) +
				Math.calculateNumberOfDiagonals(DIMENSION, LENGTH);
		assertEquals(points, matrix.getPoints().size());
		assertEquals(lines, matrix.getLines().size());
		assertEquals(false, Line.checkForDuplicates(matrix.getLines()));
	}
}