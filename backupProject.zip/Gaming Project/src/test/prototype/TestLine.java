package test.prototype;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import game.prototype.Line;
import game.prototype.Mark;
import game.prototype.Point;

public class TestLine {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 */
	private Line line;
	private Line line1;
	private static final Mark EMPTY = Mark.EMPTY;
	private static final Mark NOT_EMPTY = Mark.XX;
	private static final int ZERO = 0;
	private static final int DIM = 3;
	private static final int LENGTH = 7;
	
	// ------------------------ Setup ------------------------
	
	/**
	 * Sets two identical lines.
	 */
	@Before
	public void setUp() {
		line = new Line(DIM, LENGTH);
		line1 = new Line(DIM, LENGTH);
	}
	
	// ------------------------ Test Queries ------------------------
	
	/**
	 * Expected to return a copy line containing copies of all the points of the original line.
	 * It is also expected that the new line could be modified separately.
	 */
	@Test
	public void testCopy() {
		line1 = null;
		line1 = line.copy();
		assertEquals(true, line.equals(line1));
		
		line1.getPoints()[ZERO].setMark(NOT_EMPTY);
		assertEquals(true, line.equals(line1));
		
		line1.getPoints()[ZERO].getCoordinates()[ZERO].setValue(1);
		assertEquals(false, line.equals(line1));		
	}
	
	/**
	 * Expected to return EMPTY if points from the line are partially owned
	 * only by one player or none at all.
	 * Expected to return null if 2 or more players own points from this line.
	 * Expected to return NOT_EMPTY if he owns the whole line.
	 */
	@Test
	public void testOwnedBy() {
		Point[] points = line.getPoints();
		
		assertEquals(true, line.ownedBy() == EMPTY);
		
		points[ZERO].setMark(NOT_EMPTY);
		assertEquals(true, line.ownedBy() == EMPTY);
		
		points[DIM / DIM].setMark(NOT_EMPTY.other());
		assertEquals(true, line.ownedBy() == null);
		
		for (int i = 0; i < points.length; i++) {
			points[i].setMark(NOT_EMPTY);
		}
		assertEquals(true, line.ownedBy() == NOT_EMPTY);
	}
	
	/**
	 * Expected to return true if the lines are of equal length and all their points are equal.
	 * Expected to return false otherwise.
	 */
	@Test
	public void testEquals() {
		assertEquals(true, line.equals(line1));
		
		line1.getPoints()[ZERO].setMark(NOT_EMPTY);
		assertEquals(true, line.equals(line1));
		
		line1.getPoints()[ZERO].getCoordinates()[ZERO].setValue(DIM);
		assertEquals(false, line.equals(line1));
		
		line = new Line(DIM, LENGTH);
		line1 = new Line(DIM, DIM);
		assertEquals(false, line.equals(line1));
	}
	
	// ------------------------ Test Commands ------------------------
	
	/**
	 * Expected to have an effect only if the line
	 * contains a point which is equal to the one it is looking for.
	 * Expected to change the mark of the found point to be the same as the mark of the point argument.
	 */
	@Test
	public void testSetMark() {
		Point point = new Point(DIM);
		point.getCoordinate(DIM).setValue(DIM/DIM);
		point.setMark(NOT_EMPTY);
		
		Point target = line.getPoints()[ZERO];
		line.setMark(point);
		assertEquals(false, point.getMark() == target.getMark());
		
		target.getCoordinate(DIM).setValue(DIM);
		line.setMark(point);
		assertEquals(false, point.getMark() == target.getMark());
		
		point = target.copy();
		line.setMark(point);
		assertEquals(true, point.getMark() == target.getMark());
	}
	
	
	/**
	 * Expected to change the vale of the coordinate of the specific dimension
	 * in each point of the line equal to the point's index in the point[] list when the boolean is true.
	 * When the boolean is false it should do the same in reverse.
	 * Example.
	 * Line with coordinates (-1,-1,-1) (-1,-1,-1) (-1,-1,-1)
	 * setIteratableAt(1) 1 is the dimension, therefore the X coordinate
	 * line = (0,-1,-1) (1,-1,-1) (2,-1,-1)
	 * setIteratableAt(3) - 3 is the dimension, therefore the Z coordinate
	 * line = (0,-1,2) (1,-1,1) (2,-1,0)
	 */
	@Test
	public void testSetIteratableAt() {
		line.setIteratableCoordinateAt(DIM/DIM + DIM/DIM, true);
		line.setIteratableCoordinateAt(DIM/DIM, false);
		for (int i = 0; i < LENGTH; i++) {
			assertEquals(i,line.getPoints()[i].getCoordinate(DIM/DIM + DIM/DIM).getValue());
			assertEquals(LENGTH - i - 1, line.getPoints()[i].getCoordinate(DIM/DIM).getValue());
		}
	}
	
	// ------------------------ Test Static Commands ------------------------
	
	/**
	 * Expected to return true if a list has 2 or more lines which are equal.
	 * Expected to return false otherwise.
	 */
	@Test
	public void testCheckForDuplicates() {
		List<Line> list = new ArrayList<Line>();
		for (int i = 0; i < LENGTH; i++) {
			list.add(new Line(DIM, i));
		}
		
		assertEquals(false, Line.hasDuplicates(list));
		
		list.add(list.get(ZERO));
		assertEquals(true, Line.hasDuplicates(list));
	}
}