package test.prototype;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import game.prototype.MyMath;

public class TestMyMath {

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 */
	private static final int NUM = 6;
	private static final int VAL = 4;
	
	private static final int DIMENSION = 3;
	private static final int LENGTH = 2;
	private static final int TWO_DIMENSIONAL_DIAGONALS = 6 * 2;
	private static final int THREE_DIMENSIONAL_DIAGONALS = 4;
	private static final int ALL_DIAGONALS = TWO_DIMENSIONAL_DIAGONALS + THREE_DIMENSIONAL_DIAGONALS;
			
	private int expected;
	
	// ------------------------ Test Static Commands ------------------------
	
	/**
	 * Expected to return a number raised to a given power. Only works with positive powers.
	 */
	@Test
	public void testPow() {
		expected = 1;
		for (int i = 0; i < VAL; i++) {
			expected *= NUM;
		}
		assertEquals(expected, MyMath.pow(NUM, VAL));
	}
	
	/**
	 * Expected to return the remainder of division of a number with another number.
	 */
	@Test
	public void testModulo() {
		expected = NUM / NUM;
		assertEquals(expected, MyMath.modulo(NUM / NUM, NUM));
		
		expected = NUM - (NUM / NUM);
		assertEquals(expected, MyMath.modulo(-(NUM / NUM), NUM));
	}
	
	/**
	 * Expected to return the factorial of a number.
	 */
	@Test
	public void testFactorial() {
		expected = 1;
		for (int i = 0; i < NUM; i++) {
			expected *= NUM - i;
		}
		assertEquals(expected, MyMath.factorial(NUM));
	}
	
	/**
	 * Expected to return the number of non-repetitive possible with a set of elements.
	 */
	@Test
	public void testVariations() {
		expected = MyMath.factorial(NUM) / (MyMath.factorial(VAL) * MyMath.factorial(NUM - VAL));
		assertEquals(expected, MyMath.variations(VAL, NUM));
	}
	
	/**
	 * Expected to return the number of diagonals in a 3D Cube of length = 2 points.
	 */
	@Test
	public void testCalculateNumberOfDiagonals() {
		assertEquals(ALL_DIAGONALS, MyMath.calculateNumberOfDiagonals(DIMENSION, LENGTH));
	}
}
