package test.prototype;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import game.prototype.Coordinate;

public class TestCoordinate {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 */
	private static final int ZERO = 0;
	private static final int DIM = 3;
	private static final int VAL = 7;
	
	private Coordinate coord;
	private Coordinate coord1;
	
	// ------------------------ Setup ------------------------
	
	/**
	 * Sets two identical coordinates.
	 */
	@Before
	public void setUp() {
		coord = new Coordinate(DIM, VAL);
		coord1 = new Coordinate(DIM, VAL);
	}
	
	// ------------------------ Test Queries ------------------------
	
	/**
	 * Expected to return a copy coordinate with the same dimension and value,
	 * which could be modified separately from the original coordinate.
	 */
	@Test
	public void testCopy() {
		coord1 = null;
		assertEquals(false, coord == null);
		assertEquals(true, coord1 == null);
		
		coord1 = coord.copy();
		assertEquals(true, coord.equals(coord1));
		
		coord1.setValue(coord1.getValue() + 1);
		assertEquals(false, coord.equals(coord1));
	}
	
	/**
	 * Expected to return true when the coordinates have the same dimension and value.
	 */
	@Test
	public void testEquals() {
		coord1 = null;
		assertEquals(false, coord.equals(coord1));
		
		coord1 = new Coordinate(VAL, VAL);
		assertEquals(false, coord.equals(coord1));
		
		coord1 = new Coordinate(DIM, DIM);
		assertEquals(false, coord.equals(coord1));
		
		coord1 = new Coordinate(DIM, VAL);
		assertEquals(true, coord.equals(coord1));
	}
	
	/**
	 * Expected to return true when the coordinates have the same dimension.
	 */
	@Test
	public void testSameDimension() {
		assertEquals(true, coord.sameDimension(coord1));
		
		coord1 = new Coordinate(DIM, DIM);
		assertEquals(true, coord.sameDimension(coord1));
		
		coord1 = new Coordinate(VAL, VAL);
		assertEquals(false, coord.sameDimension(coord1));
		
		coord1 = new Coordinate(VAL, DIM);
		assertEquals(false, coord.sameDimension(coord1));
	}
	
	/**
	 * Expected to return true when the coordinates have the same value.
	 */
	@Test
	public void testSameValue() {
		assertEquals(true, coord.sameValue(coord1));
		
		coord1 = new Coordinate(DIM, DIM);
		assertEquals(false, coord.sameValue(coord1));
		
		coord1 = new Coordinate(VAL, VAL);
		assertEquals(true, coord.sameValue(coord1));
		
		coord1 = new Coordinate(VAL, DIM);
		assertEquals(false, coord.sameValue(coord1));
	}
	
	// ------------------------ Test Commands ------------------------
	
	/**
	 * Expected to change the value of a coordinate to a specific value.
	 */
	@Test
	public void testSetValue() {
		assertEquals(VAL, coord.getValue());
		
		coord.setValue(DIM);
		assertEquals(DIM, coord.getValue());
	}
	
	// ------------------------ Test Static Commands ------------------------
	
	/**
	 * Expected to return a list of coordinate copies of the original coordinates,
	 * which could also be modified separately.
	 */
	@Test
	public void testCoordinateCopy() {
		Coordinate[] coords = {coord, coord1};
		Coordinate[] copies = Coordinate.copy(coords);
		
		for(int i = 0; i < coords.length; i++) {
			assertEquals(true, coords[i].equals(copies[i]));
		}
		
		coord.setValue(DIM);
		assertEquals(false, coord.equals(copies[ZERO]));
	}
}