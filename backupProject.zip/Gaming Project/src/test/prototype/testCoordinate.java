package test.prototype;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import game.prototype.Coordinate;
import game.prototype.Point;

public class testCoordinate {
	private Coordinate coord;
	private Coordinate coord1;
	private static final int DIM = 3;
	private static final int VAL = 7;
	private static final int[] COORDINATE_VECTOR = {1, 2, 3};
	private static final int[] COORDINATE_VECTOR1 = {2, 3, 1};
	
	@Before
	public void setUp() {
		coord = new Coordinate(DIM, VAL);
		coord1 = new Coordinate(DIM, VAL);
	}
	
	/**
	 * toString should return the value in a string.
	 */
	@Test
	public void testToString() {
	//	assertEquals(true,
	//			coord.toString().equals(new Integer(coord.getValue()).toString()));
	}
	
	/**
	 * sameDimension returns true when they have the same dimension.
	 * equals returns true when they have the same dimension and value.
	 */
	@Test
	public void testSameDimension() {
		assertEquals(true, coord.equals(coord1));
		
		coord1 = new Coordinate(DIM, VAL + VAL/VAL);
		assertEquals(false, coord.equals(coord1));
		assertEquals(true, coord.sameDimension(coord1));
		
		coord1 = new Coordinate(DIM + DIM/DIM, VAL);
		assertEquals(false, coord.equals(coord1));
		assertEquals(false, coord.sameDimension(coord1));
		
		coord1 = new Coordinate(DIM + DIM/DIM, VAL + VAL/VAL);
		assertEquals(false, coord.equals(coord1));
		assertEquals(false, coord.sameDimension(coord1));
	}
	
	/**
	 * Checks whether when you extract coordinates from an integer vector, each coordinate has
	 * index + 1 dimension and each coordinate gets extracted.
	 */
	@Test
	public void testExtractCoordinates() {
		Coordinate[] coordinates = Coordinate.extractCoordinates(COORDINATE_VECTOR);
		for (int i = 0; i < COORDINATE_VECTOR.length; i++) {
			assertEquals(COORDINATE_VECTOR[i], coordinates[i].getValue());
			assertEquals(i + 1, coordinates[i].getDimension());
		}
	}
	
	/**
	 * Checks whether you can copy from a Coordinate template.
	 */
	@Test
	public void testCopy() {
		coord1 = null;
		assertEquals(false, coord == null);
		assertEquals(true, coord1 == null);
		
		coord1 = Coordinate.copy(coord);
		assertEquals(true, coord.equals(coord1));
		
		coord1.setValue(coord1.getValue() + 1);
		assertEquals(false, coord.equals(coord1));
	}
	
	@Test
	public void testIterate() {
		Coordinate[] coordinates = Coordinate.extractCoordinates(COORDINATE_VECTOR);
		Coordinate[] coordinates1 = Coordinate.extractCoordinates(COORDINATE_VECTOR1);
		for (int i = 0; i < coordinates.length; i++) {
			assertEquals(false, coordinates[i].sameValue(coordinates1[i]));
			assertEquals(true, coordinates[i].sameDimension(coordinates1[i]));
			assertEquals(false, coordinates[i].equals(coordinates1[i]));
		}
		Coordinate.iterateForward(coordinates);
		for (int i = 0; i < coordinates.length; i++) {
			assertEquals(true, coordinates[i].sameValue(coordinates1[i]));
			assertEquals(false, coordinates[i].sameDimension(coordinates1[i]));
			assertEquals(false, coordinates[i].equals(coordinates1[i]));
		}
	}
	
	@Test
	public void testIterateBackward() {
		Coordinate[] coordinates = Coordinate.extractCoordinates(COORDINATE_VECTOR);
		Coordinate[] coordinates1 = Coordinate.extractCoordinates(COORDINATE_VECTOR1);
		Coordinate.iterateForward(coordinates);
		Coordinate.iterateBackward(coordinates);
		for (int i = 0; i < coordinates.length; i++) {
			assertEquals(false, coordinates[i].sameValue(coordinates1[i]));
			assertEquals(true, coordinates[i].sameDimension(coordinates1[i]));
			assertEquals(false, coordinates[i].equals(coordinates1[i]));
		}
		Coordinate.iterateForward(coordinates);
		Coordinate.iterateForward(coordinates);
		Coordinate.iterateBackward(coordinates);
		for (int i = 0; i < coordinates.length; i++) {
			assertEquals(true, coordinates[i].sameValue(coordinates1[i]));
			assertEquals(false, coordinates[i].sameDimension(coordinates1[i]));
			assertEquals(false, coordinates[i].equals(coordinates1[i]));
		}
	}
	
	@Test
	public void testOrder() {
		Coordinate[] coordinates = new Coordinate[VAL];
		for (int i = 0; i < VAL; i ++) {
			coordinates[i] = new Coordinate(VAL - i, VAL - i - 1);
		}
		for (int i = 0; i < VAL - 1; i ++) {
			assertEquals(false, coordinates[i].getDimension() < coordinates[i + 1].getDimension());
		}
		
		Coordinate.order(coordinates);
		for (int i = 0; i < VAL - 1; i ++) {
			assertEquals(true, coordinates[i].getDimension() < coordinates[i + 1].getDimension());
		}
		
		Coordinate.iterateForward(coordinates);
		Coordinate.order(coordinates);
		for (int i = 0; i < VAL - 1; i ++) {
			assertEquals(true, coordinates[i].getDimension() < coordinates[i + 1].getDimension());
		}
	}
	
	@Test
	public void testInitialize() {
		Coordinate[] coordinates = Coordinate.initialize(3);
		Coordinate[] check = {new Coordinate(3,-1), new Coordinate(2,-1), new Coordinate(1,-1)};
		for (int i = 0; i < coordinates.length; i++) {
			assertEquals(coordinates[i].getDimension(), check[i].getDimension());
			assertEquals(coordinates[i].getValue(), check[i].getValue());
		}
	}
}