package test.prototype;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import game.prototype.*;

public class TestMatrix {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param DIMENSION of the Matrix
	 * @param LENGTH of the Matrix
	 * 
	 * @param NUMBER_OF_POINTS is the expected number of points
	 * @param NUMBER_OF_NON_DIAGONALS is the expected number of non-diagonal lines
	 * @param NUMBER_OF_DIAGONALS is the expected number of diagonal lines
	 * @param NUMBER_OF_LINES is the expected numbers of non-diagonal and diagonal lines summed.
	 * 
	 * @param matrix the holder of the currently tested Matrix
	 */
	private static final int DIMENSION = 5;
	private static final int LENGTH = 4;
	
	private static final int NUMBER_OF_POINTS = MyMath.pow(LENGTH, DIMENSION);
	private static final int NUMBER_OF_NON_DIAGONALS = DIMENSION * MyMath.pow(LENGTH, DIMENSION - 1);
	private static final int NUMBER_OF_DIAGONALS = MyMath.calculateNumberOfDiagonals(DIMENSION, LENGTH);
	private static final int NUMBER_OF_LINES = NUMBER_OF_NON_DIAGONALS + NUMBER_OF_DIAGONALS;
	
	private Matrix matrix;
	
	// ------------------------ Setup ------------------------
	
	/**
	 * Setups new Matrix.
	 */
	@Before
	public void setUp() {
		matrix = new Matrix(DIMENSION, LENGTH);
	}
	
	// ------------------------ Test Commands ------------------------
	
	/**
	 * Expected result should be a list of points with list size equal to number.
	 */
	@Test
	public void testExtractPoints() {
		matrix.extractPoints();
		assertEquals(NUMBER_OF_POINTS, matrix.getPoints().size());
	}
	
	/**
	 * Expected result should be a list of non-diagonal lines with list size equal to number.
	 */
	@Test
	public void testExtractNonDiagonals() {
		matrix.extractNonDiagonals();
		assertEquals(NUMBER_OF_NON_DIAGONALS, matrix.getLines().size());
	}
	
	/**
	 * Expected result should be a list of diagonals with list size equal to number.
	 */
	@Test
	public void testExtractDiagonals() {
		matrix.extractDiagonals();
		assertEquals(NUMBER_OF_DIAGONALS, matrix.getLines().size());
		assertEquals(false, Line.hasDuplicates(matrix.getLines()));
	}
	
	/**
	 * Expected result should be a list of points and lines, with sizes equal to their expected numbers.
	 * They should not contain any duplicates.
	 */
	@Test
	public void testExtract() {
		matrix.extract();
		assertEquals(NUMBER_OF_POINTS, matrix.getPoints().size());
		assertEquals(NUMBER_OF_LINES, matrix.getLines().size());
		assertEquals(false, Line.hasDuplicates(matrix.getLines()));
	}
}