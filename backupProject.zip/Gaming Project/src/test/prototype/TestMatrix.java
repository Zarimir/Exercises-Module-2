package test.prototype;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import game.prototype.MyMath;
import game.prototype.*;

public class TestMatrix {
	
	// ------------------------ Instance Variables ------------------------
	
	private static final int DIMENSION = 5;
	private static final int LENGTH = 5;
	private int number;
	private Matrix matrix;
	
	// ------------------------ Setup ------------------------
	
	@Before
	public void setUp() {
		matrix = new Matrix(DIMENSION, LENGTH);
	}
	
	// ------------------------ Test Commands ------------------------
	
	/**
	 * Expected result should be a list of points with list size equal to number.
	 */
	@Test
	public void testExtractPoints() {
		matrix.extractPoints();
		number = MyMath.pow(LENGTH, DIMENSION);
		assertEquals(number, matrix.getPoints().size());
	}
	
	/**
	 * Expected result should be a list of non-diagonal lines with list size equal to number.
	 */
	@Test
	public void testExtractNonDiagonals() {
		matrix.extractNonDiagonals();
		number = DIMENSION * MyMath.pow(LENGTH, DIMENSION - 1);
		assertEquals(number, matrix.getLines().size());
	}
	
	/**
	 * Expected result should be a list of diagonals with list size equal to number.
	 */
	@Test
	public void testExtractDiagonals() {
		matrix.extractDiagonals(); 
		assertEquals(MyMath.calculateNumberOfDiagonals(DIMENSION, LENGTH),
				matrix.getLines().size());
		
		assertEquals(false, Line.hasDuplicates(matrix.getLines()));
	}
	
	/**
	 * Expected result should be a list of points and lines, with sizes equal to their expected numbers.
	 * They should not contain any duplicates.
	 */
	@Test
	public void testExtract() {
		matrix.extract();
		int points = MyMath.pow(LENGTH, DIMENSION);
		int lines = DIMENSION * MyMath.pow(LENGTH, DIMENSION - 1) +
				MyMath.calculateNumberOfDiagonals(DIMENSION, LENGTH);
		
		assertEquals(points, matrix.getPoints().size());
		assertEquals(lines, matrix.getLines().size());
		assertEquals(false, Line.hasDuplicates(matrix.getLines()));
	}
}