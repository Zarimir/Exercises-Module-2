package test.prototype;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import game.prototype.HyperCube;
import game.prototype.Mark;
import game.prototype.Point;

public class TestHyperCube {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 */
	private static final int ZERO = 0;
	private static final int DIM = 3;
	private static final int LENGTH = 4;
	private static final int VAL = 7;
	
	private static final Mark EMPTY = Mark.EMPTY;
	private static final Mark NOT_EMPTY = Mark.XX;
	
	private HyperCube cube;
	private HyperCube cube1;
	
	// ------------------------ Setup ------------------------
	
	/**
	 * Sets two identical cubes.
	 */
	@Before
	public void setUp() {
		cube = new HyperCube(DIM, LENGTH);
		cube1 = new HyperCube(DIM, LENGTH);
		cube.initialize();
		cube1.initialize();
	}
	
	// ------------------------ Test Queries ------------------------
	
	/**
	 * Expected to return a copy HyperCube containing copies of
	 * all the metaPoints and metaLines of the original HyperCube.
	 * It is also expected that the new HyerCube could be modified separately.
	 */
	@Test
	public void testCopy() {
		cube1 = null;
		cube1 = cube.copy();
		assertEquals(true, cube.equals(cube1));
		
		cube1.getMetaPoints().get(ZERO).setMark(NOT_EMPTY);
		assertEquals(false, cube.equals(cube1));
		
		cube1.getMetaPoints().get(ZERO).setMark(EMPTY);
		assertEquals(true, cube.equals(cube1));
		
		cube1.getMetaLines().remove(ZERO);
		assertEquals(false, cube.equals(cube1));
		
		cube1.initialize();
		for (int i = 0; i < cube.getMetaPoints().size(); i++) {
			assertEquals(true,
					cube.getMetaPoints().get(i).equals(cube1.getMetaPoints().get(i)));
		}
		
		for (int i = 0; i < cube.getMetaLines().size(); i++) {
			assertEquals(true,
					cube.getMetaLines().get(i).equals(cube1.getMetaLines().get(i)));
		}
	}
	
	
	/**
	 * Expected to return true if the lines are of equal length and all their points are equal
	 * as well as all the marks are equal.
	 * Expected to return false otherwise.
	 */
	@Test
	public void testEquals() {
		cube1 = cube.copy();
		Point point1 = cube1.getMetaPoints().get(ZERO);
		assertEquals(true, cube.equals(cube1));
		 
		point1.setMark(NOT_EMPTY);
		assertEquals(false, cube.equals(cube1));
		
		point1.setMark(EMPTY);
		assertEquals(true, cube.equals(cube1));
		
		point1.getCoordinates()[ZERO].setValue(VAL * VAL);
		assertEquals(false, cube.equals(cube1));
	}
	
	// ------------------------ Test Commands ------------------------
	
	@Test
	public void testInitialize() {
		cube.setStatus(null, null);
		assertEquals(true, cube.getMetaPoints().size() == ZERO);
		assertEquals(true, cube.getMetaLines().size() == ZERO);
		
		cube.setStatus(cube.getPoints(), cube.getLines());
		for (int i = 0; i < cube.getLines().size(); i++) {
			if (i < cube.getPoints().size()) {
				assertEquals(true, cube.getPoints().get(i).equals(cube.getMetaPoints().get(i)));
			}
			assertEquals(true, cube.getLines().get(i).equals(cube.getMetaLines().get(i)));
		}
	}
	
	// ------------------------ Test Static Commands ------------------------
	
	@Test
	public void testHyperCubeCopyPoints() {
		List<Point> points = new ArrayList<Point>();
		List<Point> points1 = new ArrayList<Point>();
		
		assertEquals(true, points.size() == ZERO);
		assertEquals(true, points1.size() == ZERO);
		
		points1.add(new Point(DIM));
		assertEquals(true, points.size() == ZERO);
		assertEquals(false, points1.size() == ZERO);
		
		points1 = HyperCube.copyPoints(points);
		assertEquals(true, points.size() == ZERO);
		assertEquals(true, points1.size() == ZERO);
		
		points1.add(new Point(DIM));
		points.add(new Point(VAL));
		points1.get(ZERO).setMark(NOT_EMPTY);
		points = HyperCube.copyPoints(points1);
		
		assertEquals(true, points.size() == points1.size());
		for (int i = 0; i < points.size(); i++) {
			assertEquals(true, points.get(i).equals(points1.get(i)));
			assertEquals(true, points.get(i).getMark() == points1.get(i).getMark());
		}
		
		points1.get(ZERO).getCoordinates()[ZERO].setValue(VAL);
		assertEquals(false, points.get(ZERO).equals(points1.get(ZERO)));
	}
	
}