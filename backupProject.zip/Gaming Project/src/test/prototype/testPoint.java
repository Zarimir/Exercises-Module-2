package test.prototype;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import game.prototype.Coordinate;
import game.prototype.HyperCube;
import game.prototype.Point;
import game.prototype.Math;

public class testPoint {
	private Point point;
	private Point point1;
	private HyperCube cube;
	private HyperCube cube1;
	private Point[] points;
	private Point[] points1;
	private static final int DIM = 3;
	private static final int VAL = 7;
	private static final int[] INTS = {5,3,7,5};
	private static final int[] INTS1 = {3,3,4,2};
	
	@Before
	public void setUp() {
		this.cube = new HyperCube(DIM, DIM);
		this.cube1 = new HyperCube(DIM + DIM / DIM, DIM * DIM);
	}
	
	@Test
	public void testToString() {
		String string = point.toString();
		for (int i = 0; i < point.getCoordinates().length; i++) {
			assertEquals(true, point.toString().contains(
					new Integer(point.getCoordinates()[i].getValue()).toString()));
		}
	}
	
	
	@Test
	public void testEquals() {
		assertEquals(true, point.equals(INTS));
		assertEquals(false, point.equals(INTS1));
	}
	
	@Test
	public void testCollectPoints() {
		points = Point.collectPoints(cube);
		assertEquals(Math.pow(cube.getLength(), cube.getDimension()), points.length);
		for (int i = 0; i < points.length; i++) {
			assertEquals(false, points[i] == null);
		}
		
		points1 = Point.collectPoints(cube1);
		assertEquals(Math.pow(cube1.getLength(), cube1.getDimension()), points1.length);
		for (int i = 0; i < points1.length; i++) {
			assertEquals(false, points1[i] == null);
		}
		
	}
	
	@Test
	public void copy() {
		point = new Point(3);
		point1 = null;
		assertEquals(false, point.equals(point1));
		for (int i = 0; i < point.getCoordinates().length; i++) {
			point.previous();
			point.setCoordinate(i);
		}
		point1 = point.copy();
		assertEquals(true, point.equals(point1));
		point.setCoordinate(5);
		assertEquals(false, point.equals(point1));
	}
}