package test.prototype;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import game.prototype.Line;
import game.prototype.Point;

public class testLine {
	
	@Test
	public void testSetIteratableAt() {
		Line l = new Line(2, 5);
		l.setIteratableCoordinateAt(2, true);
		l.setIteratableCoordinateAt(1, false);
		//System.out.println(l);
		for (int i = 1; i < l.getPoints()[0].getCoordinates()[0].getDimension(); i++) {
			assertEquals(l.getPoints()[i - 1].getCoordinate(2).getValue() + 1, l.getPoints()[i].getCoordinate(2).getValue());
			//assertEquals(l.getPoints)
		}
		
	}
	
	@Test
	public void testAddAll() {
		List<Integer> l = new ArrayList<Integer>();
		l.add(1);
		l.add(2);
		List<Integer> p = new ArrayList<Integer>();
		p.add(4);
		p.add(5);
		//System.out.println(p);
		p.addAll(l);
		//System.out.println(p);
		for (int i = 0; i < 2; i++) {
			
			l.get(i);
		}
	}
	
	@Test
	public  void testCopy() {
		Line line = new Line(3, 5);
		//System.out.println(line);
		Line line1 = new Line(5, 5);
		assertEquals(false, line.equals(line1));
		line = line1.copy();
		assertEquals(true, line.equals(line1));
		line.getPoints()[0] = new Point(10);
		
		//System.out.println(line1);
		//System.out.println(line.equals(line1));
		
	}
}