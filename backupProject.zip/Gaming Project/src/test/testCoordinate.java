package test;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import game.Coordinate;

public class testCoordinate {
	private Coordinate coord;
	private Coordinate coord1;
	private static final int DIM = 3;
	private static final int VAL = 7;
	private static final int[] COORDINATE_VECTOR = {5,3,7,5};
	
	@Before
	public void setUp() {
		coord = new Coordinate(DIM, VAL);
		coord1 = new Coordinate(DIM, VAL);
	}
	
	/**
	 * toString should return the value in a string.
	 */
	@Test
	public void testToString() {
		assertEquals(true,
				coord.toString().equals(new Integer(coord.getValue()).toString()));
	}
	
	/**
	 * sameDimension returns true when they have the same dimension.
	 * equals returns true when they have the same dimension and value.
	 */
	@Test
	public void testSameDimension() {
		assertEquals(true, coord.equals(coord1));
		
		coord1 = new Coordinate(DIM, VAL + VAL/VAL);
		assertEquals(false, coord.equals(coord1));
		assertEquals(true, coord.sameDimension(coord1));
		
		coord1 = new Coordinate(DIM + DIM/DIM, VAL);
		assertEquals(false, coord.equals(coord1));
		assertEquals(false, coord.sameDimension(coord1));
		
		coord1 = new Coordinate(DIM + DIM/DIM, VAL + VAL/VAL);
		assertEquals(false, coord.equals(coord1));
		assertEquals(false, coord.sameDimension(coord1));
	}
	
	/**
	 * Checks whether when you extract coordinates from an integer vector, each coordinate has
	 * index + 1 dimension and each coordinate gets extracted.
	 */
	@Test
	public void testExtractCoordinates() {
		Coordinate[] coordinates = Coordinate.extractCoordinates(COORDINATE_VECTOR);
		for (int i = 0; i < COORDINATE_VECTOR.length; i++) {
			assertEquals(COORDINATE_VECTOR[i], coordinates[i].getValue());
			assertEquals(i + 1, coordinates[i].getDimension());
		}
	}
}
