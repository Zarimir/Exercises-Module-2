package game.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import game.geometry.HyperCube;
import game.geometry.Point;
import game.logic.Mark;

/**
 * Naive Strategy picks a random free point and marks it.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class NaiveStrategy implements Strategy {

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param NAME of this strategy is "Naive"
	 * @param random is an random integer generator
	 */
	//@ private invariant NAME.equals("Naive");
	//@ private invariant random != null;
	private final String NAME = "Naive";
	private Random random = new Random();
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Gets the name of this strategy.
	 * @return "Naive"
	 */
	//@ ensures \result != null;
	/*@ pure */ public String getName() {
		return this.NAME;
	}
	
	/**
	 * Determines the next legal move.
	 * @param board of the Game
	 * @param mark of the ComputerPlayer
	 */
	public Point determineMove(HyperCube board) {
		List<Point> emptyPoints = new ArrayList<Point>();
		Point holder;
		for (int i = 0; i < board.getPoints().size(); i++) {
			holder = board.getMetaPoints().get(i);
			if (holder != null && holder.getMark() == Mark.EMPTY) {
				emptyPoints.add(holder);
			}
		}
		if (emptyPoints.size() > 0) {
			return emptyPoints.get(random.nextInt(emptyPoints.size()));
		} else {
			return null;
		}
	}
}