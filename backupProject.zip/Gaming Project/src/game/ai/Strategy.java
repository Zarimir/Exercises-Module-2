/**
 * 
 */
package game.ai;

import game.geometry.HyperCube;
import game.geometry.Point;
import game.logic.Mark;

/**
 * Interface for all computer player strategies.
 * @author Zarimir Mitev
 * @version 3.0
 */
public interface Strategy {
	
	/**
	 * Strategy name.
	 * @return name of the strategy
	 */
	public String getName();
	
	/**
	 * Next legal move.
	 * @param board board
	 * @param mark mark
	 * @return point of the board
	 */
	//@ requires board != null;
	//@ requires mark != null;
	//@ requires mark != Mark.EMPTY;
	public Point determineMove(HyperCube board, Mark mark);
}
