package game.ai;

import game.geometry.Point;
import game.logic.Game;
import game.logic.Player;

/**
 * Handles the Computer Player of the Game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class ComputerPlayer extends Player {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param strategy of this ComputerPlayer
	 */
	private Strategy strategy;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Constructs a ComputerPlayer with a given mark argument and
	 * a  Naive Strategy by default.
	 * @param mark of this Player
	 */
	public ComputerPlayer() {
        this(new NaiveStrategy());
    }
	
	/**
	 * Constructs a Computer Player with a given strategy and a mark arguments.
	 * @param strategy of this ComputerPlayer
	 * @param mark of this ComputerPlayer
	 */
	public ComputerPlayer(Strategy strategy) {
        super(strategy.getName());
        this.strategy = strategy;
    }
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Gets the strategy of this ComputerPlayer
	 * @return this.strategy
	 */
	public Strategy getStrategy() {
		return this.strategy;
	}
	
	/**
	 * Determines next move based on current strategy.
	 * @param board of the Game
	 */
	public Point determineMove(Game game) {
		return this.getStrategy().determineMove(game.getHyperCube(), this.getMark());
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the strategy of this Computer Player.
	 * @param strategy
	 */
	public void setStrategy(Strategy strategy) {
		this.strategy = strategy;
	}
}
