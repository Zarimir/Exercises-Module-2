/**
 * 
 */
package game;

/**
 * @author Zarry
 * @version 3.0
 */
public interface UI {
	
	/**
	 * Starts the UI.
	 */
	public void start();
}