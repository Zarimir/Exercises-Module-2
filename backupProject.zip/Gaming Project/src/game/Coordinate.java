package game;

public class Coordinate {
	
	// ------------------------ Instance Variables ------------------------
	
	private int dimension;
	private int value;
	
	// ------------------------ Constructor ------------------------
	
	public Coordinate(int dimension, int value) {
		this.dimension = dimension;
		this.value = value;
	}
	
	public String toString() {
		return "" + this.value;
	}
	
	// ------------------------ Queries ------------------------
	
	public int getDimension() {
		return this.dimension;
	}
	
	public int getValue() {
		return this.value;
	}
	
	// ------------------------ Comparisons ------------------------
	
	public boolean equals(Coordinate coordinate) {
		if (this.sameDimension(coordinate) &&
				this.value == coordinate.getValue()) {
			return true;
		}
		return false;
	}
	
	public boolean sameDimension(Coordinate coordinate) {
		if (coordinate == null) {
			throw new ArithmeticException("Coordinate is equal to null");
		} else if (this.dimension == coordinate.getDimension()) {
			return true;
		}
		return false;
	}
	
	// ------------------------ Commands ------------------------
	
	public static Coordinate[] extractCoordinates(int[] orderedCoordinates) {
		if (orderedCoordinates == null || orderedCoordinates.length < 1) {
			throw new ArithmeticException("The Array of coordinates is null or has 0 elements");
		}
		Coordinate[] result = new Coordinate[orderedCoordinates.length];
		for (int i = 0; i < orderedCoordinates.length; i++) {
			result[i] = new Coordinate(i + 1, orderedCoordinates[i]);
		}
		return result;
	}
}
