package game;

public class Coordinate {
	
	// ------------------------ Instance Variables ------------------------
	
	private int dimension;
	private int value;
	
	// ------------------------ Constructor ------------------------
	
	//@ requires dimension > 0;
	//@ requires value > 0;
	public Coordinate(int dimension, int value) {
		this.dimension = dimension;
		this.value = value;
	}
	
	public String toString() {
		return "" + this.value;
		//return "[" + this.dimension + ":" + this.value +"]";
	}
	
	// ------------------------ Queries ------------------------
	
	public int getDimension() {
		return this.dimension;
	}
	
	public int getValue() {
		return this.value;
	}
	
	// ------------------------ Comparisons ------------------------
	
	public boolean equals(Coordinate coordinate) {
		if (coordinate == null) {
			throw new ArithmeticException("Coordinate is equal to null");
		}
		return this.sameDimension(coordinate) && this.sameValue(coordinate);
	}
	
	public boolean sameDimension(Coordinate coordinate) {
		if (coordinate == null) {
			throw new ArithmeticException("Coordinate is equal to null");
		} else if (this.dimension == coordinate.getDimension()) {
			return true;
		}
		return false;
	}
	
	public boolean sameValue(Coordinate coordinate) {
		if (coordinate == null) {
			throw new ArithmeticException("Coordinate is equal to null");
		} else if (this.value == coordinate.getValue()) {
			return true;
		}
		return false;
	}
	
	// ------------------------ Commands ------------------------
	
	public static Coordinate[] extractCoordinates(int[] orderedCoordinates) {
		if (orderedCoordinates == null || orderedCoordinates.length < 1) {
			throw new ArithmeticException("The Array of coordinates is null or has 0 elements");
		}
		Coordinate[] result = new Coordinate[orderedCoordinates.length];
		for (int i = 0; i < orderedCoordinates.length; i++) {
			result[i] = new Coordinate(i + 1, orderedCoordinates[i]);
		}
		return result;
	}
	
	public void setValue(int value) {
		if (value < 0) {
			throw new ArithmeticException("This method does not allow negative values!");
		}
		this.value = value;
	}
	
	public static Coordinate copy(Coordinate coordinate) {
		if (coordinate == null) {
			throw new ArithmeticException("Coordinate is null!");
		}
		return new Coordinate(coordinate.getDimension(), coordinate.getValue());
	}
	
	public static Coordinate[] copy(Coordinate[] coordinates) {
		if (coordinates == null) {
			throw new ArithmeticException("Coordinate is null!");
		}
		Coordinate[] coords = new Coordinate[coordinates.length];
		for (int i = 0; i < coords.length; i++) {
			coords[i] = Coordinate.copy(coordinates[i]);
		}
		return coords;
	}
	
	public static void iterateForward(Coordinate[] coords) {
		if (coords == null) {
			throw new ArithmeticException("Coordinate[] is null!");
		} else if (coords.length > 1) {
			Coordinate temp = coords[0];
			for (int i = 0; i < coords.length - 1; i++) {
				coords[i] = coords[i + 1];	
			}
			coords[coords.length - 1] = temp;
		}
	}
	
	public static void iterateBackward(Coordinate[] coords) {
		if (coords == null) {
			throw new ArithmeticException("Coordinate[] is null!");
		} else if (coords.length > 1) {
			Coordinate temp = coords[coords.length - 1];
			for (int i = 1; i < coords.length; i++) {
				coords[coords.length - i] = coords[coords.length - i - 1];	
			}
			coords[0] = temp;
		}
	}
	
	public static void order(Coordinate[] coords) {
		if (coords == null) {
			throw new ArithmeticException("Coordinate[] is null!");
		} else if (coords.length > 1) {
			int index = coords.length;
			boolean sorted = false;
			Coordinate holder;
			while (index > 1 && !sorted) {
				sorted = true;
				for (int i = 1; i < index; i++) {
					if (coords[i - 1].getDimension() > coords[i].getDimension()) {
						holder = coords[i - 1];
						coords[i - 1] = coords[i];
						coords[i] = holder;
						sorted = false;
					}
				}
				index -= 1;
			}
		}
	}
	
	public static void prnt(Coordinate[] coordinates) {
		String s = "(";
		for (int i = 0; i < coordinates.length; i++) {
			s += coordinates[i];
			if (i != coordinates.length - 1) {
				s += ", ";
			} else {
				s += ")";
			}
		}
		System.out.println(s);
	}
}
