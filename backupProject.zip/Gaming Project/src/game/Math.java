package game;

public class Math {
	/**
	 * Raises a number to the power of another number.
	 * @param number
	 * @param power has to be >= 0
	 * @return number ^ power
	 * @throws ArithmeticException whenever the power is less than 1
	 */
	//@ requires power > -1;
	/*@ pure */ public static int pow(int number, int power) throws ArithmeticException {
		System.out.println("myMath");
		if (power >= 0) {
			int result = 1;
			for (int i = 0; i < power; i++) {
				result *= number;
			}
			return result;
		} else {
			throw new ArithmeticException("This method does NOT allow powers lower than 0!");
		}
	}
}
