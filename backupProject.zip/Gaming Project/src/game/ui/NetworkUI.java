package game.ui;

import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.geometry.Point;
import game.logic.Game;
import game.logic.Player;
import game.network.NetworkPlayer;
import game.network.NetworkProtocol;
import game.network.exception.CommandNotRecognizedException;
import game.network.exception.InvalidMoveException;
import game.network.exception.NotYourTurnException;

public class NetworkUI implements View, NetworkProtocol, Observer {
	
	private Set<NetworkPlayer> players = ConcurrentHashMap.newKeySet();;
	private Game game;
	private int waitForPlayers = 0;
	
	public NetworkUI (Game game, Set<NetworkPlayer> players) {
		this.game = game;
		this.players.addAll(players);
	}
	
	public void update(Observable o, Object obj) {
		if (o instanceof NetworkPlayer) {
			NetworkPlayer player = (NetworkPlayer) o;
			try {
				if (obj.equals(READY)) {
					waitForPlayers -= 1;
					if (waitForPlayers == 0) {
						game.play();
					}
				} else if (obj.equals(REQUESTMOVE)) {
					determineMove(player);
				} else if (obj.equals(MAKEMOVE)) {
					Point point = player.getPoint();
					if (!player.hasTurn()) {
						throw new NotYourTurnException();
					} else if (player.getFromCube() == null) {
						throw new InvalidMoveException(point);
					} else {
						constructMoveMessage(player);
					}
				} else if (obj.equals(ERROR_USER_QUIT)) {
					quitGame(player);
				} else {
					throw new CommandNotRecognizedException();
				}
			} catch (NotYourTurnException e) {
				player.message(e.getMessage());
			} catch (InvalidMoveException e) {
				player.message(e.getMessage());
			} catch (CommandNotRecognizedException e) {
				player.message(e.getMessage());
			}
		} else if (o instanceof Game) {
			if (obj instanceof NetworkPlayer) {
				this.players.add((NetworkPlayer) obj);
			} else if (obj instanceof String) {
				String msg = (String) obj;
				if (msg.equals(READY)) {
					waitForPlayers = players.size();
					for (NetworkPlayer player : players) {
						player.checkReady();
					}
				}
			}
		}
	}
	
	public void run() {
		
	}
	
	public void showWinner(Player winner) {
		String winnerName = "";
		if (winner != null) {
			winnerName = winner.getName();
		}
		broadcast(GAMEOVER + winnerName);
	}
	
	public void determineMove(NetworkPlayer player) {
		
	}
	
	public void quitGame(NetworkPlayer player) {
		players.remove(player);
		unlockCommands();
		broadcast(ERROR_USER_QUIT + DELIMITER + player.getName());
		player = null;
		game.exit(ERROR_USER_QUIT);
	}
	
	public void constructMoveMessage(NetworkPlayer player) {
		player.setPoint(player.getFromCube());
		int[] coords = player.getPoint().strip();
		String message = SETMOVE + DELIMITER + player.getName();
		for (int coord : coords) {
			message += DELIMITER + coord;
		}
		broadcast(message);
		player.pointIsReady();
	}
	
	public void broadcast(String message) {
		try {
			for (NetworkPlayer player : players) {
				player.message(message);
			}
		} catch (Exception e) {
			System.out.println("NetworkUI broadcast failed...");
		}
	}
	
	public void unlockCommands() {
		for (NetworkPlayer player : players) {
			player.getHandler().unlockCommands();
		}
	}
}