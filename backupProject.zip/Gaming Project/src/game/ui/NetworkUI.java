package game.ui;

import java.util.Observer;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.logic.Player;

public class NetworkUI implements View, Observer {
	
	private Set<Player> players = ConcurrentHashMap.newKeySet();;
	
	public NetworkUI (Set<Player> players) {
		this.players.addAll(players);
	}
	
	public void update(Observable o, Object obj) {
		
	}
	
	public void showError(String message) {
		
	}
	public void inform(String message) {
		
	}
}