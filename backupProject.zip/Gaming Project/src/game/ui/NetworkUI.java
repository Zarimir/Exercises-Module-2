package game.ui;

import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.logic.Game;
import game.logic.Mark;
import game.logic.Player;
import game.network.NetworkPlayer;
import game.network.NetworkProtocol;

public class NetworkUI implements View, NetworkProtocol, Observer {
	
	private Set<Player> players = ConcurrentHashMap.newKeySet();;
	private Game game;
	
	public NetworkUI (Game game, Set<Player> players) {
		this.game = game;
		this.players.addAll(players);
	}
	
	public void update(Observable o, Object obj) {
		if (o instanceof NetworkPlayer) {
			NetworkPlayer player = (NetworkPlayer) o;
			if (obj.equals(REQUESTMOVE)) {
				player.getHandler().getMove();
			}
		}
	}
	
	public void showWinner(Player winner) {
		String winnerName = "";
		if (winner != null) {
			winnerName = winner.getName();
		}
		for (Player player : players) {
			if (player instanceof NetworkPlayer) {
				((NetworkPlayer) player).getHandler().sendMessage(GAMEOVER + winnerName);
			}
		}
	}
}