/**
 * 
 */
package game.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Scanner;

/**
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public abstract class TUI implements View {
	
	// ------------------------  Instance Variables  ------------------------
	
	private static final Scanner INPUT = new Scanner(System.in);
	
	private Map<String, Integer> commands = new HashMap<String, Integer>();
	
	// ------------------------ Constructor ------------------------
	
	public TUI() {
		
	}
	
	// ------------------------ Queries ------------------------
	
	/*
	public HyperCube getHyperCube() {
		return this.game.getHyperCube();
	}
	*/
	
	// ------------------------ Commands ------------------------
	
	
	public void getCommand() {
		String choice;
		System.out.println("What's your input? > ");
		choice = INPUT.nextLine();
		findCommand(choice);
	}
	
	public boolean containsCommand(String choice, String command) {
		String cut = choice.substring(0, command.length());
		return cut.equals(command);
	}
	
	public abstract void executeCommand(String[] arguments);
	
	public void showError(String error) {
		System.out.println(error);
	}
	
	public void inform(String message) {
		System.out.println(message);
	}
	
	public abstract void exit(String[] args);
	public abstract void showCommands(String[] args);
}
