/**
 * 
 */
package game.ui;

import java.util.Observable;
import java.util.Scanner;

import game.logic.Game;
import game.logic.GameProtocol;
import game.logic.HumanPlayer;
import game.logic.Mark;
import game.logic.Player;

/**
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public class PlayerTUI extends TUI implements GameProtocol {
	
	// ------------------------  Instance Variables  ------------------------
	
	private static final String COMMANDLIST = "?";
	private static final String EXIT = "EXIT";
	private static final String SHOW = "SHOW";	
	private static final String[] COMMANDS = {COMMANDLIST, EXIT, SHOW};
	private static final Scanner INPUT = new Scanner(System.in);
	private String forcedCommand;
	private Player currentPlayer;
	
	//private Map<String, Integer> commands;
	
	private Game game;
	
	// ------------------------ Constructor ------------------------
	
	public PlayerTUI(Game game) {
		this.game = game;
	}
	
	// ------------------------ Queries ------------------------
	
	// ------------------------ Commands ------------------------
	
	public void executeCommand(String[] args) {
		String command = args[0];
		if (forcedCommand != null && command.equals(forcedCommand) || forcedCommand == null) {
			switch (command) {
			case DETERMINE_MOVE:
				determineMove();
			case COMMANDLIST:
				showCommands(args);
				break;
			case EXIT:
				exit(args);
				break;
			}
		} else {
				showError(ERROR_ENFORCED_COMMAND);
		}
	}
	
	public void determineMove() {
		
	}
	
	public void update(Observable o, Object obj) {
		if (o instanceof HumanPlayer) {
			if (obj.equals(DETERMINE_MOVE)) {
				currentPlayer = (HumanPlayer) o;
				forcedCommand = DETERMINE_MOVE;
			}
		}
	}
	
	public void exit(String[] args) {
		inform("Done!");
		game.exit();
	}
	
	public String toString() {
		String list = "Commands:";
		for (int i = 0; i < COMMANDS.length; i++) {
			list += " " + COMMANDS[i];
		}
		return list;
	}
	
	public void showCommands(String[] args) {
		inform(this.toString());
	}
	
	public void showWinner(Mark winner) {
        if (winner == Mark.EMPTY) {
        	System.out.println("Draw. There is no winner!");
        } else {
        	String name = game.getPlayer(winner).getName();
        	System.out.println(name + " has won!");
        }
        getCommand();
    }
	
	public void showGame() {
		int current = 0;
		Mark[] marks = new Mark[16];
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 16; j++) {
				marks[j] = game.getHyperCube().getPoints().get(current).getMark();
			}
			printRow(marks);
		}
	}
	
	public void printRow(Mark[] marks) {
		for (int i = 0; i < marks.length; i++) {
			System.out.print("___");
		}
		System.out.println();
		for (int i = 0; i < marks.length; i++) {
			System.out.println("|" + marks[i] + "|");
		}
	}
	
	public int[] readCoordinates(Player player) {
		int dimension = game.getHyperCube().getDimension();
		int[] result;
		String choice;
		String[] cut;
		while(true) {
			inform("You need to input the index (1-16) or " + dimension + "dimensional point's coordinates!"
					+ "\nOr type EXIT");
			choice = INPUT.nextLine();
			cut = choice.split("[^0-9]+");
			if (cut.length == 1 || cut.length == dimension) {
				break;
			} else if (choice.equals(EXIT)) {
				exit(cut);
			} else {
				showError("Invalid index or coordinates");
			}
		}
		if (cut.length == 1) {
			result = new int[1];
			result[0] = Integer.parseInt(cut[0]);
		} else {
			result = new int[dimension];
			for (int i = 0; i < cut.length; i++) {
				result[i] = Integer.parseInt(cut[i]);
			}
		}
		return result;
	}
}
