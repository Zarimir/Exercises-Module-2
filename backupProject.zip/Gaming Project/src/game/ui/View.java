package game.ui;

public interface View {
    //public void start();
    public void showError(String message);
    public void inform(String message);
}