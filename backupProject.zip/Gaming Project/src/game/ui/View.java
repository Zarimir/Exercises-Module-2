package game.ui;

import java.util.Observer;

import game.logic.Player;

public interface View extends Observer {
    //public void start();
    public void showWinner(Player mark);
}