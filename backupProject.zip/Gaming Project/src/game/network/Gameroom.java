package game.network;

import java.util.Observable;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.ai.ComputerPlayer;
import game.logic.Game;

public class Gameroom extends Observable implements Protocol, Runnable {
	private Set<ClientHandler> queue = ConcurrentHashMap.newKeySet();
	private Set<Game> games = ConcurrentHashMap.newKeySet();
	
	public void update(ClientHandler handler) {
		if (handler.hasStatus(COMPUTER)) {
			if (handler.isReady()) {
				Game newGame = new Game();
				newGame.addPlayer(handler.getPlayer());
				newGame.addPlayer(new ComputerPlayer());
				games.add(newGame);
			}
		}
		if (isInQueue(player)) {
			computerWaiters.remove(player);
		} else {
			waiters.add(player);
		}
		humanWaiters.add(player);
	}
	
	public void remove(NetworkPlayer player) {
		waiters.remove(player);
		computerWaiters.remove(player);
		humanWaiters.remove(player);
	}
	
	public boolean checkForNewGames() {
		if (computerWaiters.size() > 2) {
			
		} else if (humanWaiters.size() > 2) {
			
		}
	}
	
	public boolean checkIfReady(NetworkPlayer player1, ComputerPlayer player2) {
		player1.getHandler().isReady(player2);
		try {
			Thread.sleep(20 * 1000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}
	
	public boolean checkIfReady(NetworkPlayer player1, NetworkPlayer player2) {
		player1.getHandler().isReady(player2.getName());
		this.setChanged());
		this.notifyObservers("String");
		if ()
		player2.getHandler().isReady(player1);
		try {
			Thread.sleep(20 * 1000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}
	
	
	private Lock myLock = new ReentrantLock();
	private Condition condition = myLock.newCondition();
	
	private void method() {
		myLock.lock();
	
		try {
			boolean responseReceived = condition.await(1000, TimeUnit.MILLISECONDS);
			if (responseReceived) {
				
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		myLock.unlock();
	}
	
	private void receiveResponse() {
		myLock.lock();
		condition.signal();
		myLock.unlock();
	}
}
