package game.network;

import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.ai.ComputerPlayer;
import game.logic.Game;

public class Gameroom extends Observable implements Observer, NetworkProtocol {
	private Set<Game> lobbies = ConcurrentHashMap.newKeySet();
	private Set<Game> games = ConcurrentHashMap.newKeySet();
	
	
	public void update(Observable o, Object obj) {
		if (o instanceof Game) {
			Game game = (Game) o;
			if (obj.equals(READY)) {
				games.add(game);
				if (lobbies.contains(game)) {
					lobbies.remove(game);
				}
			} else if (obj.equals(ERROR_USER_QUIT)) {
				lobbies.add(game);
				if (games.contains(game)) {
					games.remove(game);
				}
			} else if (games.contains(game) && obj.equals(GAMEOVER)) {
				games.remove(game);
			}
		}
	}
	
	public void addPlayer(NetworkPlayer player, String opponent) {
		
		if (opponent.equals(COMPUTER)) {
			Game game = new Game();
			game.addPlayer(player);
			game.addPlayer(new ComputerPlayer());
			game.setReady();
			games.add(game);
		} else {
			lobby.addPlayer(player);
			if (lobby.getPlayers().size() == 2) {
				lobby.setReady();
				games.add(lobby);
				lobby = new Game();
			}
		}
		
	}
	
	/*
	
	private Lock myLock = new ReentrantLock();
	private Condition condition = myLock.newCondition();
	
	private void method() {
		myLock.lock();
	
		try {
			boolean responseReceived = condition.await(1000, TimeUnit.MILLISECONDS);
			if (responseReceived) {
				
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		myLock.unlock();
	}
	
	public void receiveResponse() {
		myLock.lock();
		condition.signal();
		myLock.unlock();
	}
	
	public void gameInterrupted(Game game, Player player, String message) {
		
	}
	*/
}
