package game.network.exception;

import game.geometry.Point;
import game.network.NetworkProtocol;

public class InvalidMoveException extends Exception implements NetworkProtocol {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2992471290598694020L;

	public InvalidMoveException() {
		super(ERROR_INVALID_MOVE);
	}
	
	public InvalidMoveException(Point point) {
		super(constructMessage(point));
	}
	
	public static String constructMessage(Point point) {
		String message = ERROR_INVALID_MOVE;
		message = ERROR_INVALID_MOVE;
		int[] coords = point.strip();
		for (int coord : coords) {
			message += DELIMITER + coord;
		}
		return message;
	}
}
