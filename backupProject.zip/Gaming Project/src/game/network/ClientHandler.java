package game.network;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.logic.Game;
import game.logic.Player;
import game.network.exception.CommandNotRecognizedException;
import game.network.exception.UsernameTakenException;

public class ClientHandler implements Observer, NetworkProtocol, Runnable {
	private Server server;
	private BufferedReader in;
	private BufferedWriter out;
	private String clientName = null;
	private Set<String> possible = ConcurrentHashMap.newKeySet();
	private Set<String> status = ConcurrentHashMap.newKeySet();
	private Game game;
	private NetworkPlayer player;
	
	
	/**
	 * Constructs a ClientHandler object
	 * Initializes both Data streams.
	 */
	//@ requires serverArg != null && sockArg != null;
	public ClientHandler(Server serverArg, Socket sockArg) throws IOException {
		this.server = serverArg;
		in = new BufferedReader(new InputStreamReader(sockArg.getInputStream()));
		out = new BufferedWriter(new OutputStreamWriter(sockArg.getOutputStream()));
		possible.add(HELLO);
	}
	
	public String getClientName() {
		return clientName;
	}
	
	//public void requestMove();
	
	public void update(Observable obj, Object o) {
		
	}
	
	/**
	 * Reads the name of a Client from the input stream and sends
	 * a broadcast message to the Server to signal that the Client
	 * is participating in the chat. Notice that this method should
	 * be called immediately after the ClientHandler has been constructed.
	 */
	public void greet(String[] args) throws IOException {
		try {
			if (args.length < 2) {
				throw new CommandNotRecognizedException();
			} else if (server.getHandler(args[1]) != null) {
				throw new UsernameTakenException();
			} else {
				String reply = HELLO;
				clientName = args[1];
				
				if (contains(EXT_CHAT, args)) {
					status.add(EXT_CHAT);
					reply += DELIMITER + EXT_CHAT;
				}
				unlockCommands();
				sendMessage(reply);
				server.broadcast(Server.NAME + DELIMITER + "["+ clientName + " is now online.]");
			}
		} catch (CommandNotRecognizedException e) {
			sendMessage(e.getMessage());
		} catch (UsernameTakenException e) {
			sendMessage(e.getMessage());
		}
	}
	
	public void unlockCommands() {
		possible = ConcurrentHashMap.newKeySet();
		possible.add(PLAY);
		if (status.contains(EXT_CHAT)) {
			possible.add(WHISPER);
			possible.add(BROADCAST);
			possible.add(CHATUSERS);
		}
	}
	
	/**
	 * This method takes care of sending messages from the Client.
	 * Every message that is received, is prepended with the name
	 * of the Client, and the new message is offered to the Server
	 * for broadcasting. If an IOException is thrown while reading
	 * the message, the method concludes that the socket connection is
	 * broken and shutdown() will be called.
	 */
	public void run() {
		try {
			String command = in.readLine();
			while (command != null) {
				executeCommand(command);
				//server.broadcast(clientName + ": " + command);
				command = in.readLine();
			}
			shutdown();
		} catch (IOException e) {
			shutdown();
		}
	}
	
	/**
	 * This method can be used to send a message over the socket
	 * connection to the Client. If the writing of a message fails,
	 * the method concludes that the socket connection has been lost
	 * and shutdown() is called.
	 */
	public void sendMessage(String msg) {
		try {
			out.write(msg);
			out.newLine();
			out.flush();
		} catch (IOException e) {
			shutdown();
		}
	}
	
	/**
	 * This ClientHandler signs off from the Server and subsequently
	 * sends a last broadcast to the Server to inform that the Client
	 * is no longer participating in the chat.
	 */
	private void shutdown() {
		server.removeHandler(this);
		server.broadcast(Server.NAME + DELIMITER + "[" + clientName + " is now offline.]");
	}
	
	public void requestCommands(Set<String> commands) {
		this.possible = ConcurrentHashMap.newKeySet(); 
		for (String command : commands) {
			this.possible.add(command);
		}
	}
	
	public void executeCommand(String attempt) {
		String command = attempt.split(DELIMITER)[0];
		String[] args = attempt.split(DELIMITER);
		if (possible.contains(command)) {
			try {
				switch (command) {
				case HELLO:
					greet(args);
					break;
				case PLAY:
					play(args);
					break;
				case READY:
					//isReady(args);
					break;
				/*
				case BROADCAST:
					broadcast(args);
					break;
				case WHISPER:
					whisper(args);
					break;
				case CHATUSERS:
					sendChatusers(args);
					break;
				*/
				}
			} catch (IOException e) {
				sendMessage(ERROR_COMMAND_NOT_RECOGNIZED);
			}
		} else {
			sendMessage(ERROR_UNEXPECTED + listPossible());
		}
	}
	
	public String listPossible() {
		String possibleList = "";
		for (String command : possible) {
			possibleList += DELIMITER + command;
		}
		return possibleList;
	}
	
	public void broadcast(String[] args) {
		if (args.length > 1) {
			server.broadcast(clientName + DELIMITER + args[1]);
		}
	}
	
	//NOT YET IMPLEMENTED
	/*
	public void whisper(String[] args) {
		
		try {
			if (args.length > 2) {
				ClientHandler messageTo = server.getHandler(args[1]);
				if (messageTo != null) {
					if (messageTo.hasStatus(EXT_CHAT)) {
						messageTo.sendMessage("Test");
						messageTo.sendMessage(WHISPER + DELIMITER + clientName + DELIMITER + args[2]);
					} else {
						throw new HasNoChatException();
					}
				} else {
					throw new UserNotFoundException();
					sendMessage(ERROR_USER_NOT_FOUND);
				}
			}
		} catch (HasNoChatException){
			
		}
		
	}
	*/
	
	public void play(String[] args) {
		try {
			if (args.length > 1 && (args[1].equals(HUMAN)|| args[1].equals(COMPUTER))) {
				this.player = new NetworkPlayer(this);
				sendMessage(WAIT);
				possible.remove(PLAY);
				server.addPlayer(this.player, args[1]);
			} else {
				throw new CommandNotRecognizedException();
			}
		} catch (CommandNotRecognizedException e) {
			sendMessage(e.getMessage());
		}
	}
	
	public boolean contains(String arg, String[] args) {
		for (int i = 1; i < args.length; i++) {
			if (args[i].equals(arg)) {
				return true;
			}
		}
		return false;
	}
	
	public Set<String> getStatus() {
		return status;
	}
	
	public void sendChatusers(String[] args) {
		System.out.println("About to execute");
		server.sendChatusers(this);
	}
	
	public boolean hasStatus(String status) {
		return this.status.contains(status);
	}
	
	public Player getPlayer() {
		return this.player;
	}
	/*
	public boolean isReady(String oponent) {
		suspendExpected(READY);
		sendMessage(READY + DELIMITER + clientName + DELIMITER + oponent);
	}
	*/
}