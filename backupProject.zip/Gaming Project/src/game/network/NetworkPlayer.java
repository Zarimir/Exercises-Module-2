package game.network;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.logic.Player;

/**
 * Handles the Network Player of the Game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class NetworkPlayer extends Player implements NetworkProtocol {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param strategy of this ComputerPlayer
	 */
	private ClientHandler handler;
	private Lock lock = new ReentrantLock();
	private Condition condition = lock.newCondition();
	//private status;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Constructs a Computer Player with a given strategy and a mark arguments.
	 * @param strategy of this ComputerPlayer
	 * @param mark of this ComputerPlayer
	 */
	public NetworkPlayer(ClientHandler handler) {
        super(handler.getClientName());
        this.handler = handler;
    }
	
	// ------------------------ Queries ------------------------
	
	public ClientHandler getHandler() {
		return this.handler;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Determines next move based on current strategy.
	 * @param board of the Game
	 */
	public void determinePoint() {
		lock.lock();
		getHandler().requestMove();
		try {
			this.setChanged();
			this.notifyObservers(REQUESTMOVE);
			boolean pointIsReady = condition.await(20, TimeUnit.SECONDS);
			if (!pointIsReady) {
				
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		lock.unlock();
	}
	
	public void pointIsReady() {
		lock.lock();
		condition.signal();
		lock.unlock();
	}
}