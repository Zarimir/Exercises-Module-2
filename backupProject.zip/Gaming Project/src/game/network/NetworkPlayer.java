package game.network;

import game.ai.Strategy;
import game.geometry.Point;
import game.logic.Game;
import game.logic.Player;

/**
 * Handles the Network Player of the Game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class NetworkPlayer extends Player {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param strategy of this ComputerPlayer
	 */
	private Strategy strategy;
	private ClientHandler handler;
	//private status;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Constructs a Computer Player with a given strategy and a mark arguments.
	 * @param strategy of this ComputerPlayer
	 * @param mark of this ComputerPlayer
	 */
	public NetworkPlayer(ClientHandler handler) {
        super(handler.getName());
        this.handler = handler;
    }
	
	// ------------------------ Queries ------------------------
	
	public ClientHandler getHandler() {
		return this.handler;
	}
	
	/**
	 * Gets the strategy of this ComputerPlayer
	 * @return this.strategy
	 */
	public Strategy getStrategy() {
		return this.strategy;
	}
	
	/**
	 * Determines next move based on current strategy.
	 * @param board of the Game
	 */
	public Point determineMove(Game game) {
		Point found;
		Point target;
		target = new Point(handler.getCoords());
		found = game.getHyperCube().getPoint(target);
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the strategy of this Computer Player.
	 * @param strategy
	 */
	public void setStrategy(Strategy strategy) {
		this.strategy = strategy;
	}
	
	public void makeMove() {
		
	}
}
