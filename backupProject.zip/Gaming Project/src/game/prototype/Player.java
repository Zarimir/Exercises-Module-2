package game.prototype;

/**
 * Abstract class for keeping a player in the Tic Tac Toe game.
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public abstract class Player {
	
	// ------------------------ Instance Variables ------------------------

	/**
	 * Instance Variables.
	 * @param name of the Player
	 * @param mark of the Player
	 */
    private String name;
    private Mark mark;

	// ------------------------ Constructor ------------------------
    
    /**
     * Constructs a player with a given name and mark arguments.
     * @param name of the player
     * @param mark of the player
     */
    //@ requires name != null;
    //@ requires mark == Mark.XX || mark== Mark.OO;
    //@ ensures this.getName() == name;
    //@ ensures this.getMark() == mark;
    public Player(String name, Mark mark) {
        this.name = name;
        this.mark = mark;
    }

	// ------------------------ Queries ------------------------

    /**
     * Gets the name of the player.
     * @return this.name
     */
    /*@ pure */ public String getName() {
        return name;
    }

    /**
     * Gets the mark of the player.
     * @return this.mark
     */
    /*@ pure */ public Mark getMark() {
        return mark;
    }
    
    /**
     * Determines the field for the next move.
     * @param board the current game board
     * @return the player's choice
     */
    //@ requires board != null && board.getWinner() == null;
    //@ ensures \result != null;
    public abstract Point determineMove(HyperCube board);

	// ------------------------ Commands ------------------------
    
    //@ requires board != null && board.getWinner() == null;
    /**
     * Makes a move on the board.
     * @param board the current board
     */
    public void makeMove(HyperCube board) {
        Point choice = determineMove(board);
        board.mark(choice, this.mark);
    }
}