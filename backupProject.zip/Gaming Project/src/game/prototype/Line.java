/**
 * 
 */
package game.prototype;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Zarry
 *
 */
public class Line {
	
	// ------------------------ Instance Variables ------------------------
	
	//@ private invariant points != null;
	private Point[] points;
	
	// ------------------------ Constructors ------------------------
	
	//@ requires points != null;
	public Line(Point[] points) {
		this.points = Point.copy(points);
	}
	
	public Line(List<Point> points) {
		//assert points.length == cube.getLength();
		this.points = new Point[points.size()];
		for (int i = 0; i < points.size(); i++) {
			this.points[i] = points.get(i);
		}
	}
	
	//@ requires length > 0;
	public Line(int dimension, int length) {
		Point[] temp = new Point[length];
		for (int i = 0; i < length; i++) {
			temp[i] = new Point(dimension);
		}
		this.points = temp;
	}
	
	public String toString() {
		String s = "";
		for (int i = 0; i < this.points.length - 1; i++) {
			s += this.points[i] + ",";
		}
		s += this.points[this.points.length - 1] + ";";
		return s;
	}
	
	// ------------------------ Queries ------------------------
	
	public Line copy() {
		List<Point> metaPoints = new ArrayList<Point>();
		for (int i = 0; i < points.length; i++) {
			metaPoints.add(points[i].copy());
		}
		return new Line(metaPoints);
	}
	
	public Point[] getPoints() {
		return this.points;
	}
	
	public Mark ownedBy() {	
		Mark owner = Mark.EMPTY;
		boolean hasWinner = true;
		for (int i = 0; i < this.points.length; i++) {
			if (owner.equals(Mark.EMPTY) &&
					!this.points[i].getMark().equals(owner)) {
				owner = this.points[i].getMark();
			} else if (!owner.equals(Mark.EMPTY) &&
					!this.points[ i ].getMark().equals(owner)) { //////////////////////////////////////// if points[i] == empty
				owner = null;
				hasWinner = false;
				break;
			}
			if (this.points[i].getMark().equals(Mark.EMPTY)) {
				hasWinner = false;
			}
		}
		
		if (owner == null) {
			return null;
		} else if (!hasWinner) {
			return Mark.EMPTY;
		} else {
			return owner;
		}
	}
	
	// ------------------------ Comparisons ------------------------
	
	public boolean equals(Line line) {
		if (points.length != line.getPoints().length) {
			return false;
		}
		for (int i = 0; i < points.length; i++) {
			if (!points[i].equals(line.getPoints()[i])) {
				return false;
			}
		}
		return true;
	}
	
	// ------------------------ Commands ------------------------
	
	public void setIteratableCoordinateAt(int dimension, boolean increasing) {
		if (increasing) {
			for (int i = 0; i < points.length; i++) {
				points[i].getCoordinate(dimension).setValue(i);
			}
		} else {
			for (int i = 0; i < points.length; i++) {
				points[i].getCoordinate(dimension).setValue(points.length - i - 1);
			}
		}
	}
	
	// ------------------------ Static Commands ------------------------
	
	public static boolean checkForDuplicates(List<Line> l) {
		List<Line> lines = new ArrayList<Line>();
		for (int i = 0; i < l.size(); i++) {
			lines.add(l.get(i).copy());
		}
		Line holder;
		while(lines.size() > 0) {
			holder = lines.remove(lines.size() - 1);
			for (int i = 0; i < lines.size(); i++) {
				if (holder.equals(lines.get(i))) {
					return true;
				}
			}
		}
		return false;
	}
}