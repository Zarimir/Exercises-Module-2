/**
 * 
 */
package game.prototype;

import java.util.List;

/**
 * @author Zarry
 *
 */
public class Line {
	
	public static void main(String[] args) {
		
	}
	
	// ------------------------ Constructor ------------------------
	
	//@ private invariant points != null;
	//private HyperCube cube;
	private Point[] points;
	private int index = 0;
	
	//@ requires points != null;
	public Line(Point[] points) throws ArithmeticException {
		//assert points.length == cube.getLength();
		this.points = Point.copy(points);
	}
	
	public Line(List<Point> points) throws ArithmeticException {
		//assert points.length == cube.getLength();
		this.points = new Point[points.size()];
		for (int i = 0; i < points.size(); i++) {
			this.points[i] = points.get(i);
		}
	}
	
	public Line(Line line) {
		this.points = line.getPoints().clone();
	}
	
	//@ requires length > 1;
	public Line(int dimension, int length) {
		Point[] temp = new Point[length];
		for (int i = 0; i < length; i++) {
			temp[i] = new Point(dimension);
		}
		this.points = temp;
	}
	
	//@ requires cube != null;
	public Line(HyperCube cube) {
		this(cube.getDimension(), cube.getLength());
	}
	
	public String toString() {
		String s = "";
		for (int i = 0; i < this.points.length - 1; i++) {
			s += this.points[i] + ",";
		}
		s += this.points[this.points.length - 1] + ";";
		return s;
	}
	
	public Point[] getPoints() {
		return this.points;
	}
	
	public Mark ownedBy() {	
		Mark owner = Mark.EMPTY;
		boolean hasWinner = true;
		for (int i = 0; i < this.points.length; i++) {
			if (owner.equals(Mark.EMPTY) &&
					!this.points[i].getMark().equals(owner)) {
				owner = this.points[i].getMark();
			} else if (!owner.equals(Mark.EMPTY) &&
					!this.points[i].getMark().equals(owner)) {
				owner = null;
				hasWinner = false;
				break;
			}
			if (this.points[i].getMark().equals(Mark.EMPTY)) {
				hasWinner = false;
			}
		}
		
		if (owner == null) {
			return null;
		} else if (!hasWinner) {
			return Mark.EMPTY;
		} else {
			return owner;
		}
	}
	
	public static void prnt(List<Line> lines) {
		String s = "";
		for (int i = 0; i < lines.size(); i++) {
			s += "Line " + i + ": ";
			s += lines.get(i).toString() + "\n";
		}
		System.out.println(s);
	}
	
	public void next() {
		index = Math.modulo(index + 1, points.length);
	}
	
	public void previous() {
		index = Math.modulo(index - 1, points.length);
	}
	
	public void setPoint(Point point) {
		points[index] = new Point(point);
		//System.out.println("Index = " + index + ", point: " + points[index]);
	}
	
	public int getIndex() {
		return this.index;
	}
	
	public void reset() {
		this.index = 0;
	}
}