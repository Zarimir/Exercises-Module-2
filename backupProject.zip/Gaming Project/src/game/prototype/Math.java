package game.prototype;

public class Math {
	public static void main(String[] args) {
		//System.out.println(Math.pow(-1, 2));
		System.out.println(Math.variations(0, 4));
	}
	/**
	 * Raises a number to the power of another number.
	 * @param number
	 * @param power has to be >= 0
	 * @return number ^ power
	 * @throws ArithmeticException whenever the power is less than 1
	 */
	//@ requires power > -1;
	/*@ pure */ public static int pow(int number, int power) throws ArithmeticException {
		//System.out.println("myMath");
		if (power >= 0) {
			int result = 1;
			for (int i = 0; i < power; i++) {
				result *= number;
			}
			return result;
		} else {
			throw new ArithmeticException("This method does NOT allow powers lower than 0!");
		}
	}
	
	//@ requires mod > 0;
	public static int modulo(int num, int mod) throws ArithmeticException {
		int result;
		result = num;
		while (result < 0) {
			result += mod;
			//System.out.println(result + " : " + mod);
		}
		while (result >= mod) {
			result -= mod;
			//System.out.println("-");
		}
		//System.out.println(result);
		return result;
	}
	
	public static int variations(int numbers, int totalNumbers) {
		int result = 1;
		int del = 1;
		for (int i = 1; i <= numbers; i++) {
			del *= i;
			result *= totalNumbers + 1 - i;
		}
		return result / del;
	}
}
