package game.prototype;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Queue extends Thread {
	private Set<Player> waiters = new HashSet<Player>();
	private Set<Player> humanWaiters = new HashSet<Player>();
	private Set<Player> computerWaiters = new HashSet<Player>();
	private List<Game> games = new ArrayList<Game>();
	
	public boolean isInQueue(NetworkPlayer player) {
		return waiters.contains(player);
	}
	
	public void addHumanWaiter(NetworkPlayer player) {
		if (isInQueue(player)) {
			computerWaiters.remove(player);
		} else {
			waiters.add(player);
		}
		humanWaiters.add(player);
	}
	
	public void addComputerWaiter(NetworkPlayer player) {
		if (isInQueue(player)) {
			humanWaiters.remove(player);
		} else {
			waiters.add(player);
		}
		computerWaiters.add(player);
	}
	
	public void removePlayer(NetworkPlayer player) {
		waiters.remove(player);
		computerWaiters.remove(player);
		humanWaiters.remove(player);
	}
	
	public boolean checkForNewGames() {
		if (computerWaiters.size() > 2) {
			
		} else if (humanWaiters.size() > 2) {
			
		}
	}
	
	public boolean checkIfReady(NetworkPlayer player) {
		return player.getHandler().isReady();
	}
}
