package game.prototype;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The controller of the game according to the MVC model.
 * Unifies the model, view and networking aspects of the game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class Game {
	
	public static void main(String[] args) {
		Player player1 = new HumanPlayer("Pesho", Mark.XX);
		Player player2 = new HumanPlayer("Dani", Mark.OO);
		//Game game = new Game(player1, player2);
		//game.start();
	}

	// ------------------------ Instance Variables ------------------------

    /**
     * Instance Variables.
     * @param board of this <code>Game</code>
     * @param platers of this <code>Game</code>
     * @param current the index of the current <code>Player</code>
     */
    //@ private invariant board != null;
	//@ private invariant (\forall int i; 0 <= i && i < NUMBER_PLAYERS; players[i] != null);
	//@ private invariant 0 <= current  && current < NUMBER_PLAYERS;
	private HyperCube board;
	private List<Player> players = new ArrayList<Player>();
    private int current;
    private View view;
    private boolean status;
    

    // ------------------------ Constructor ------------------------

    //@ requires s0 != null;
    //@ requires s1 != null;
    public Game() {
        current = 0;
        view = new PlayerTUI(this);
        board = new HyperCube(2, 3);
        board.initialize();
    }
    
    // ------------------------ Queries ------------------------
    
    public HyperCube getHyperCube() {
    	return this.board;
    }
    
    public List<Player> getPlayers() {
    	return this.players;
    }
    
    // ------------------------ Commands ------------------------

    /**
     * Starts the Tic Tac Toe game. <br>
     * Asks after each ended game if the user wants to continue. Continues until
     * the user does not want to play anymore.
     */
    public void start() {
        boolean again = true;
        while (again) {
            reset();
            play();
            view.showResult(getPlayer(board.getWinner()));
        }
    }

    /**
     * Resets the game. <br>
     * The board is emptied and player[0] becomes the current player.
     */
    private void reset() {
        current = 0;
        board.initialize();
    }

    /**
     * Plays the Tic Tac Toe game. <br>
     * First the (still empty) board is shown. Then the game is played until it
     * is over. Players can make a move one after the other. After each move,
     * the changed game situation is printed.
     */
    private void play() {
    	this.update();
    	while (board.getWinner() == null && status != false) {
    		Player player = players.get(current);
    		player.makeMove(this.board);
    		
    		this.current = (this.current + 1) % 2;
    		this.update();
    	}
    	this.printResult();
    }

    /**
     * Prints the game situation.
     */
    private void update() {
    	System.out.println(board.getMetaLines());
    }

    /*@
       requires this.board.gameOver();
     */

    /**
     * Prints the result of the last game. <br>
     */
    public void printResult() {
        if (board.getWinner() != null && board.getWinner() != Mark.EMPTY) {
            Mark winner = board.getWinner();
            System.out.println("Winner " + winner + " has won!");
        } else {
            System.out.println("Draw. There is no winner!");
        }
    }
    
    public void exit() {
    	this.status = false;
    }
    
    public void addPlayer(Player newPlayer) {
    	players.add(newPlayer);
    }
    
    public Player getPlayer(Mark mark) {
    	if (mark == null) {
    		return null;
    	} else {
    		for (int i = 0; i < players.size(); i++) {
    			if (players.get(i).getMark() == mark) {
    				return players.get(i);
    			}
    		}
    		return null;
    	}
    }
    
    public void getHumanMove() {
    	((TUI) view).readCoordinates(players.get(current));
    }
}