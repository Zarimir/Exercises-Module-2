/**
 * 
 */
package game.prototype;

/**
 * @author Zarry
 *
 */
public class Game {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mark m = Mark.XX;
		System.out.println(m.other().other().other().other());
	}
	
	
	

}
