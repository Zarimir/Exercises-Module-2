package game.prototype;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ClientHandler extends Thread implements Protocol {
	private Server server;
	private BufferedReader in;
	private BufferedWriter out;
	private String clientName = null;
	private Set<String> expected = ConcurrentHashMap.newKeySet();
	private Set<String> expectedSuspended = ConcurrentHashMap.newKeySet();
	private Set<String> status = ConcurrentHashMap.newKeySet();
	private Game game;
	private Player player;
	
	
	/**
	 * Constructs a ClientHandler object
	 * Initializes both Data streams.
	 */
	//@ requires serverArg != null && sockArg != null;
	public ClientHandler(Server serverArg, Socket sockArg) throws IOException {
		this.server = serverArg;
		in = new BufferedReader(new InputStreamReader(sockArg.getInputStream()));
		out = new BufferedWriter(new OutputStreamWriter(sockArg.getOutputStream()));
		expected.add(HELLO);
	}
	
	public String getClientName() {
		return clientName;
	}
	
	/**
	 * Reads the name of a Client from the input stream and sends
	 * a broadcast message to the Server to signal that the Client
	 * is participating in the chat. Notice that this method should
	 * be called immediately after the ClientHandler has been constructed.
	 */
	public void greet(String[] args) throws IOException {
		if (args.length < 2) {
			sendMessage(ERROR_COMMAND_NOT_RECOGNIZED);
		} else {
			String name = args[1];
			if (server.getHandler(name) == null) {
				clientName = name;
				sendMessage(HELLO);
				expected.remove(HELLO);
				expected.add(PLAY);
				expected.add(WHISPER);
				expected.add(BROADCAST);
				expected.add(CHATUSERS);
				expected.add(LEADERBOARD);
				server.broadcast("["+ clientName + " is now online.]");
				if (contains(EXT_CHAT, args)) {
					status.add(EXT_CHAT);
					sendMessage("Has chat");
				}
				if (contains(EXT_CHALLENGE, args)) {
					status.add(EXT_CHALLENGE);
				}
			} else {
				sendMessage(ERROR_USERNAME_TAKEN);
			}
		}
		//("[" + clientName + " has entered]");
	}
	
	/**
	 * This method takes care of sending messages from the Client.
	 * Every message that is received, is prepended with the name
	 * of the Client, and the new message is offered to the Server
	 * for broadcasting. If an IOException is thrown while reading
	 * the message, the method concludes that the socket connection is
	 * broken and shutdown() will be called.
	 */
	public void run() {
		try {
			String command = in.readLine();
			while (command != null) {
				executeCommand(command);
				//server.broadcast(clientName + ": " + command);
				command = in.readLine();
			}
			shutdown();
		} catch (IOException e) {
			shutdown();
		}
	}
	
	/**
	 * This method can be used to send a message over the socket
	 * connection to the Client. If the writing of a message fails,
	 * the method concludes that the socket connection has been lost
	 * and shutdown() is called.
	 */
	public void sendMessage(String msg) {
		try {
			out.write(msg);
			out.newLine();
			out.flush();
		} catch (IOException e) {
			shutdown();
		}
	}
	
	/**
	 * This ClientHandler signs off from the Server and subsequently
	 * sends a last broadcast to the Server to inform that the Client
	 * is no longer participating in the chat.
	 */
	private void shutdown() {
		server.removeHandler(this);
		server.broadcast("[" + clientName + " is now offline.]");
	}
	
	public void executeCommand(String attempt) {
		String command = attempt.split(DELIMITER)[0];
		String[] args = attempt.split(DELIMITER);
		if (expected.contains(command) || expected.size() == 0) {
			try {
				switch (command) {
				case HELLO:
					greet(args);
					break;
				case PLAY:
					play(args);
					break;
				case READY:
					isReady(args);
					break;
				case BROADCAST:
					broadcast(args);
					break;
				case WHISPER:
					whisper(args);
					break;
				case CHATUSERS:
					sendChatusers(args);
					break;
				default:
					sendMessage(ERROR_COMMAND_NOT_RECOGNIZED);
					break;
				}
			} catch (IOException e) {
				sendMessage(ERROR_COMMAND_NOT_RECOGNIZED);
			}
		} else {
			sendMessage(ERROR_UNEXPECTED + DELIMITER + expected);
		}
	}
	
	public void broadcast(String[] args) {
		if (args.length > 1) {
			server.broadcast(clientName + DELIMITER + args[1]);
		}
	}
	
	public void whisper(String[] args) {
		if (args.length > 2) {
			ClientHandler messageTo = server.getHandler(args[1]);
			if (messageTo != null) {
				if (messageTo.hasStatus(EXT_CHAT)) {
					messageTo.sendMessage("Test");
					messageTo.sendMessage(WHISPER + DELIMITER + clientName + DELIMITER + args[2]);
				} else {
					sendMessage(ERROR_USER_HAS_NO_CHAT);
				}
			} else {
				sendMessage(ERROR_USER_NOT_FOUND);
			}
		}
	}
	
	public void play(String[] args) {
		boolean human = contains(HUMAN, args);
		boolean computer = contains(COMPUTER, args); 
		if (human || computer) {
			this.player = new NetworkPlayer(this);
			sendMessage(WAIT);
			if (human) {
				status.add(HUMAN);
			} else if (computer) {
				status.add(COMPUTER);
			}
		} else {
			sendMessage(ERROR_COMMAND_NOT_RECOGNIZED);
		}
	}
	
	public boolean contains(String arg, String[] args) {
		for (int i = 1; i < args.length; i++) {
			if (args[i].equals(arg)) {
				return true;
			}
		}
		return false;
	}
	
	public Set<String> getStatus() {
		return status;
	}
	
	public void sendChatusers(String[] args) {
		System.out.println("About to execute");
		server.sendChatusers(this);
	}
	
	public boolean hasStatus(String status) {
		return this.status.contains(status);
	}
	
	public Player getPlayer() {
		return this.player;
	}
	
	public void suspendExpected(String forcedCommand) {
		expectedSuspended.addAll(expected);
		expected = ConcurrentHashMap.newKeySet();
		expected.add(forcedCommand);
	}
	
	public void restoreExpected() {
		expected.addAll(expectedSuspended);
		expectedSuspended = ConcurrentHashMap.newKeySet();
	}
	
	public boolean isReady(String oponent) {
		suspendExpected(READY);
		sendMessage(READY + DELIMITER + clientName + DELIMITER + oponent);
	}
}