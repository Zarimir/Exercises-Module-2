package game.prototype;

/**
 * Handles the Computer Player of the Game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class ComputerPlayer extends Player {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param strategy of this ComputerPlayer
	 */
	private Strategy strategy;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Constructs a ComputerPlayer with a given mark argument and
	 * a  Naive Strategy by default.
	 * @param mark of this Player
	 */
	public ComputerPlayer(Mark mark) {
        this(new NaiveStrategy(), mark);
    }
	
	/**
	 * Constructs a Computer Player with a given strategy and a mark arguments.
	 * @param strategy of this ComputerPlayer
	 * @param mark of this ComputerPlayer
	 */
	public ComputerPlayer(Strategy strategy, Mark mark) {
        super(strategy.getName(), mark);
        this.strategy = strategy;
    }
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Gets the strategy of this ComputerPlayer
	 * @return this.strategy
	 */
	public Strategy getStrategy() {
		return this.strategy;
	}
	
	/**
	 * Determines next move based on current strategy.
	 * @param board of the Game
	 */
	public Point determineMove(HyperCube board) {
		return this.getStrategy().determineMove(board, this.getMark());
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the strategy of this Computer Player.
	 * @param strategy
	 */
	public void setStrategy(Strategy strategy) {
		this.strategy = strategy;
	}
}
