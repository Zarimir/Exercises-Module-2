package game.prototype;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Gameroom extends Thread implements Protocol {
	private Set<ClientHandler> queue = ConcurrentHashMap.newKeySet();
	private Set<Game> games = ConcurrentHashMap.newKeySet();
	
	public void update(ClientHandler handler) {
		if (handler.hasStatus(COMPUTER)) {
			if (handler.isReady()) {
				Game newGame = new Game();
				newGame.addPlayer(handler.getPlayer());
				newGame.addPlayer(new ComputerPlayer());
				games.add(newGame);
			}
		}
		if (isInQueue(player)) {
			computerWaiters.remove(player);
		} else {
			waiters.add(player);
		}
		humanWaiters.add(player);
	}
	
	public void remove(NetworkPlayer player) {
		waiters.remove(player);
		computerWaiters.remove(player);
		humanWaiters.remove(player);
	}
	
	public boolean checkForNewGames() {
		if (computerWaiters.size() > 2) {
			
		} else if (humanWaiters.size() > 2) {
			
		}
	}
	
	public boolean checkIfReady(NetworkPlayer player1, ComputerPlayer player2) {
		player1.getHandler().isReady(player2);
		try {
			Thread.sleep(20 * 1000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}
	
	public boolean checkIfReady(NetworkPlayer player1, NetworkPlayer player2) {
		player1.getHandler().isReady(player2.getName());
		if ()
		player2.getHandler().isReady(player1);
		try {
			Thread.sleep(20 * 1000);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}
}
