package game.prototype;

public class Menu {
	private static final String SERVER = "SERVER";
	private static final String CLIENT = "CLIENT";
	private static final String GAME = "GAME";
}
