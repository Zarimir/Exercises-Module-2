package game.prototype;

/**
 * @author Zarimir
 * @version 3.0
 */
public class Point {

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension the dimensions of the points
	 * @param coordinates the coordinates of the point
	 * @param mark the mark of the point
	 */
	//@ private invariant dimension > 1;
	//@ private invariant coordinates.length > 1;
	//@ private invariant mark != null;
	private Coordinate[] coordinates;
	private Mark mark;
	
	// ------------------------ Constructor ------------------------

	/**
	 * Constructor takes a HyperCube and an array of integers as coordinates and sets the mark to EMPTY.
	 * @param cube the HyperCube this point belongs to
	 * @param coordinates the coordinates of the point
	 */
	//@ requires coordinates != null;
	//@ requires coordinates.length > 1;
	public Point(Coordinate[] coordinates) {
		this.coordinates = Coordinate.copy(coordinates);
		this.mark = Mark.EMPTY;
	}
	
	//@ requires dimension >= 0;
	public Point(int dimension) {
		Coordinate[] coordinates = new Coordinate[dimension];
		for (int i = 1; i <= dimension; i++) {
			coordinates[i - 1] = new Coordinate(i, -1);
		}
		this.coordinates = coordinates;
		this.mark = Mark.EMPTY;
	}
	
	public Point(Point point) {
		this.coordinates = Point.copy(point).getCoordinates().clone();
	}
	
	/**
	 * The String of this class returns its coordinates in brackets.
	 */
	//@ ensures \result != null;
	public String toString() {
		String s = "";
		s += "(";
		for (int i = 0; i < this.coordinates.length - 1; i++) {
			s += this.coordinates[i] + ", ";
		}
		s += this.coordinates[this.coordinates.length - 1];
		s += ")";
		return s;
	}
	
	// ------------------------ Queries ------------------------
	
	public Point copy() {
		Coordinate[] metaCoordinates = this.coordinates.clone();
		for (int i = 0; i < metaCoordinates.length; i++) {
			metaCoordinates[i] = coordinates[i].copy();
		}
		return new Point(metaCoordinates);
	}
	
	public Coordinate getCoordinate(int dimension) {
		for (int i = 0; i < coordinates.length; i++) {
			if (coordinates[i].getDimension() == dimension) {
				return coordinates[i];
			}
		}
		return null;
	}
	
	public Coordinate[] getCoordinates() {
		return this.coordinates;
	}
	
	/**
	 * Gets the Mark of the point.
	 * @return the mark of this point
	 */
	//@ ensures \result != null; && \result != Mark.EMPTY;;
	public Mark getMark() {
		return this.mark;
	}
	
	// ------------------------ Comparisons ------------------------
	
	////////////////////////////////////////////////////////////neeeeds rework
	public boolean equals(Point point) {
		if (point != null && coordinates.length == point.getCoordinates().length) {
			Coordinate[] myCoords = this.getCoordinates();
			Coordinate[] otherCoords = point.getCoordinates();
			for (int i = 0; i < coordinates.length; i++) {
				if (!myCoords[i].equals(otherCoords[i])) {
					return false;
				}
			}
			return true;
		}
		return false;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the point to belong to a player.
	 * @param ownedBy the player who marks this point
	 */
	//@ requires ownedBy != null && ownedBy != Mark.EMPTY;
	public void setMark(Mark ownedBy) {
		this.mark = ownedBy;
	}
	
	// ------------------------ Static Commands ------------------------
	
	public static Point copy(Point point) {
		return new Point(point.getCoordinates());
	}
	
	public static Point[] copy(Point[] points) {
		Point[] p = new Point[points.length];
		for (int i = 0; i < points.length; i ++) {
			p[i] = (points[i]).copy();
		}
		return p;
	}
}