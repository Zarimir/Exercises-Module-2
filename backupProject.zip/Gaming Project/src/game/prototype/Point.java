package game.prototype;

/**
 * @author Zarimir
 * @version 3.0
 */
public class Point {

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension the dimensions of the points
	 * @param coordinates the coordinates of the point
	 * @param mark the mark of the point
	 */
	//@ private invariant dimension > 1;
	//@ private invariant coordinates.length > 1;
	//@ private invariant mark != null;
	private Coordinate[] coordinates;
	private Mark mark = Mark.EMPTY;
	
	// ------------------------ Constructor ------------------------

	/**
	 * Constructor takes an array of integers as coordinates and creates a point with those coordinates.
	 * @param coordinates the coordinates of the point
	 */
	//@ requires coordinates != null;
	//@ requires coordinates.length > 0;
	public Point(Coordinate[] coordinates) {
		this.coordinates = Coordinate.copy(coordinates);
	}
	
	/**
	 * Constructs default point which has values -1 for each coordinate.
	 * @param dimension the dimensions of the point
	 */
	//@ requires dimension >= 0;
	public Point(int dimension) {
		Coordinate[] coordinates = new Coordinate[dimension];
		for (int i = 1; i <= dimension; i++) {
			coordinates[i - 1] = new Coordinate(i, -1);
		}
		this.coordinates = coordinates;
	}
	
	/**
	 * The String of this class returns its coordinates in brackets.
	 */
	public String toString() {
		String s = "";
		s += "(";
		for (int i = 0; i < this.coordinates.length - 1; i++) {
			s += this.coordinates[i] + ", ";
		}
		s += this.coordinates[this.coordinates.length - 1];
		s += ")";
		return s;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Returns a copy of this point. It also copies this point's mark.
	 * @return new Point()
	 */
	public Point copy() {
		Coordinate[] metaCoordinates = this.coordinates.clone();
		for (int i = 0; i < metaCoordinates.length; i++) {
			metaCoordinates[i] = coordinates[i].copy();
		}
		Point point = new Point(metaCoordinates);
		point.setMark(this.mark);
		return point;
	}
	
	/**
	 * Gets the coordinate of this point which has the same dimension as the integer argument.
	 * @param dimension argument
	 * @return coordinate with this dimension or null if there aren't any
	 */
	public Coordinate getCoordinate(int dimension) {
		for (int i = 0; i < coordinates.length; i++) {
			if (coordinates[i].getDimension() == dimension) {
				return coordinates[i];
			}
		}
		return null;
	}
	
	/**
	 * Gets the coordinates of this point.
	 * @return this.coordinates
	 */
	public Coordinate[] getCoordinates() {
		return this.coordinates;
	}
	
	/**
	 * Gets the Mark of the point.
	 * @return the mark of this point
	 */
	public Mark getMark() {
		return this.mark;
	}
	
	// ------------------------ Comparisons ------------------------
	
	/**
	 * Two points are equal if they have the same coordinate dimensions and values.
	 * @param point argument
	 * @return true if equal, false otherwise
	 */
	public boolean equals(Point point) {
		if (point != null && coordinates.length == point.getCoordinates().length) {
			Coordinate[] myCoords = this.getCoordinates();
			Coordinate[] otherCoords = point.getCoordinates();
			for (int i = 0; i < coordinates.length; i++) {
				if (!myCoords[i].equals(otherCoords[i])) {
					return false;
				}
			}
			return true;
		}
		return false;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the point to belong to a player.
	 * @param ownedBy the player who marks this point
	 */
	public void setMark(Mark ownedBy) {
		this.mark = ownedBy;
	}
	
	// ------------------------ Static Commands ------------------------
	
	/**
	 * Makes a copy of a point.
	 * @param point argument
	 * @return new Point with the same values
	 */
	public static Point copy(Point point) {
		return new Point(point.getCoordinates());
	}
	
	/**
	 * Makes a copy of a Point[] list, by copying each of the points.
	 * @param points argument
	 * @return new Point[] with copies of points in the argument
	 */
	public static Point[] copy(Point[] points) {
		Point[] p = new Point[points.length];
		for (int i = 0; i < points.length; i ++) {
			p[i] = (points[i]).copy();
		}
		return p;
	}
}