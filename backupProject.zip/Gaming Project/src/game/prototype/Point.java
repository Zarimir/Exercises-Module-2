package game.prototype;

/**
 * @author Zarimir
 * @version 3.0
 */
public class Point {

	// ------------------------ Main ------------------------

	public static void main(String[] args) {
		
	}

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension the dimensions of the points
	 * @param coordinates the coordinates of the point
	 * @param mark the mark of the point
	 */
	//@ private invariant dimension > 1;
	//@ private invariant coordinates.length > 1;
	//@ private invariant mark != null;
	//private HyperCube cube;
	private Coordinate[] coordinates;
	private Mark mark;
	private int index;
	
	// ------------------------ Constructor ------------------------

	/**
	 * Constructor takes a HyperCube and an array of integers as coordinates and sets the mark to EMPTY.
	 * @param cube the HyperCube this point belongs to
	 * @param coordinates the coordinates of the point
	 */
	//@ requires coordinates != null;
	//@ requires coordinates.length > 1;
	public Point(/*HyperCube cube, */Coordinate[] coordinates) {
		//this.cube = cube;
		this.coordinates = Coordinate.copy(coordinates);
		this.mark = Mark.EMPTY;
		this.index = coordinates.length - 1;
	}
	
	//@ requires dimension >= 0;
	public Point(int dimension) {
		Coordinate[] coordinates = new Coordinate[dimension];
		for (int i = 1; i <= dimension; i++) {
			coordinates[i - 1] = new Coordinate(i, -1);
		}
		this.coordinates = coordinates;
		this.mark = Mark.EMPTY;
		this.index = coordinates.length - 1;
	}
	
	public Point(Point point) {
		this.coordinates = Point.copy(point).getCoordinates().clone();
		this.index = coordinates.length - 1;
	}
	
	/**
	 * The String of this class returns its coordinates in brackets.
	 */
	//@ ensures \result != null;
	public String toString() {
		String s = "";
		s += "(";
		for (int i = 0; i < this.coordinates.length - 1; i++) {
			s += this.coordinates[i] + ", ";
		}
		s += this.coordinates[this.coordinates.length - 1];
		s += ")";
		return s;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Gets the Mark of the point.
	 * @return the mark of this point
	 */
	//@ ensures \result != null; && \result != Mark.EMPTY;;
	public Mark getMark() {
		return this.mark;
	}
	
	public Coordinate[] getCoordinates() {
		return this.coordinates;
	}
	
	public boolean equals(Point point) {
		if (point == null) {
			throw new ArithmeticException("Is null!");			
		} else if (coordinates.length == point.getCoordinates().length) {
			Point myPoint = Point.copy(this);
			Point otherPoint = Point.copy(point);
			Coordinate[] myCoords = myPoint.getCoordinates();
			Coordinate[] otherCoords = otherPoint.getCoordinates();
			for (int i = 0; i < coordinates.length; i++) {
				if (!myCoords[i].equals(otherCoords[i])) {
					return false;
				}
			}
			return true;
		}
		throw new ArithmeticException("Uncompatible dimensions!");
		
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the point to belong to a player.
	 * @param ownedBy the player who marks this point
	 */
	//@ requires ownedBy != null && ownedBy != Mark.EMPTY;
	public void setMark(Mark ownedBy) {
		this.mark = ownedBy;
	}
	
	public static Point copy(Point point) {
		return new Point(point.getCoordinates());
	}
	
	public static Point[] copy(Point[] points) {
		Point[] p = new Point[points.length];
		for (int i = 0; i < points.length; i ++) {
			p[i] = Point.copy(points[i]);
		}
		return p;
	}
	
	// ------------------------ Static Commands ------------------------
	
	public void next() {
		index = Math.modulo(index - 1, coordinates.length);
	}
	
	public void previous() {
		index = Math.modulo(index + 1, coordinates.length);
	}
	
	public void setCoordinate(int i) {
		coordinates[index].setValue(i);
	}
	
	public Coordinate getCurrent() {
		return this.coordinates[index];
	}
	
	public int getIndex() {
		return this.index;
	}
}



/*
public void next() {
	if (coordinates.length > 1) {
		Coordinate temp = coordinates[0];
		for (int i = 0; i < coordinates.length - 1; i++) {
			coordinates[i] = coordinates[i + 1];	
		}
		coordinates[coordinates.length - 1] = temp;
	}
}

public void previous() {
	if (coordinates.length > 1) {
		Coordinate temp = coordinates[coordinates.length - 1];
		for (int i = 1; i < coordinates.length; i++) {
			coordinates[coordinates.length - i] = coordinates[coordinates.length - i - 1];	
		}
		coordinates[0] = temp;
	}
}
*/