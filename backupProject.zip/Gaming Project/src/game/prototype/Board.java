package game.prototype;

/**
 * @author Zarimir Mitev and Vincent Luiten.
 * @version 3.0
 */
public class Board {
	
	// ------------------------ ------------------------
	    
	/*
	public static void main(String[] args) {
	}
    
    
    public int index(int row, int col) {
        return col + row * this.length;
    }

    public boolean isFull() {
    	// TODO: implement, see exercise P-4.18
    	for (int i = 0; i < this.length *this.length; i++) {
    		if (this.isEmptyField(i)) {
    			return false;
    		}
    	}
        return true;
    }

    public boolean gameOver() {
    	// TODO: implement, see exercise P-4.18
        return (this.isFull() || this.hasWinner());
    }
    */
}