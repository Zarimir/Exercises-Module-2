package game.prototype;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Zarimir Mitev and Vincent Luiten.
 * @version 3.0
 */
public class Board {
	
    private int length;
    private int dimension;
    
    private List<Line> lines;
    private List<Point> points;
    
    // -- Constructors -----------------------------------------------
    
    public Board(int dimension, int length) {
    	HyperCube cube = new HyperCube (dimension, length);
    	cube.initialize();
    	this.points = cube.getPoints();
    	this.lines = cube.getLines();    	
    	this.dimension = dimension;
    	this.length = length;
    }
    
    public Board(List<Point> points, List<Line> lines) {
    	this.points = HyperCube.copyPoints(points);
    	this.lines = HyperCube.copyLines(lines);
    	this.dimension = points.get(0).getCoordinates().length;
    	this.length = lines.get(0).getPoints().length;
    }

    public Board copy() {
        return new Board(this.points, this.lines);
    }
    
    public int index(int row, int col) {
        return col + row * this.length;
    }

    public boolean isField(int index) {
        return 0 <= index && index < this.length * this.length;
    }
    
    public boolean isField(int row, int col) {
        return 0 <= row && row < this.length && 0 <= col && col < this.length;
    }
    
    public Mark getField(int i) {
    	if (this.isField(i)) {
    		return this.fields[i];
    	}
    	
        return null;
    }

    public Mark getField(int row, int col) {
    	// TODO: implement, see exercise P-4.18
    	if (this.isField(row, col)) {
    		return this.getField(this.index(row, col));
    	}
    	return null;
    }

    public boolean isEmptyField(int i) {
        return this.isField(i) && this.getField(i) == Mark.EMPTY;
    }

    public boolean isEmptyField(int row, int col) {
        return this.isEmptyField(this.index(row, col));
    }

    public boolean isFull() {
    	// TODO: implement, see exercise P-4.18
    	for (int i = 0; i < this.length *this.length; i++) {
    		if (this.isEmptyField(i)) {
    			return false;
    		}
    	}
        return true;
    }

    public boolean gameOver() {
    	// TODO: implement, see exercise P-4.18
        return (this.isFull() || this.hasWinner());
    }

    public boolean hasWinner() {
        return this.isWinner(Mark.OO) || this.isWinner(Mark.XX);
    }

    public void reset() {
    	for (int i = 0; i < this.length * this.length; i++) {
    		this.fields[i] = Mark.EMPTY;
    	}
    }

    public void setField(int i, Mark m) {
    	if (0 <= i && i < this.length * this.length) {
    		this.fields[i] = m;
    	}
    }

    public void setField(int row, int col, Mark m) {
    	this.setField(this.index(row, col), m);
    }
}