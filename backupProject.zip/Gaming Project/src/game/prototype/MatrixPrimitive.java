package game.prototype;

import java.util.ArrayList;
import java.util.List;

public class MatrixPrimitive {
	private int[] ints;
	private boolean variationPossible;
	private int index = -1;
	
	public MatrixPrimitive (int[] ints) {
		this.ints = ints.clone();
	}
	
	public boolean reset() {
		List<Integer> indexes = new ArrayList<Integer>();
		int currentIndex;
		int freeSpaces;
		for (int i = 0; i < ints.length; i++) {
			currentIndex = ints.length - i - 1;
			freeSpaces = indexes.size() + 1;
			if (ints[currentIndex] != -1) {
				if (currentIndex + freeSpaces < ints.length) {
					indexes.add(0, ints[currentIndex]);
					ints[currentIndex] = -1;
					currentIndex++;
					for (int j = currentIndex; j < ints.length; j++) {
						if (indexes.size() > 0) {
							ints[currentIndex] = indexes.get(0);
							indexes.remove(0);
						} else {
							ints[currentIndex] = -1;
						}
						currentIndex++;
					}
					System.out.println(currentIndex);
					return true;
				} else {
					indexes.add(0, ints[currentIndex]);
				}
			}
		}
		return false;
	}
	
	public boolean iterate() {
		if (index == -1) {
			for (int i = 0; i < ints.length - 1; i++) {
				if (ints[i + 1] == -1) {
					index = i;
					break;
				}
			}
		}
		if (index + 1 < ints.length) {
			//assert ints[index + 1] == -1;
			//System.out.println(index + ":" + ints.length);
			ints[index + 1] = ints[index];
			ints[index] = -1;
			index++;
			return true;
		} else {
			return reset();
		}
	}
	
	public List<Integer> getFreeIndexes() {
		List<Integer> freeIndexes = new ArrayList<Integer>();
		for (int i = 0; i < ints.length; i++) {
			if (ints[i] == -1) {
				freeIndexes.add(i);
			}
		}
		return freeIndexes;
	}
	
	public String toString() {
		String s = "(";
		for (int i = 0; i < ints.length; i++) {
			s += ints[i] + ", ";
		}
		s = s.substring(0, s.length() - 1);
		s += ")";
		return s;
	}
}
