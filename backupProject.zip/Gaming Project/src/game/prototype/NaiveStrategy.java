package game.prototype;

import java.util.ArrayList;
import java.util.List;

/**
 * Naive Strategy picks a random free point and marks it.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class NaiveStrategy implements Strategy {

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param NAME of this strategy is "Naive"
	 */
	private final String NAME = "Naive";
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Gets the name of this strategy.
	 * @return "Naive"
	 */
	public String getName() {
		return this.NAME;
	}
	
	/**
	 * Determines the next legal move.
	 * @param board of the Game
	 * @param mark of the ComputerPlayer
	 */
	public Point determineMove(HyperCube board, Mark m) {
		List<Point> emptyFields = new ArrayList<Point>();
		Point holder;
		for (int i = 0; i < board.getLength() * board.getLength(); i++) {
			holder = board.getPoint(i);
			if (holder != null) {
				emptyFields.add(holder);
			}
		}
		int random = (int) (Math.random() * (emptyFields.size()));
		
		return emptyFields.get(random);
	}
}