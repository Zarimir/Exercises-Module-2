package game.prototype;

public class Coordinate {
	
	// ------------------------ Instance Variables ------------------------
	
	private int dimension;
	private int value;
	
	// ------------------------ Constructor ------------------------
	
	//@ requires dimension > 0;
	//@ requires value > 0;
	public Coordinate(int dimension, int value) {
		this.dimension = dimension;
		this.value = value;
	}
	
	public String toString() {
		return "" + this.value;
		//return "[" + this.dimension + ":" + this.value + "]";
		//return "[" + this.dimension + ":" + this.value +"]";
	}
	
	// ------------------------ Queries ------------------------
	
	public Coordinate copy() {
		Coordinate metaCoordinate = new Coordinate(dimension, value);
		return metaCoordinate;
	}
	
	public int getDimension() {
		return this.dimension;
	}
	
	public int getValue() {
		return this.value;
	}	
	
	// ------------------------ Comparisons ------------------------
	
	public boolean equals(Coordinate coordinate) {
		return this.sameDimension(coordinate) && this.sameValue(coordinate);
	}
	
	public boolean sameDimension(Coordinate coordinate) {
		if (this.dimension == coordinate.getDimension()) {
			return true;
		}
		return false;
	}
	
	public boolean sameValue(Coordinate coordinate) {
		if (this.value == coordinate.getValue()) {
			return true;
		}
		return false;
	}
	
	
	// ------------------------ Commands ------------------------
	
	public void setValue(int value) {
		this.value = value;
	}
	
	// ------------------------ Static Commands ------------------------
	
	public static Coordinate copy(Coordinate coordinate) {
		return new Coordinate(coordinate.getDimension(), coordinate.getValue());
	}
	
	public static Coordinate[] copy(Coordinate[] coordinates) {
		Coordinate[] coords = new Coordinate[coordinates.length];
		for (int i = 0; i < coords.length; i++) {
			coords[i] = Coordinate.copy(coordinates[i]);
		}
		return coords;
	}
}