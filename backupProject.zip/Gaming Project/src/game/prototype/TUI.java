/**
 * 
 */
package game.prototype;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public abstract class TUI implements View {
	
	// ------------------------  Instance Variables  ------------------------
	
	private static final Scanner INPUT = new Scanner(System.in);
	
	private Map<String, Integer> commands = new HashMap<String, Integer>();
	
	// ------------------------ Constructor ------------------------
	
	public TUI() {
		
	}
	
	// ------------------------ Queries ------------------------
	
	/*
	public HyperCube getHyperCube() {
		return this.game.getHyperCube();
	}
	*/
	
	// ------------------------ Commands ------------------------
	
	public void putCommands(String[] commandList) {
		for (int i = 0; i < commandList.length; i++) {
			commands.put(commandList[i], 0);
		}
	}
	
	public void putCommands(String command, int arguments) {
		commands.put(command, arguments);
	}
	
	public void getCommand() {
		String choice;
		System.out.println("What's your input? > ");
		choice = INPUT.nextLine();
		findCommand(choice);
	}
	
	public void findCommand(String choice) {
		String[] arguments;
		boolean found = false;
		for (Map.Entry<String, Integer> entry : commands.entrySet()) {
			if (containsCommand(choice, entry.getKey())) {
				arguments = choice.substring(choice.indexOf(" ")).split(" ");
				found = true;
				if (arguments.length >= entry.getValue()) {
					executeCommand(entry.getKey(), arguments);
				} else if (found) {
					break;
				}
			}
		}
		if (!found) {
			showError("Command not found! Please try again...");
			getCommand();
		} else if (found) {
			showError("Invalid number of arguments! Please try again...");
			getCommand();
		}
	}
	
	public boolean containsCommand(String choice, String command) {
		String cut = choice.substring(0, command.length());
		return cut.equals(command);
	}
	
	public abstract void executeCommand(String command, String[] arguments);
	
	public void showError(String error) {
		System.out.println(error);
	}
	
	public void inform(String message) {
		System.out.println(message);
	}
	
	public abstract void exit(String[] args);
	public abstract void showCommands(String[] args);
}
