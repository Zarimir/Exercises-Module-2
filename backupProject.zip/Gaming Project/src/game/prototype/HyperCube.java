package game.prototype;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class HyperCube {
	
	// ------------------------ Instance Variables ------------------------
	
	private int dimension;
	private int length;
	private List<Point> points;
	private List<Line> lines;
	
	// ------------------------ Constructors ------------------------
	
	//@ requires dimension > 1;
	//@ requires length > 1;
	public HyperCube(int dimension, int length) {
		assert dimension > 1;
		assert length > 1;
		
		this.dimension = dimension;
		this.length = length;
	}
	
	// ------------------------ Queries ------------------------
	
	public int getDimension() {
		return this.dimension;
	}
	
	public int getLength() {
		return this.length;
	}
	
	public List<Point> getPoints() {
		return this.points;
	}
	
	public List<Line> getLines() {
		return this.lines;
	}
	
	public Point getPoint(Point target) {
		for (int i = 0; i < this.points.size(); i++) {
			if (this.points.get(i).equals(target)) {
				return this.points.get(i);
			}
		}
		return null;
	}
	
	// ------------------------ Comparisons ------------------------
	
	// ------------------------ Commands ------------------------
	
	public void initialize() {
		Matrix matrix = new Matrix(this);

	}
	
	// Needs to be finished
		// Update isAffected and ownedBy
	public void updateLines(Point move) {
		Line line;
		Mark m;
		for (Iterator<Line> it = this.lines.iterator(); it.hasNext();) {
			line = it.next();
			
			///////////////////////////////////////////////////////////////////////////////////line.isAffected(move)
			if (true) {
				m = line.ownedBy();
				if (m == null) {
					it.remove();
				} else if (!m.equals(Mark.EMPTY)) {
					
				}
			}
		}
	}
	
	// ------------------------ Static Commands ------------------------
	
	public int edges() {
		return this.dimension * Math.pow(this.length, this.dimension - 1);
	}
	
	public int outerDiagonals() {
		return Math.pow(2, dimension - 1) * (Math.pow(2, dimension) - dimension - 1); 
	}
	
	public static List<Point> copyPoints(List<Point> points) {
		List<Point> result = new ArrayList<Point>();
		for (int i = 0; i < points.size(); i++) {
			result.add(points.get(i).copy());
		}
		return result;
	}
	
	public static List<Line> copyLines(List<Line> lines) {
		List<Line> result = new ArrayList<Line>();
		for (int i = 0; i < lines.size(); i++) {
			result.add(lines.get(i).copy());
		}
		return result;
	}
}