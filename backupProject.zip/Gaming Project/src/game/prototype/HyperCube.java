package game.prototype;

import java.util.ArrayList;
import java.util.List;

public class HyperCube {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension of this cube
	 * @param length of this cube
	 * @param points of this cube
	 * @param lines of this cube
	 */
	//@ private invariant dimension > 1;
	//@ private invariant length > 1;
	private int dimension;
	private int length;
	private List<Point> points;
	private List<Line> lines;
	
	// ------------------------ Constructors ------------------------
	
	/**
	 * Constructs a HyperCube of <code>dimension</code> and <code>length</code> parameters.
	 * @param dimension of the HyperCube
	 * @param length of the HyperCube
	 */
	//@ requires dimension > 1;
	//@ requires length > 1;
	public HyperCube(int dimension, int length) {
		this.dimension = dimension;
		this.length = length;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Gets the <code>dimension</code>.
	 * @return this.dimension
	 */
	public int getDimension() {
		return this.dimension;
	}
	
	/**
	 * Gets the <code>length</code>.
	 * @return this.length
	 */
	public int getLength() {
		return this.length;
	}
	
	/**
	 * Gets the <code>points</code>.
	 * @return this.points
	 */
	public List<Point> getPoints() {
		return this.points;
	}
	
	/**
	 * Gets the <code>lines</code>.
	 * @return this.lines
	 */
	public List<Line> getLines() {
		return this.lines;
	}
	
	/**
	 * Gets the <code>Point</code> equal to the <code>target</code>.
	 * @param target Point
	 * @return point which equals to target or null if there aren't any
	 */
	public Point getPoint(Point target) {
		for (int i = 0; i < this.points.size(); i++) {
			if (this.points.get(i).equals(target)) {
				return this.points.get(i);
			}
		}
		return null;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Initializes the list of points and lines of this HyperCube.
	 */
	public void initialize() {
		Matrix matrix = new Matrix(this);
		matrix.extract();
		this.points = matrix.getPoints();
		this.lines = matrix.getLines();
	}
	
	// ------------------------ Static Commands ------------------------
	
	/**
	 * Makes a copy of an ArrayList of points, by copying each point separately.
	 * @param points argument
	 * @return new ArrayList<Point> containing all points of <code>points</code>
	 */
	public static List<Point> copyPoints(List<Point> points) {
		List<Point> result = new ArrayList<Point>();
		for (int i = 0; i < points.size(); i++) {
			result.add(points.get(i).copy());
		}
		return result;
	}
	
	/**
	 * Makes a copy of an ArrayList of lines, by copying each line separately.
	 * @param lines argument
	 * @return new ArrayList<Line> containing all lines of <code>lines</code>
	 */
	public static List<Line> copyLines(List<Line> lines) {
		List<Line> result = new ArrayList<Line>();
		for (int i = 0; i < lines.size(); i++) {
			result.add(lines.get(i).copy());
		}
		return result;
	}
}