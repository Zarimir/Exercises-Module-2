package game.prototype;


///////////////////////////////////////////////////////////////////////////////////////
//////////OBSERVER, CUTLINES, MVC
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The board of the classic tic-tac-toe is represented by a 2-dimensional square.
 * It is logical to represent a multi-dimensional tic-tac-toe with
 * a multi-dimensional square also known as a HyperCube.
 * The HyperCube has all the self-managing methods required by the Game class.
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public class HyperCube {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension of this cube
	 * @param length of this cube
	 * @param points of this cube
	 * @param lines of this cube
	 * @param metaPoints the current state of the points of this cube
	 * @param metaLines the current state of the lines of this cube
	 * @param winner the current state of this cube
	 */
	//@ private invariant dimension > 1;
	//@ private invariant length > 1;
	private int dimension;
	private int length;
	private List<Point> points;
	private List<Line> lines;
	
	private List<Point> metaPoints;
	private List<Line> metaLines;
	private Mark winner = null;
	
	// ------------------------ Constructors ------------------------
	
	/**
	 * Constructs a HyperCube of <code>dimension</code> and <code>length</code> parameters.
	 * @param dimension of the HyperCube
	 * @param length of the HyperCube
	 */
	//@ requires dimension > 1;
	//@ requires length > 1;
	public HyperCube(int dimension, int length) {
		this.dimension = dimension;
		this.length = length;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
     * Makes a new <code>HyperCube</code> with the dimension and length of this one.
     * Then sets the status of the metaPoints and metaLines to be the same as this one.
     * @return new HyperCube()
     */
    public HyperCube copy() {
    	HyperCube cube = new HyperCube(dimension, length);
    	cube.setStatus(this.metaPoints, this.metaLines);
        return cube;
    }
	
	/**
	 * Gets the <code>dimension</code>.
	 * @return this.dimension
	 */
	public int getDimension() {
		return this.dimension;
	}
	
	/**
	 * Gets the <code>length</code>.
	 * @return this.length
	 */
	public int getLength() {
		return this.length;
	}
	
	/**
	 * Gets the <code>points</code>.
	 * @return this.points
	 */
	public List<Point> getPoints() {
		return this.points;
	}
	
	/**
	 * Gets the <code>lines</code>.
	 * @return this.lines
	 */
	public List<Line> getLines() {
		return this.lines;
	}
	
	/**
	 * Gets the point at index from points.
	 * Returns null if index is out of range.
	 * Returns null if all points are used up at this column.
	 * Works correctly in 2 and 3 dimensions only.
	 * @param index
	 * @return Point() or null
	 */
	public Point getPoint(int index) {
		int i = index;
		while (i < metaPoints.size() && 0 <= i && i < length * length) {
			if (metaPoints.get(i).getMark() != Mark.EMPTY) {
				return metaPoints.get(i);
			}
			i += length;
		}
		return null;
	}
	
	/**
	 * Gets the point from points which is equal to the point argument.
	 * @param choice argument
	 * @return Point() which is equal to the argument and is empty or null otherwise
	 */
	public Point getPoint(Point choice) {
		for (int i = 0; i < metaPoints.size(); i++) {
			if (choice.equals(metaPoints.get(i))) {
				Point target = metaPoints.get(i);
				if (target.getMark() == Mark.EMPTY) {
					return target;
				} else {
					return null;
				}
			}
		}
		return null;
	}
	
	/**
	 * Gets the winner of this HyperCube.
	 * Returns null if the game is not over.
	 * Returns Mark.EMPTY if there is a draw.
	 * Returns the mark of the winner if a player wins.
	 * @return null if the game is not over, or Mark if it's over
	 */
	public Mark getWinner() {
		return this.winner;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Initializes the list of points and lines of this HyperCube.
	 * After it has been initialized, the same method can be used to reset it.
	 * Sets the winner to null;
	 */
	public void initialize() {
		if (this.points == null || this.lines == null) {
			Matrix matrix = new Matrix(this);
			matrix.extract();
			this.points = matrix.getPoints();
			this.lines = matrix.getLines();
		}
		setStatus(this.points, this.lines);
		this.winner = null;
	}
	
	/**
	 * Sets the current status of the HyperCube, which is
	 * the metaPoints with all their marks and the metaLines with all their lines and marks
	 * @param points
	 * @param lines
	 */
	public void setStatus(List<Point> points, List<Line> lines) {
		this.metaPoints = HyperCube.copyPoints(points);
		this.metaLines = HyperCube.copyLines(lines);
	}
	
	/**
	 * Marks a point from the points list and updates all the lines.
	 * @param choice
	 * @param player
	 */
	public void mark(Point choice, Mark player) {
		choice.setMark(player);
		updateLines(choice);
	}
	
	/**
     * Updates the lines.
     * If the current line contains the same point, sets the mark to be of the player who marked it.
     * Sets the winner if the game is over. Removes irrelevant lines.
     * The game is over if there is a winner or there aren't any relevant lines left.
     * @param move the current move
     */
    public void updateLines(Point choice) {
		Line line;
		Mark mark;
		for (Iterator<Line> it = this.metaLines.iterator(); it.hasNext();) {
			line = it.next();
			line.setMark(choice);
			mark = line.ownedBy();
			if (mark == null) {
				it.remove();
			} else if (mark != Mark.EMPTY) {
				winner = mark;
				break;
			}
		}
		if (metaLines.size() == 0) {
			winner = Mark.EMPTY;
		}
	}
    
	// ------------------------ Static Commands ------------------------
    
	/**
	 * Makes a copy of an ArrayList of points, by copying each point separately.
	 * @param points argument
	 * @return new ArrayList<Point> containing all points of <code>points</code>
	 */
	public static List<Point> copyPoints(List<Point> points) {
		List<Point> result = new ArrayList<Point>();
		for (int i = 0; i < points.size(); i++) {
			result.add(points.get(i).copy());
		}
		return result;
	}
	
	/**
	 * Makes a copy of an ArrayList of lines, by copying each line separately.
	 * @param lines argument
	 * @return new ArrayList<Line> containing all lines of <code>lines</code>
	 */
	public static List<Line> copyLines(List<Line> lines) {
		List<Line> result = new ArrayList<Line>();
		for (int i = 0; i < lines.size(); i++) {
			result.add(lines.get(i).copy());
		}
		return result;
	}
}