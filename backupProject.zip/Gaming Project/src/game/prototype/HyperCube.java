package game.prototype;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class HyperCube {
	
	public static void main(String[] args) {
		HyperCube obj = new HyperCube(2, 5);
		// System.out.println(obj.outerDiagonals());
		obj.initialize();
		//System.out.println(obj.getPointsString());
		//Line.prnt(obj.getLines());
		
		
	}
	
	private int dimension;
	private int length;
	private List<Point> points;
	private List<Line> lines;
	
	//@ requires dimension > 1;
	//@ requires length > 1;
	public HyperCube(int dimension, int length) {
		assert dimension > 1;
		assert length > 1;
		
		this.dimension = dimension;
		this.length = length;
	}
	
	public void initialize() {
		this.extractPoints();
		this.collectLines();
	}
	
	public List<Point> getPoints() {
		return this.points;
	}
	
	public String getPointsString() {
		String s = "";
		for (int i = 0; i < this.points.size(); i++) {
			s += this.points.get(i);
		}
		return s;
	}
	
	public Point getPoint(Point target) {
		for (int i = 0; i < this.points.size(); i++) {
			if (this.points.get(i).equals(target)) {
				return this.points.get(i);
			}
		}
		System.out.println("Return null");
		return null;
	}
	
	// Needs to be finished
	// Update isAffected and ownedBy
	public void updateLines(Point move) {
		Line line;
		Mark m;
		for (Iterator<Line> it = this.lines.iterator(); it.hasNext();) {
			line = it.next();
			
			///////////////////////////////////////////////////////////////////////////////////line.isAffected(move)
			if (true) {
				m = line.ownedBy();
				if (m == null) {
					it.remove();
				} else if (!m.equals(Mark.EMPTY)) {
					
				}
			}
		}
	}
	
	public List<Line> getLines() {
		return this.lines;
	}
	
	public int getDimension() {
		return this.dimension;
	}
	
	public int getLength() {
		return this.length;
	}
	
	public int edges() {
		return this.dimension * Math.pow(this.length, this.dimension - 1);
	}
	
	public int outerDiagonals() {
		return Math.pow(2, dimension - 1) * (Math.pow(2, dimension) - dimension - 1); 
	}
	
	//public int outerDiagonals(int face) {
	//	return Math.pow(2, dimension - 1) * (Math.pow(2, dimension) - dimension - 1); 
	//}
	
	
	
	
	
	
	
	public void collectLines() throws ArithmeticException {
    		lines = new ArrayList<Line>();
    		extractStraightLines();
	}
	
	public void extractStraightLines() {
		Point metaPoint = new Point(dimension);
		Line metaLine = new Line(dimension, length);
		int level;
		for (int i = 0; i < dimension; i++) {
			level = dimension;
			extractStraightLines(metaPoint, metaLine, level);

			metaPoint.next();
			metaPoint.next();
		}
		boolean check = lines.size() == dimension * Math.pow(length, dimension - 1);
		if (!check) {
			throw new ArithmeticException("Wrong number of non-diagonal lines!");
		}
	}
	
	public void extractStraightLines (Point metaPoint, Line metaLine, int level) {
		if (level == 1) {
			metaLine.reset();
		}
		for (int i = 0; i < length; i++) {
			metaPoint.setCoordinate(i);
			if (level > 1) {
				metaPoint.next();
				extractStraightLines(metaPoint, metaLine, level - 1);
			} else {
				metaLine.setPoint(metaPoint);
				metaLine.next();
			}
		}
		if (level == 1) {
			lines.add(new Line(metaLine));
		}
		metaPoint.previous();
	}
	
	/**
	 * Takes an N dimensional HyperCube and returns a list of all its points according to its length and dimension.
	 * The number of points collected is equal to the length to the power of the dimension.
	 * @param length the length of the HyperCube
	 * @param dimension the dimension of the HyperCube
	 * @throws ArithmeticException whenever the length is NOT longer than 1 or the dimension is NOT larger than 1
	 */
	//@ requires cube != null;
	//@ ensures \result.length == Math.pow(cube.getLength, cube.getDimension);
	//@ ensures \forall(int i; 0 <= i && i < \result.length; \result[i] != null);
	public void extractPoints() {
		points = new ArrayList<Point>(); 
		Point metaPoint = new Point(dimension);
		int level = dimension;
		extractPoints(metaPoint, level);
	}
	
	public void extractPoints(Point metaPoint, int level) {
		for (int i = 0; i < length; i++) {
			metaPoint.setCoordinate(i);
			if (level > 1) {
				metaPoint.next();
				extractPoints(metaPoint, level - 1);
			} else {
				points.add(new Point(metaPoint));
			}
		}
		metaPoint.previous();
	}
}