package game.prototype;

import java.util.ArrayList;
import java.util.List;

public class Matrix {
	
	// ------------------------ Instance Variables ------------------------
	
	private List<Point> points = new ArrayList<Point>();
	private List<Line> temp = new ArrayList<Line>();
	private List<Line> metaLines = new ArrayList<Line>();
	private List<Line> lines = new ArrayList<Line>();
	
	private int dimension;
	private int length;
	private int currentDimension;
	
	private int left;
	private int index = -1;
	private boolean[] matrix;
	private List<Integer> constants;
	
	// ------------------------ Constructors ------------------------
	
	public Matrix (int dimension, int length) {
		this.dimension = dimension;
		this.length = length;
		this.currentDimension = 2;
	}
	
	public Matrix (HyperCube cube) {
		this.dimension = cube.getDimension();
		this.length = cube.getLength();
	}
	
	// ------------------------ Queries ------------------------
	
	public List<Point> getPoints() {
		return this.points;
	}
	
	public List<Line> getLines() {
		return this.lines;
	}
	
	// ------------------------ Commands ------------------------
	
	public void extractPoints() {
		temp = new ArrayList<Line>();
		currentDimension = 0;
		constructLines();
		addSimilarLines();
	}
	
	public void extractNonDiagonals() {
		temp = new ArrayList<Line>();
		currentDimension = 1;
		constructLines();
		addSimilarLines();
	}
	
	public void extractDiagonals() {
		temp = new ArrayList<Line>();
		for (int i = 2; i < dimension; i++) {
			currentDimension = i;
			constructLines();
			addSimilarLines();
		}
		currentDimension = dimension;
		constructLines();
		for (int i = 0; i < temp.size(); i++) {
			lines.add(temp.get(i).copy());
			
		}
	}
	
	/**
	 * Constructs a line pattern based on <code>currentDimension</code>.
	 */
	public void constructLines() {
		if (currentDimension == 0) {
			constructOnePointlLine();
		} else if (currentDimension == 1) {
			constructNonDiagonals();
		} else if (currentDimension == 2) {
			construct2DimensionalDiagonals();
		} else {
			constructNDimensionalDiagonals(currentDimension);
		}
	}
	
	// Constructs a 1 dimensional line pattern (equivalent to a point)
	/**
	 * Constructs a <code>Line</code> pattern of only one <code>Point</code>,
	 * which is the equivalent to a <code>Point</code> pattern.
	 */
	public void constructOnePointlLine() {
		Line metaLine = new Line(dimension, 1);
		temp.add(metaLine.copy());
	}
	
	// Constructs a line pattern for non-diagonal lines.
	/**
	 * Constructs a 1 dimensional <code>Line</code> pattern, which is the pattern for a non-diagonal line.
	 */
	public void constructNonDiagonals() {
		Line metaLine = new Line(dimension, length);
		metaLine.setIteratableCoordinateAt(1, true);
		temp.add(metaLine.copy());
	}
	
	public void construct2DimensionalDiagonals() {
		Line metaLine = new Line(dimension, length);
		Line metaLine2 = metaLine.copy();
		for (int i = 0; i < length; i++) {
			metaLine.setIteratableCoordinateAt(1, true);
			metaLine.setIteratableCoordinateAt(2, true);
			
			metaLine2.setIteratableCoordinateAt(1, true);
			metaLine2.setIteratableCoordinateAt(2, false);
		}
		temp.add(metaLine.copy());
		temp.add(metaLine2.copy());
	}
	
	public void constructNDimensionalDiagonals(int dimension) {
		int end = temp.size();
		for (int i = 0; i < end; i++) {
			temp.add(temp.get(i).copy());
			temp.get(i).setIteratableCoordinateAt(dimension, true);
			temp.get(temp.size() - 1).setIteratableCoordinateAt(dimension, false);
		}
		
	}
	
	public void addSimilarLines() {
		initialize();
		use();
	}
	
	
	public void initialize() {
		updateMetaLines();
		constructMatrix();
		updateConstants();
		initializeIndex();
		left = Math.variations(dimension - constants.size(), dimension);
	}
	
	public void updateMetaLines() {
		metaLines = new ArrayList<Line>();
		for (int i = 0; i < temp.size(); i++) {
			metaLines.add(temp.get(i).copy());
		}
	}
	
	public void constructMatrix() {
		Coordinate[] metaCoordinates = metaLines.get(0).getPoints()[0].getCoordinates();
		matrix = new boolean[dimension];
		for (int i = 0; i < metaCoordinates.length; i++) {
			matrix[i] = metaCoordinates[i].getValue() > -1;
		}
	}
	
	public void updateConstants() {
		constants = new ArrayList<Integer>();
		for (int i = 0; i < matrix.length; i++) {
			if (matrix[i] == false) {
				constants.add(i + 1);
			}
		}
	}
	
	public void initializeIndex() {
		int currentIndex;
		for (int i = 0; i < matrix.length; i++) {
			currentIndex = matrix.length - i - 1;
			if (matrix[currentIndex]) {
				index = currentIndex;
				break;
			}
		}
	}
	
	public void use() {
		while (true) {
			left -= 1;
			if (constants.size() > 0) {
				iterateConstants(constants.size() - 1);
			}
			if (left == 0) {
				break;
			}
			iterate();
			massSwap();
		}
	}
	
	public void iterateConstants(int level) {
		for (int i = 0; i < length; i++) {
			setValues(constants.get(level), i);
			if (level > 0) {
				iterateConstants(level - 1);
			} else {
				update();
			}
		}
	}
	
	public void setValues(int dimension, int value) {
		for (int i = 0; i < metaLines.size(); i++) {
			Point[] points = metaLines.get(i).getPoints();
			for (int j = 0; j < points.length; j++) {
				points[j].getCoordinate(dimension).setValue(value);
			}
		}
	}
	public void update() {
		if (constants.size() == matrix.length) {
			updatePoints();
		} else {
			updateLines();
		}
	}
	
	public void updatePoints() {
		for (int i = 0; i < metaLines.size(); i++) {
			points.add(metaLines.get(i).getPoints()[0].copy());
		}
	}
	
	public void updateLines() {
		for (int i = 0; i < metaLines.size(); i++) {
			lines.add(metaLines.get(i).copy());
		}
	}
	
	public void massSwap() {
		updateMetaLines();
		int count = currentDimension;
		for (int i = dimension; i > 0; i -= 1) {
			if (matrix[i - 1]) {
				if (count != i) {
					swap(count, i);
				}
				count-= 1;
			}
		}
	}
	
	public void swap(int dimension, int dimensionTo) {
		int holder;
		for (int i = 0; i < metaLines.size(); i++) {
			Point[] points = metaLines.get(i).getPoints();
			for (int j = 0; j < points.length; j++) {
				Coordinate from = points[j].getCoordinate(dimension);
				Coordinate to = points[j].getCoordinate(dimensionTo);
				holder = from.getValue();
				from.setValue(to.getValue());
				to.setValue(holder);
			}
		}
	}
	
	public void iterate() {
		if (index + 1 < matrix.length) {
			matrix[index + 1] = true;
			matrix[index] = false;
			index++;
		} else {
			reorder();
		}
		updateConstants();
	}
	
	public void reorder() {
		int count = 0;
		int currentIndex;
		int freeSpaces;
		for (int i = 0; i < matrix.length; i++) {
			currentIndex = matrix.length - i - 1;
			freeSpaces = count + 1;
			if (matrix[currentIndex]) {
				count++;
				if (currentIndex + freeSpaces < matrix.length) {
					matrix[currentIndex] = false;
					currentIndex++;
					for (int j = currentIndex; j < matrix.length; j++) {
						if (count > 0) {
							matrix[currentIndex] = true;
							count -= 1;
						} else {
							matrix[currentIndex] = false;
						}
						currentIndex++;
					}
				}
			}
		}
		initializeIndex();
	}	
	
	public String toString() {
		String s = "LINES:\n";
		for (int i = 0; i < lines.size(); i++) {
			s += lines.get(i) + "\n";
		}
		return s;
	}
}
