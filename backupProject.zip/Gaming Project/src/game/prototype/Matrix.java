package game.prototype;

import java.util.ArrayList;
import java.util.List;

public class Matrix {
	private List<Line> diagonals = new ArrayList<Line>();
	private List<Line> metaDiagonals = new ArrayList<Line>();
	private List<Line> allDiagonals = new ArrayList<Line>();
	private int dimension;
	private int length;
	private int currentDimension = 2;
	
	private int left;
	private int index = -1;
	private boolean[] matrix;
	private List<Integer> constants;
	public Matrix (int dimension, int length) {
		this.dimension = dimension;
		this.length = length;
		this.currentDimension = 2;
	}
	
	public List<Line> getDiagonals() {
		return this.allDiagonals;
	}
	
	public void extractDiagonals() {
		construct2DimensionalDiagonals();
		for (int i = 2; i <= dimension; i++) {
			//System.out.println("hi");
			currentDimension = i;
			constructDiagonals(i);
			addSimilarDiagonals();
		}
		constructDiagonals(dimension);
		for (int i = 0; i < diagonals.size(); i++) {
			//allDiagonals.add(diagonals.get(i));
			
		}
	}
	
	public void constructDiagonals(int dimension) {
		if (dimension == 2) {
			construct2DimensionalDiagonals();
		} else {
			constructNDimensionalDiagonals(dimension);
		}
	}
	
	public void construct2DimensionalDiagonals() {
		Line metaLine = new Line(dimension, length);
		Line metaLine2 = metaLine.copy();
		for (int i = 0; i < length; i++) {
			metaLine.setIteratableCoordinateAt(1, true);
			metaLine.setIteratableCoordinateAt(2, true);
			
			metaLine2.setIteratableCoordinateAt(1, true);
			metaLine2.setIteratableCoordinateAt(2, false);
		}
		diagonals.add(metaLine.copy());
		diagonals.add(metaLine2.copy());
	}
	
	public void constructNDimensionalDiagonals(int dimension) {
		int end = diagonals.size();
		for (int i = 0; i < end; i++) {
			diagonals.add(diagonals.get(i).copy());
			diagonals.get(i).setIteratableCoordinateAt(dimension, true);
			diagonals.get(diagonals.size() - 1).setIteratableCoordinateAt(dimension, false);
		}
		
	}
	
	public void addSimilarDiagonals() {
		initialize();
		use();
	}
	
	
	public void initialize() {
		updateMetaDiagonals();
		//System.out.println(metaDiagonals);
		constructMatrix();
		updateConstants();
		initializeIndex();
		left = Math.variations(dimension - constants.size(), dimension);
	}
	
	public void updateMetaDiagonals() {
		metaDiagonals = new ArrayList<Line>();
		for (int i = 0; i < diagonals.size(); i++) {
			metaDiagonals.add(diagonals.get(i).copy());
		}
	}
	
	public void constructMatrix() {
		Coordinate[] metaCoordinates = metaDiagonals.get(0).getPoints()[0].getCoordinates();
		matrix = new boolean[dimension];
		for (int i = 0; i < metaCoordinates.length; i++) {
			matrix[i] = metaCoordinates[i].getValue() > -1;
		}
	}
	
	public void updateConstants() {
		constants = new ArrayList<Integer>();
		for (int i = 0; i < matrix.length; i++) {
			if (matrix[i] == false) {
				constants.add(i + 1);
			}
		}
		//System.out.println(constants);
	}
	
	public void swap(int dimension, int dimensionTo) {
		int holder;
		for (int i = 0; i < metaDiagonals.size(); i++) {
			Point[] points = metaDiagonals.get(i).getPoints();
			for (int j = 0; j < points.length; j++) {
				Coordinate from = points[j].getCoordinate(dimension);
				Coordinate to = points[j].getCoordinate(dimensionTo);
				holder = from.getValue();
				from.setValue(to.getValue());
				to.setValue(holder);
			}
		}
	}
	
	public void massSwap() {
		updateMetaDiagonals();
		int count = currentDimension;
		for (int i = dimension; i > 0; i -= 1) {
			if (matrix[i - 1]) {
				if (count != i) {
					swap(count, i);
				}
				count-= 1;
			}
		}
	}
	
	public void reorder() {
		int count = 0;
		int currentIndex;
		int freeSpaces;
		for (int i = 0; i < matrix.length; i++) {
			currentIndex = matrix.length - i - 1;
			freeSpaces = count + 1;
			if (matrix[currentIndex]) {
				count++;
				if (currentIndex + freeSpaces < matrix.length) {
					matrix[currentIndex] = false;
					currentIndex++;
					for (int j = currentIndex; j < matrix.length; j++) {
						if (count > 0) {
							matrix[currentIndex] = true;
							count -= 1;
						} else {
							matrix[currentIndex] = false;
						}
						currentIndex++;
					}
				}
			}
		}
		initializeIndex();
	}
	
	public void initializeIndex() {
		int currentIndex;
		for (int i = 0; i < matrix.length; i++) {
			currentIndex = matrix.length - i - 1;
			if (matrix[currentIndex]) {
				index = currentIndex;
				break;
			}
		}
	}
	public void check() {
		//iterate();
		iterateConstants();
		for (int i = 0; i < matrix.length; i++) {
			//System.out.print(matrix[i]);
		}
		//System.out.println();
		//System.out.println(metaDiagonals);
		//System.out.println(constants);
	}
	public void iterate() {
		left -= 1;
		if (index + 1 < matrix.length) {
			//assert ints[index + 1] == -1;
			//System.out.println(index + ":" + ints.length);
			matrix[index + 1] = true;
			matrix[index] = false;
			index++;
		} else {
			reorder();
		}
		updateConstants();
	}
	public void setValues(int dimension, int value) {
		//System.out.println(dimension + " : " + value);
		for (int i = 0; i < metaDiagonals.size(); i++) {
			Point[] points = metaDiagonals.get(i).getPoints();
			for (int j = 0; j < points.length; j++) {
				//System.out.print("\ncheck:\n" + metaDiagonals);
				//System.out.println("Old point: " + points[j]);
				points[j].getCoordinate(dimension).setValue(value);
				//System.out.println("New point: " + points[j]);
			}
		}
	}
	
	public void iterateConstants() {
		//System.out.println("waddup:?");
		int level = constants.size() - 1;
		iterateConstants(level);
	}
	
	public void iterateConstants(int level) {
		for (int i = 0; i < length; i++) {
			setValues(constants.get(level), i);
			if (level > 0) {
				iterateConstants(level - 1);
			} else {
				for (int j = 0; j < metaDiagonals.size(); j++) {
					allDiagonals.add(metaDiagonals.get(j).copy());
					//System.out.println(allDiagonals.get(allDiagonals.size() - 1));
					//System.out.println(metaDiagonals.get(j).copy());
				}
			}
		}
	}
	
	public void use() {
		while (true) {
			//System.out.println("left " + left);
			iterateConstants();
			if (left == 0) {
				break;
			}
			iterate();
			massSwap();
		}
	}
	
	public String toString() {
		String s = "LINES:\n";
		for (int i = 0; i < allDiagonals.size(); i++) {
			s += allDiagonals.get(i) + "\n";
		}
		return s;
	}
}
