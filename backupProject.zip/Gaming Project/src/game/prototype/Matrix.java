package game.prototype;

import java.util.ArrayList;
import java.util.List;

public class Matrix {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * (holders) Instance Variables.
	 * @param temp holds the current pattern
	 * @param metaLines copies temp pattern and modifies itself
	 * @param points holds all the points
	 * @param lines holds all the lines
	 */
	private List<Line> temp = new ArrayList<Line>();
	private List<Line> metaLines = new ArrayList<Line>();
	private List<Point> points = new ArrayList<Point>();
	private List<Line> lines = new ArrayList<Line>();
	
	/**
	 * (HyperCube values) Instance Variables.
	 * @param dimension stores the dimension of the HyperCube
	 * @param length stores the length of the HyperCube
	 * @param currentDimension stores the dimension of the HyperCube the program is currently working in
	 */
	private int dimension;
	private int length;
	private int currentDimension;
	
	/**
	 * (matrix values) Instance Variables.
	 * @param index stores the index of the last element of the matrix pattern
	 * @param left stores the amount of pattern rotations left
	 * @param matrix stores the positions of the pattern and the constants of this pattern rotation
	 * @param constants stores the positions of the constants
	 */
	private int index;
	private int left;
	private boolean[] matrix;
	private List<Integer> constants;
	
	// ------------------------ Constructors ------------------------
	
	/**
	 * Constructs a <code>Matrix</code> with given <code>dimension</code> and <code>length</code>.
	 * @param dimension
	 * @param length
	 */
	//@ requires dimension > 0;
	//@ requires length > 0;
	public Matrix (int dimension, int length) {
		this.dimension = dimension;
		this.length = length;
		this.currentDimension = 2;
	}
	
	/**
	 * Constructs a <code>Matrix</code> from a given <code>HyperCube</code>,
	 * by setting its <code>dimension</code> and <code>length</code> of the same value
	 * as the cube's.
	 * @param cube HyperCube
	 */
	//@ requires cube != null;
	//@ requires cube.getDimension() > 0;
	//@ requires cube.getLength() > 0;
	public Matrix (HyperCube cube) {
		this.dimension = cube.getDimension();
		this.length = cube.getLength();
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Gets the currently extracted points.
	 * @return this.points
	 */
	public List<Point> getPoints() {
		return this.points;
	}
	
	/**
	 * Gets the currently extractedLines().
	 * @return this.lines
	 */
	public List<Line> getLines() {
		return this.lines;
	}
	
	// ------------------------ Extraction Commands ------------------------
	
	/**
	 * Extracts all <code>Point</code> and <code>Line</code>
	 * from an abstract <code>HyperCube</code>.
	 */
	public void extract() {
		extractPoints();
		extractNonDiagonals();
		extractDiagonals();
	}
	
	/**
	 * Extracts all <code>Point</code>s from an abstract <code>HyperCube</code>.
	 */
	public void extractPoints() {
		temp = new ArrayList<Line>();
		currentDimension = 0;
		constructLines();
		constructSimilarLines();
	}
	
	/**
	 * Extracts all non-diagonal <code>Line</code>s from an abstract <code>HyperCube</code>.
	 */
	public void extractNonDiagonals() {
		temp = new ArrayList<Line>();
		currentDimension = 1;
		constructLines();
		constructSimilarLines();
	}
	
	/**
	 * Extracts all diagonal <code>Line</code>s from an abstract <code>HyperCube</code>.
	 */
	public void extractDiagonals() {
		temp = new ArrayList<Line>();
		for (int i = 2; i < dimension; i++) {
			currentDimension = i;
			constructLines();
			constructSimilarLines();
		}
		currentDimension = dimension;
		constructLines();
		for (int i = 0; i < temp.size(); i++) {
			lines.add(temp.get(i).copy());
			
		}
	}
	
	// ------------------------ Construction Commands ------------------------
	
	/**
	 * Constructs a line pattern based on <code>currentDimension</code>.
	 */
	public void constructLines() {
		if (currentDimension == 0) {
			constructOnePointlLine();
		} else if (currentDimension == 1) {
			constructNonDiagonals();
		} else if (currentDimension == 2) {
			construct2DimensionalDiagonals();
		} else {
			constructNDimensionalDiagonals();
		}
	}
	
	/**
	 * Constructs a <code>Line</code> pattern of only one <code>Point</code>,
	 * which is the equivalent to a <code>Point</code> pattern.
	 */
	public void constructOnePointlLine() {
		Line metaLine = new Line(dimension, 1);
		temp.add(metaLine.copy());
	}
	
	/**
	 * Constructs a 1 dimensional <code>Line</code> pattern, which is the pattern for a non-diagonal line.
	 */
	public void constructNonDiagonals() {
		Line metaLine = new Line(dimension, length);
		metaLine.setIteratableCoordinateAt(1, true);
		temp.add(metaLine.copy());
	}
	
	/**
	 * Constructs the 2 2-dimensional <code>Line</code>.
	 * For one of the lines, (x,y) iterate in one direction, for the other <code>Line</code>,
	 * (x,y) iterate in opposite directions. This pattern is the equivalent to the 
	 * diagonals of a 2-dimensional square.
	 */
	public void construct2DimensionalDiagonals() {
		Line metaLine = new Line(dimension, length);
		Line metaLine2 = metaLine.copy();
		for (int i = 0; i < length; i++) {
			metaLine.setIteratableCoordinateAt(1, true);
			metaLine.setIteratableCoordinateAt(2, true);
			
			metaLine2.setIteratableCoordinateAt(1, true);
			metaLine2.setIteratableCoordinateAt(2, false);
		}
		temp.add(metaLine.copy());
		temp.add(metaLine2.copy());
	}
	
	/**
	 * Constructs 2^N diagonals, where N is equal to the current dimension.
	 * for the first half, the coordinate which is in dimension N iterates upwards,
	 * for the second half it iterates downwards.
	 * This pattern is the equivalent to the diagonals of an N-dimensional HyperCube.
	 */
	public void constructNDimensionalDiagonals() {
		int end = temp.size();
		for (int i = 0; i < end; i++) {
			temp.add(temp.get(i).copy());
			temp.get(i).setIteratableCoordinateAt(currentDimension, true);
			temp.get(temp.size() - 1).setIteratableCoordinateAt(currentDimension, false);
		}
	}
	
	/**
	 * Constructs all similar lines possible with the dimensions of this <code>Matrix</code>,
	 * according to the preset pattern which is in <code>temp</code>.
	 */
	public void constructSimilarLines() {
		initialize();
		use();
	}
	
	// ------------------------ Pattern Rotation Commands ------------------------
	
	/**
	 * Initializes the Matrix and the pattern rotation utilities.
	 * <code>left</code> is the number of rotations possible without repeating.
	 */
	public void initialize() {
		updateMetaLines();
		constructMatrix();
		updateConstants();
		initializeIndex();
		left = Math.variations(dimension - constants.size(), dimension);
	}
	
	/**
	 * Initializes <code>metaLines</code>, on which we copy the pattern from <code>temp</code>.
	 */
	public void updateMetaLines() {
		metaLines = new ArrayList<Line>();
		for (int i = 0; i < temp.size(); i++) {
			metaLines.add(temp.get(i).copy());
		}
	}
	
	/**
	 * Constructs the <code>matrix</code> list, which holds booleans according to pattern.
	 * <code>true</code> represents position for pattern,
	 * <code>false</code> represents position for constant.
	 */
	public void constructMatrix() {
		Coordinate[] metaCoordinates = metaLines.get(0).getPoints()[0].getCoordinates();
		matrix = new boolean[dimension];
		for (int i = 0; i < metaCoordinates.length; i++) {
			matrix[i] = metaCoordinates[i].getValue() > -1;
		}
	}
	
	/**
	 * Updates the <code>constants</code> list with all the new positions
	 * for the constants of this pattern rotation.
	 */
	public void updateConstants() {
		constants = new ArrayList<Integer>();
		for (int i = 0; i < matrix.length; i++) {
			if (matrix[i] == false) {
				constants.add(i + 1);
			}
		}
	}
	
	/**
	 * Initializes the index for the pattern coordinate
	 * which is nearest the end of the <code>matrix</code>.
	 * <code>currentIndex</code> is used to check the list in reverse.
	 */
	public void initializeIndex() {
		int currentIndex;
		for (int i = 0; i < matrix.length; i++) {
			currentIndex = matrix.length - i - 1;
			if (matrix[currentIndex]) {
				index = currentIndex;
				break;
			}
		}
	}
	
	/**
	 * Uses the Matrix, for each pattern rotation,
	 * it fills all the positions which do not belong to the pattern
	 * with all possible constant values depending on <code>length</code>,
	 * then it rotates the pattern until it's used up all the pattern rotations
	 * and constant combinations. 
	 */
	public void use() {
		while (true) {
			left -= 1;
			if (constants.size() > 0) {
				iterateConstants(constants.size() - 1);
			}
			if (left == 0) {
				break;
			}
			iterate();
			massSwap();
		}
	}
	
	
	/**
	 * Iterates all constants on all constant positions left according to <code>matrix</code>.
	 * @param level indicates recursion depth, as well as constant position, 
	 */
	public void iterateConstants(int level) {
		for (int i = 0; i < length; i++) {
			setConstant(constants.get(level), i);
			if (level > 0) {
				iterateConstants(level - 1);
			} else {
				update();
			}
		}
	}
	
	/**
	 * Sets a constant value on a specific dimension coordinate
	 * in every <code>Line</code> in <code>metaLines</code>
	 * @param dimension distinguishes coordinates
	 * @param value constant
	 */
	public void setConstant(int dimension, int value) {
		for (int i = 0; i < metaLines.size(); i++) {
			Point[] points = metaLines.get(i).getPoints();
			for (int j = 0; j < points.length; j++) {
				points[j].getCoordinate(dimension).setValue(value);
			}
		}
	}
	
	/**
	 * Updates <code>points</code> or <code>lines</code>.
	 * If the matrix consists of constants only, it means it's a <code>Point</code>.
	 */
	public void update() {
		if (constants.size() == matrix.length) {
			updatePoints();
		} else {
			updateLines();
		}
	}
	
	/**
	 * Updates <code>points</code> with the current <code>metaLine</code>,
	 * which consists of only 1 <code>Point</code>.
	 * The <code>Point</code> is extracted and appended to <code>points</code>.
	 */
	public void updatePoints() {
		for (int i = 0; i < metaLines.size(); i++) {
			points.add(metaLines.get(i).getPoints()[0].copy());
		}
	}
	
	/**
	 * Updates <code>lines</code> by appending a copy of the current <code>metaLines</code> list.
	 */
	public void updateLines() {
		for (int i = 0; i < metaLines.size(); i++) {
			lines.add(metaLines.get(i).copy());
		}
	}
	
	/**
	 * Copies the original pattern which is not rotated from <code>temp</code>.
	 * Then swaps the values of the <code>Coordinate</code>s from the original pattern
	 * with the <code>Coordinates</code> from the new pattern rotation, according to the
	 * new dimensional values.
	 */
	public void massSwap() {
		updateMetaLines();
		int count = currentDimension;
		for (int i = dimension; i > 0; i -= 1) {
			if (matrix[i - 1]) {
				if (count != i) {
					swap(count, i);
				}
				count-= 1;
			}
		}
	}
	
	/**
	 * Swaps the values of
	 * <code>Coordinate</code> of dimension <code>dimension</code>
	 * with <code>Coordinate</code> of dimension <code>dimensionTo</code>
	 * in every <code>Point</code>
	 * in every <code>Line</code>
	 * in <code>metaLines</code>.
	 * The effect is used to rotate patterns.
	 * @param dimension coordinate1
	 * @param dimensionTo coordinate2
	 */
	public void swap(int dimension, int dimensionTo) {
		int holder;
		for (int i = 0; i < metaLines.size(); i++) {
			Point[] points = metaLines.get(i).getPoints();
			for (int j = 0; j < points.length; j++) {
				Coordinate from = points[j].getCoordinate(dimension);
				Coordinate to = points[j].getCoordinate(dimensionTo);
				holder = from.getValue();
				from.setValue(to.getValue());
				to.setValue(holder);
			}
		}
	}
	
	/**
	 * Rotates matrix patterns by moving the last element of the pattern
	 * one position nearer the end.
	 * If the end has been reached, it reorders the elements.
	 */
	public void iterate() {
		if (index + 1 < matrix.length) {
			matrix[index + 1] = true;
			matrix[index] = false;
			index++;
		} else {
			reorder();
		}
		updateConstants();
	}
	
	/**
	 * Reorder the elements in a pattern, when the last element reaches the end of the matrix.
	 * Initializes index again.
	 */
	public void reorder() {
		int count = 0;
		int currentIndex;
		int freeSpaces;
		for (int i = 0; i < matrix.length; i++) {
			currentIndex = matrix.length - i - 1;
			freeSpaces = count + 1;
			if (matrix[currentIndex]) {
				count++;
				if (currentIndex + freeSpaces < matrix.length) {
					matrix[currentIndex] = false;
					currentIndex++;
					for (int j = currentIndex; j < matrix.length; j++) {
						if (count > 0) {
							matrix[currentIndex] = true;
							count -= 1;
						} else {
							matrix[currentIndex] = false;
						}
						currentIndex++;
					}
				}
			}
		}
		initializeIndex();
	}	
	
	public String toString() {
		String s = "LINES:\n";
		for (int i = 0; i < lines.size(); i++) {
			s += lines.get(i) + "\n";
		}
		return s;
	}
}
