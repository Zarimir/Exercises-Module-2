/**
 * 
 */
package game;

/**
 * @author Zarry
 * @version 3.0
 */
public interface Strategy {
	
	/**
	 * Strategy name.
	 * @return name of the strategy
	 */
	public String getName();
	
	/**
	 * Next legal move.
	 * @param b board
	 * @param m mark
	 * @return index of the square
	 */
	public int determineMove(Board b, Mark m);
}
