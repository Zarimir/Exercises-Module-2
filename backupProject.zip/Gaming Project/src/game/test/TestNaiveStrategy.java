package game.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import game.ai.ComputerPlayer;
import game.ai.NaiveStrategy;
import game.ai.Strategy;
import game.geometry.HyperCube;
import game.geometry.Point;
import game.logic.Mark;

public class TestNaiveStrategy {

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 */
	private static final int DIM = 3;
	private static final int LENGTH = 4;
	private static final int VAL = 1000;
	
	private static final Mark EMPTY = Mark.EMPTY;
	private static final Mark NOT_EMPTY = Mark.XX;
	
	public static final Strategy NAIVE = new NaiveStrategy();
	private static final ComputerPlayer BOT = new ComputerPlayer(NOT_EMPTY);
	private HyperCube cube;
	
	// ------------------------ Setup ------------------------
	
	/**
	 * Sets two identical cubes and initializes them.
	 */
	@Before
	public void setUp() {
		cube = new HyperCube(DIM, LENGTH);
		cube.initialize();
	}
	
	// ------------------------ Test Queries ------------------------
	
	/**
	 * Expected to only return points from a cube which are with Mark.EMPTY.
	 * Expected to return null if there aren't any free points.
	 */
	@Test
	public void testDetermineMove() {
		for (int i = 0; i < VAL; i++) {
			Point move = BOT.determineMove(cube);
			assertEquals(EMPTY, move.getMark());
		}
		
		for (int i = VAL / VAL; i < cube.getPoints().size(); i++) {
			cube.getPoints().get(i).setMark(NOT_EMPTY);
		}
		
		for (int i = 0; i < VAL / VAL; i++) {
			Point move = BOT.determineMove(cube);
			assertEquals(EMPTY, move.getMark());
		}
		
		for (int i = 0; i < cube.getPoints().size(); i++) {
			cube.getPoints().get(i).setMark(NOT_EMPTY);
		}
		
		for (int i = 0; i < VAL; i++) {
			Point move = BOT.determineMove(cube);
			assertEquals(null, move);
		}
	}
}
