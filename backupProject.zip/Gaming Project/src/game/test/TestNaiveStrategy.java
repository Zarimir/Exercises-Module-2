package game.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import game.ai.ComputerPlayer;
import game.ai.NaiveStrategy;
import game.ai.Strategy;
import game.geometry.HyperCube;
import game.logic.Mark;

public class TestNaiveStrategy {

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 */
	private static final int DIM = 3;
	private static final int LENGTH = 4;
	private static final int VAL = 1000;
	
	private static final Mark EMPTY = Mark.EMPTY;
	private static final Mark NOT_EMPTY = Mark.XX;
	
	public static final Strategy NAIVE = new NaiveStrategy();
	private ComputerPlayer BOT = new ComputerPlayer();
	private HyperCube cube;
	
	// ------------------------ Setup ------------------------
	
	/**
	 * Sets two identical cubes and initializes them.
	 */
	@Before
	public void setUp() {
		cube = new HyperCube(DIM, LENGTH);
		cube.initialize();
		BOT.setCube(cube);
		BOT.setMark(NOT_EMPTY);
	}
	
	// ------------------------ Test Queries ------------------------
	
	/**
	 * Expected to only return points from a cube which are with Mark.EMPTY.
	 */
	@Test
	public void testDetermineMove() {
		for (int i = 0; i < VAL; i++) {
			BOT.determinePoint();
			assertEquals(EMPTY, BOT.getPoint().getMark());
		}
		
		BOT.determinePoint();
		assertEquals(EMPTY, BOT.getPoint().getMark());
		BOT.determinePoint();
		BOT.getPoint().setMark(NOT_EMPTY);
		assertEquals(NOT_EMPTY, BOT.getPoint().getMark());
		assertEquals(null, BOT.getFromCube());
	}
}
