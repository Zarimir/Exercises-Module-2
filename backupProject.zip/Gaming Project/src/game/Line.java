/**
 * 
 */
package game;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Zarry
 *
 */
public class Line {
	
	public static void main(String[] args) {
		
	}
	
	// ------------------------ Constructor ------------------------
	
	//@ private invariant points != null;
	private HyperCube cube;
	private Point[] points;
	
	//@ requires points != null;
	public Line(Point[] points) throws ArithmeticException {
		assert points.length == cube.getLength();
		this.points = Point.copy(points);
	}
	
	public String toString() {
		String s = "";
		for (int i = 0; i < this.points.length - 1; i++) {
			s += this.points[i] + ",";
		}
		s += this.points[this.points.length - 1] + ";";
		return s;
	}
	
	public Mark ownedBy() {	
		Mark owner = Mark.EMPTY;
		boolean hasWinner = true;
		for (int i = 0; i < this.points.length; i++) {
			if (owner.equals(Mark.EMPTY) &&
					!this.points[i].getMark().equals(owner)) {
				owner = this.points[i].getMark();
			} else if (!owner.equals(Mark.EMPTY) &&
					!this.points[i].getMark().equals(owner)) {
				owner = null;
				hasWinner = false;
				break;
			}
			if (this.points[i].getMark().equals(Mark.EMPTY)) {
				hasWinner = false;
			}
		}
		
		if (owner == null) {
			return null;
		} else if (!hasWinner) {
			return Mark.EMPTY;
		} else {
			return owner;
		}
	}
	
	public boolean isAffected(Point move) {
		for (int i = 0; i < this.points.length; i++) {
			if (this.points[i].isAffected(move)) {
				return true;
			}
		}
		return false;
	}
	
	/*
	public static Line[] collectLines(HyperCube cube) {
		return null;
	}
	*/
	
	/*
	public static void collectPoints(int length, int dimension) throws ArithmeticException {
    	if (length > 1 && dimension > 1) {
    		Point[] points = new Point[pow(length, dimension)];
    		Line[] lines = new Line[];
    		shredCube(points, dimension, length);
    		
    		// Asserts whether points is null or has a negative value
    		assert assertCheck(points);
    	} else {
    		throw new ArithmeticException("The length and the dimension should be larger than 1!");
    	}
	}
	*/
	
	public static void prnt(List<Line> lines) {
		String s = "";
		for (int i = 0; i < lines.size(); i++) {
			s += "Line " + i + ": ";
			if (i != lines.size() - 1) {
				s += lines.get(i).toString() + ", ";
			} else {
				s += ";";
			}
		}
		System.out.println(s);
	}
	
	public static List<Line> collectLines(HyperCube cube) throws ArithmeticException {
    	if (cube.getLength() > 1 && cube.getDimension() > 1) {
    		List<Line> lines = new ArrayList<Line>();
    		extractStraightLines(cube, lines);
    		// Asserts whether points is null or has a negative value
    		//assert assertCheck(lines);
    		return lines;
    	} else {
    		throw new ArithmeticException("The length and the dimension should be larger than 1!");
    	}
	}
	
	// recursion will solve
	public static void extractStraightLines(HyperCube cube, List<Line> lines) {
		Coordinate[] transitCoords = new Coordinate[cube.getDimension()];
		Coordinate[] transitLine = new Coordinate[cube.getLength()];
		int level;
		for (int i = 0; i < transitCoords.length; i++) {
			for (int j = 0; j < transitCoords.length; j++) {
				transitCoords[j] = new Coordinate(transitCoords.length - j, -1);
				//System.out.print(transitCoords[j]);
			}
			level = transitCoords.length;
			extractStraightLines(cube, lines, transitCoords, transitLine, level);
		}
	}
	
	public static void extractStraightLines (
			HyperCube cube,
			List<Line> lines,
			Coordinate[] transitCoords,
			Coordinate[] transitLine,
			int level) {
		Point[] points = new Point[cube.getLength()];
		for (int i = 0; i < transitLine.length; i++) {
			transitCoords[0].setValue(i);
			//System.out.print("level " + level + ": ");
			//Coordinate.prnt(transitCoords);
			//System.out.println();
			if (level > 1) {
				//System.out.println("y = " + i + "index = " + index);
				Coordinate.iterateForward(transitCoords);
				extractStraightLines(
						cube, lines, transitCoords,
						transitLine, level - 1);
			} else {
				//System.out.println("\nx = " + i + "index = " + index);
				for (int j = 0; j < transitCoords.length; j++) {
					
				}
				//Coordinate.prnt(transitCoords);
				points[i] = cube.getPoint(transitCoords);
				//System.out.println(points[i]);
			}
			
		}
		for (int i = 0; i < points.length; i++) {
			//System.out.print(points[i]);
		}
		if (level == 1) {
			//System.out.print("\nPOP:");
			//for (int i = 0; i < points.length; i++) {
				//System.out.print(points[i]);				
			//}
			//System.out.println("Hello");
			//System.out.println(points);
			Line obj = new Line(points);
			//System.out.println(obj);
			lines.add(obj);
			//System.out.println();
		}
		Coordinate.iterateForward(transitCoords);
		level++;
		
		
		
		
	}
	
	public static void diagonals() {
		
	}
	
}




/*
public static List<Line> collectLines(HyperCube cube) throws ArithmeticException {
if (cube.getLength() > 1 && cube.getDimension() > 1) {
	List<Line> lines = new ArrayList<Line>();
	extractStraightLines(cube, lines);
	// Asserts whether points is null or has a negative value
	//assert assertCheck(lines);
	return lines;
} else {
	throw new ArithmeticException("The length and the dimension should be larger than 1!");
}
}

public static void extractStraightLines(HyperCube cube, List<Line> lines) {
int[] transitCoords = new int[cube.getDimension()];
int[] transitLine = new int[cube.getLength()];
int index;
for (int i = 0; i < transitCoords.length; i++) {
	for (int j = 0; j < transitCoords.length; j++) {
		transitCoords[j] = -1;
		//System.out.print(transitCoords[j]);
	}
	index = transitCoords.length - 1 - i;
	//System.out.println(index);
	extractStraightLines(cube, lines, transitCoords, transitLine, index);
}
}

public static void extractStraightLines (
	HyperCube cube,
	List<Line> lines,
	int[] transitCoords,
	int[] transitLine,
	int index) {
//System.out.println(index - 2 + " : " + transitCoords.length);
boolean notLast = (transitCoords[Math.modulo(index - 1, transitCoords.length)] == (-1));
//System.out.println("Got here");
Point[] points = new Point[cube.getLength()];
for (int i = 0; i < transitLine.length; i ++) {
	transitCoords[index] = i;
	if (notLast) {
		//System.out.println("y = " + i + "index = " + index);
		extractStraightLines(
				cube, lines, transitCoords,
				transitLine, Math.modulo(index - 1, transitCoords.length));
	} else {
		//System.out.println("\nx = " + i + "index = " + index);
		for (int j = 0; j < transitCoords.length; j++) {
		}
		points[i] = cube.getPoint(transitCoords);
	}
	
}
for (int i = 0; i < points.length; i++) {
	//System.out.print(points[i]);
}
if (!notLast) {
	System.out.print("\nPOP:");
	for (int i = 0; i < points.length; i++) {
		//System.out.print(points[i]);				
	}
	Line obj = new Line(points);
	System.out.print(obj);
	lines.add(obj);
	//System.out.println();
}
}
*/