/**
 * 
 */
package game;

/**
 * @author Zarry
 *
 */
public class Line {
	
	public static void main(String[] args) {
		System.out.println(Math.pow(3, 0));
	}
	
	// ------------------------ Constructor ------------------------
	
	//@ private invariant length > 1;
	//@ private invariant points != null;
	private static int length;
	private HyperCube cube;
	private Point[] points;
	
	//@ requires points != null;
	public Line(Point[] points) throws ArithmeticException {
		assert points.length == cube.getLength();
		this.points = points;
	}
	
	public Mark ownedBy() {
		Mark ownedBy = this.points[0].getMark();
		
		if (ownedBy.equals(Mark.EMPTY)) {
			return null;
		}
		
		for (int i = 1; i < this.points.length; i++) {
			if (!points[1].getMark().equals(ownedBy)) {
				return null;
			}
		}
		
		return ownedBy;
	}
	
	public static Line[] collectLines(HyperCube cube) {
		return null;
	}
	
	public static void collectPoints(int length, int dimension) throws ArithmeticException {
    	if (length > 1 && dimension > 1) {
    		Point[] points = new Point[pow(length, dimension)];
    		Line[] lines = new Line[];
    		shredCube(points, dimension, length);
    		
    		// Asserts whether points is null or has a negative value
    		assert assertCheck(points);
    	} else {
    		throw new ArithmeticException("The length and the dimension should be larger than 1!");
    	}
	}
	
	public static void shredCube(Line[] lines, int DIM, int Length) {
		return null;
	}
	
	public static void straightLines() {
		
	}
	
	public static void diagonals() {
		
	}
	
}
