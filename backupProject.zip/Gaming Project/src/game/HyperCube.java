package game;

import java.util.Iterator;
import java.util.List;

public class HyperCube {
	
	public static void main(String[] args) {
		HyperCube obj = new HyperCube(2, 2);
		// System.out.println(obj.outerDiagonals());
		obj.initialize();
		//Line.prnt(obj.getLines());
		//System.out.println(obj.getPointsString());
	}
	
	private int dimension;
	private int length;
	private Point[] points;
	private List<Line> lines;
	
	//@ requires dimension > 1;
	//@ requires length > 1;
	public HyperCube(int dimension, int length) {
		assert dimension > 1;
		assert length > 1;
		
		this.dimension = dimension;
		this.length = length;
	}
	
	public void initialize() {
		this.points = Point.collectPoints(this);
		this.lines = Line.collectLines(this);
	}
	
	public Point[] getPoints() {
		return this.points;
	}
	
	public String getPointsString() {
		String s = "";
		for (int i = 0; i < this.points.length; i++) {
			s += this.points[i];
		}
		return s;
	}
	
	// needs to be checked
	public Point getPoint(int[] coordinates) {
		Coordinate.extractCoordinates(coordinates);
		return this.getPoint(coordinates);
		/*
		for (int i = 0; i < this.points.length; i++) {
			if (this.points[i].equals(coordinates)) {
				return this.points[i];
			}
			
		}
		return null;
		*/
	}
	
	public Point getPoint(Coordinate[] coordinates) {
		//Coordinate.prnt(coordinates);
		for (int i = 0; i < this.points.length; i++) {
			//System.out.println(this.points[i] + " = " + i);
			if (this.points[i].equals(coordinates)) {
				return this.points[i];
			}
			
		}
		return null;
	}
	
	public void updateLines(Point move) {
		Line line;
		Mark m;
		for (Iterator<Line> it = this.lines.iterator(); it.hasNext();) {
			line = it.next();
			if (line.isAffected(move)) {
				m = line.ownedBy();
				if (m == null) {
					it.remove();
				} else if (!m.equals(Mark.EMPTY)) {
					
				}
			}
		}
	}
	
	public List<Line> getLines() {
		return this.lines;
	}
	
	public int getDimension() {
		return this.dimension;
	}
	
	public int getLength() {
		return this.length;
	}
	
	public int edges() {
		return this.dimension * Math.pow(this.length, this.dimension - 1);
	}
	
	public int outerDiagonals() {
		return Math.pow(2, dimension - 1) * (Math.pow(2, dimension) - dimension - 1); 
	}
	
	//public int outerDiagonals(int face) {
	//	return Math.pow(2, dimension - 1) * (Math.pow(2, dimension) - dimension - 1); 
	//}
}