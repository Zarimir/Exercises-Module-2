package game;

public class HyperCube {
	
	public static void main(String[] args) {
		HyperCube obj = new HyperCube(4, 2);
		System.out.println(obj.outerDiagonals());
	}
	
	private int dimension;
	private int length;
	private Point[] points;
	private Line[] lines;
	
	//@ requires dimension > 1;
	//@ requires length > 1;
	public HyperCube(int dimension, int length) {
		assert dimension > 1;
		assert length > 1;
		
		this.dimension = dimension;
		this.length = length;
	}
	
	public void initialize() {
		this.points = Point.collectPoints(this);
		this.lines = Line.collectLines(this);
	}
	
	public Point[] getPoints() {
		return this.points;
	}
	
	public Line[] getLines() {
		return this.lines;
	}
	
	public int getDimension() {
		return this.dimension;
	}
	
	public int getLength() {
		return this.length;
	}
	
	
	
	
	public int edges() {
		return this.dimension * Math.pow(this.length, this.dimension - 1);
	}
	
	public int outerDiagonals() {
		return Math.pow(2, dimension - 1) * (Math.pow(2, dimension) - dimension - 1); 
	}
	
	//public int outerDiagonals(int face) {
	//	return Math.pow(2, dimension - 1) * (Math.pow(2, dimension) - dimension - 1); 
	//}
}