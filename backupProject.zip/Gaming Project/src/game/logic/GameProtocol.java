package game.logic;

public interface GameProtocol {

}
