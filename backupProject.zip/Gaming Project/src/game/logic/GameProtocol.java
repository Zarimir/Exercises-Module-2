package game.logic;

public interface GameProtocol {

	public static final String DETERMINE_MOVE = "DETERMINE_MOVE";
	public static final String SHOW_GAME = "SHOW_GAME";
	public static final String EXIT = "EXIT";
	public static final String DELIMITER = ";";
	public static final String ERROR_ENFORCED_COMMAND = "ERROR_ENFORCED_COMMAND";
}