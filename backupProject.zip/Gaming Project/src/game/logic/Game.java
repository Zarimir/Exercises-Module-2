package game.logic;

import java.util.Observable;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import game.geometry.HyperCube;
import game.ui.PlayerTUI;
import game.ui.View;

/**
 * The controller of the game according to the MVC model.
 * Unifies the model, view and networking aspects of the game.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class Game extends Observable implements GameProtocol {

	// ------------------------ Instance Variables ------------------------

    /**
     * Instance Variables.
     * @param cube of this <code>Game</code>
     * @param platers of this <code>Game</code>
     * @param current the index of the current <code>Player</code>
     */
    //@ private invariant board != null;
	//@ private invariant (\forall int i; 0 <= i && i < NUMBER_PLAYERS; players[i] != null);
	//@ private invariant 0 <= current  && current < NUMBER_PLAYERS;
	private HyperCube cube;
	private Set<Player> players = ConcurrentHashMap.newKeySet();
    private View view;
    private static final Mark DEFAULT = Mark.XX;
    private boolean exit = false;
    

    // ------------------------ Constructor ------------------------

    //@ requires s0 != null;
    //@ requires s1 != null;
    public Game() {
        this(3,4);
    }
    
    //@ requires dimension > 1;
    //@ requires length > 1;
    public Game(int dimension, int length) {
        view = new PlayerTUI(this);
        cube = new HyperCube(dimension, length);
        cube.initialize();
    }
    
    // ------------------------ Queries ------------------------
    
    public HyperCube getHyperCube() {
    	return this.cube;
    }
    
    public Set<Player> getPlayers() {
    	return this.players;
    }
    
    // ------------------------ Commands ------------------------
    
    /**
     * Starts the Tic Tac Toe game. <br>
     * Asks after each ended game if the user wants to continue. Continues until
     * the user does not want to play anymore.
     */
    /*
    public void start() {
        boolean again = true;
        while (again) {
            cube.initialize();
            play();
        }
    }
    */

    /**
     * Plays the Tic Tac Toe game. <br>
     * First the (still empty) board is shown. Then the game is played until it
     * is over. Players can make a move one after the other. After each move,
     * the changed game situation is printed.
     */
    public void play() {
    	while (cube.getWinner() == null && !exit) {
    		for (Player player : players) {
        		player.makeMove(); //update game
    		}
    	}
    	view.showWinner(getPlayer(cube.getWinner()));
    }
    
    public void addPlayer(Player newPlayer) {
    	if (players.size() == 0) {
    		newPlayer.setMark(DEFAULT);
    	} else {
    		newPlayer.setMark(DEFAULT.other());
    	}
    	newPlayer.addObserver(view);
    	this.setChanged();
    	this.notifyObservers(newPlayer);
    	players.add(newPlayer);
    }
    
    public void setCubes() {
    	for (Player player : players) {
    		player.setCube(this.cube);
    	}
    }
    
    public Player getPlayer(Mark mark) {
    	if (mark == null) {
    		return null;
    	} else {
    		for (Player player : players) {
    			if (player.getMark() == mark) {
    				return player;
    			}
    		}
    		return null;
    	}
    }
    
    public void exit(String string) {
    	this.exit = true;
    	this.setChanged();
    	this.notifyObservers(string);
    }
}