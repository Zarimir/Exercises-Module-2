package game;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Zarimir
 * @version 3.0
 */
public class Point {

	// ------------------------ Main ------------------------

	public static void main(String[] args) {
		/*
		//Point.collectPoints(4, 1);
		//System.out.println(Point.collectPoints(3, 2));
		List<Integer> ints = new ArrayList<Integer>();
		//System.out.println("hi");
		for (int i = 0; i < 5; i++) {
			ints.add(new Integer(i));
		}
		ints.remove(2);
		System.out.print(ints);
		for (int i = 0; i < ints.size(); i++) {
			System.out.print(ints.get(i).intValue());
		}
		int[] a = {1,2,3};
		int[] b = {1,2,3};
		System.out.println(a.equals(b));
		System.out.println((5) % 4);
		*/
	}

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension the dimensions of the points
	 * @param coordinates the coordinates of the point
	 * @param mark the mark of the point
	 */
	//@ private invariant dimension > 1;
	//@ private invariant coordinates.length > 1;
	//@ private invariant mark != null;
	private HyperCube cube;
	private Coordinate[] coordinates;
	private Mark mark;
	
	// ------------------------ Constructor ------------------------

	/**
	 * Constructor takes a HyperCube and an array of integers as coordinates and sets the mark to EMPTY.
	 * @param cube the HyperCube this point belongs to
	 * @param coordinates the coordinates of the point
	 */
	//@ requires coordinates != null;
	//@ requires coordinates.length > 1;
	public Point(/*HyperCube cube, */Coordinate[] coordinates) {
		//this.cube = cube;
		this.coordinates = Coordinate.copy(coordinates);
		Coordinate.order(this.coordinates);
		this.mark = Mark.EMPTY;
	}
	
	/**
	 * The String of this class returns its coordinates in brackets.
	 */
	//@ ensures \result != null;
	public String toString() {
		String s = "";
		s += "(";
		for (int i = 0; i < this.coordinates.length - 1; i++) {
			s += this.coordinates[i] + ", ";
		}
		s += this.coordinates[this.coordinates.length - 1];
		s += ")";
		return s;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Gets the Mark of the point.
	 * @return the mark of this point
	 */
	//@ ensures \result != null; && \result != Mark.EMPTY;;
	public Mark getMark() {
		return this.mark;
	}
	
	public Coordinate[] getCoordinates() {
		return this.coordinates;
	}
	
	public boolean isAffected(Point move) {
		if (move == null) {
			throw new ArithmeticException("Is null!");			
		} else if (move.getMark().equals(Mark.EMPTY)) {
			throw new ArithmeticException("Move belongs to empty!");			
		}
		return this.equals(move) && !this.getMark().equals(move.getMark());
	}
	
	public boolean equals(Point point) throws ArithmeticException {
		if (point == null) {
			throw new ArithmeticException("Is null!");			
		} else if (point.getCoordinates().length == this.coordinates.length) {
			for (int i = 0; i < this.coordinates.length; i++) {
				if (!this.coordinates[i].equals(point.getCoordinates()[i])) {
					return false;
				}
			}
			return true;
		}
		throw new ArithmeticException("Uncompatible dimensions!");
		
	}
	
	public boolean equals(Coordinate[] coordinates) throws ArithmeticException {
		//System.out.println("Length: " + coordinates.length + ":" + this.coordinates.length);
		/*if (coordinates == null) {
			throw new ArithmeticException("Is null");
		} else */if (coordinates.length == this.coordinates.length) {
			for (int i = 0; i < coordinates.length; i++) {
				if (!this.coordinates[i].equals(coordinates[i])) {
					return false;
				}
			}
			return true;
		}
		throw new ArithmeticException("Uncompatible dimensions!");
	}
	
	public boolean equals(int[] coordinates) throws ArithmeticException {
		if (coordinates == null) {
			throw new ArithmeticException("Is null");
		} else {
			return this.equals(Coordinate.extractCoordinates(coordinates));
		}
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the point to belong to a player.
	 * @param ownedBy the player who marks this point
	 */
	//@ requires ownedBy != null && ownedBy != Mark.EMPTY;
	public void setMark(Mark ownedBy) {
		this.mark = ownedBy;
	}
	
	public static Point copy(Point point) {
		if (point == null) {
			throw new ArithmeticException("Point is null!");
		}
		return new Point(point.getCoordinates());
	}
	
	public static Point[] copy(Point[] points) {
		if (points == null) {
			throw new ArithmeticException("Point is null!");
		}
		Point[] p = new Point[points.length];
		for (int i = 0; i < points.length; i ++) {
			p[i] = Point.copy(points[i]);
		}
		return p;
	}
	
	// ------------------------ Static Commands ------------------------
	
	/**
	 * Takes an N dimensional HyperCube and returns a list of all its points according to its length and dimension.
	 * The number of points collected is equal to the length to the power of the dimension.
	 * @param length the length of the HyperCube
	 * @param dimension the dimension of the HyperCube
	 * @throws ArithmeticException whenever the length is NOT longer than 1 or the dimension is NOT larger than 1
	 */
	//@ requires cube != null;
	//@ ensures \result.length == Math.pow(cube.getLength, cube.getDimension);
	//@ ensures \forall(int i; 0 <= i && i < \result.length; \result[i] != null);
	public static Point[] collectPoints(HyperCube cube) throws ArithmeticException {
    	if (cube.getLength() > 1 && cube.getDimension() > 1) {
    		Point[] points = new Point[Math.pow(cube.getLength(), cube.getDimension())];
    		extractPoints(cube, points);
    		// Asserts whether points is null or has a negative value
    		assert assertCheck(points);
    		return points;
    	} else {
    		throw new ArithmeticException("The length and the dimension should be larger than 1!");
    	}
	}
	
	/**
	 * Initiates recursive for loops in order to generate all the required points.
	 * @param points a list of all the points
	 * @param dimension the dimensions of the HyperCube
	 * @param length the length of the HyperCube
	 */
	//@ requires dimension > 1;
	//@ requires length > 1;
	//@ requires points.length == Math.pow(length, dimension);
	public static void extractPoints(HyperCube cube, Point[] points) {
		Coordinate[] transit = new Coordinate[cube.getDimension()];
		for (int i = 0; i < transit.length; i++) {
			transit[i] = new Coordinate(transit.length - i, 0);
			//System.out.print(transit[i].getDimension() + " : " + transit[i].getValue());
		}
		extractPoints(cube, points, transit, cube.getDimension());
	}
	
	public static void extractPoints(HyperCube cube, Point[] points, Coordinate[] transit, int level) {
		// Asserts whether transit is null or has a negative coordinate
		//assert assertCheck(transit) == true;
		
		for (int i = 0; i < cube.getLength(); i++) {
			//System.out.println(level);
			transit[0].setValue(i);
			//System.out.println("level " + level + " = [" + transit[0].getDimension() + ":" + transit[0].getValue() + "]");
			if (level > 1) {
				//System.out.println("iterate");
				Coordinate.iterateForward(transit);
				//Coordinate.iterateForward(transit);
				extractPoints(cube, points, transit, level - 1);
			} else {
				for (int j = 0; j < points.length; j++) {
					if (points[j] == null) {
						// Asserts whether transit is null or has a negative coordinate
						//assert assertCheck(transit) == true;
						
						points[j] = new Point(transit);
						//System.out.println(points[j]);
						break;
					}
				}
			}
		}
		Coordinate.iterateBackward(transit);
	}
	
	// ------------------------ Assert Checks ------------------------
	
	/**
	 * Checks whether <code>transit</code> contains a negative coordinate.
	 * @param transit the array of integers
	 * @return false if it is null or contains a negative integer; true otherwise
	 */
	//@ requires transit != null;
	public static boolean assertCheck(int[] transit) {
		if (transit == null) {
			return false;
		}
		for (int i = 0; i < transit.length; i++) {
			if (transit[i] < 0) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Asserts whether <code>collectPoints()</code> is containing a point equal to null.
	 * @param transit the array of points
	 * @return false if it is null or contains a null; true otherwise
	 */
	//@ requires transit != null;
	public static boolean assertCheck(Point[] transit) {
		if (transit == null) {
			return false;
		}
		for (int i = 0; i < transit.length; i++) {
			if (transit[i] == null) {
				return false;
			}
		}
		return true;
	}
}