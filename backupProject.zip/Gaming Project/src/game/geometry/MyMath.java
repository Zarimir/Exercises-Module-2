package game.geometry;

/**
 * Contains methods for raising a number to a power, finding remainder of division, 
 * calculating number of variations and calculating number of diagonals of a HyperCube.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class MyMath {
	public static void main(String[] args) {
		int num1 = 5;
		int num2 = 10;
		System.out.println(MyMath.variations(num1, num2));
		System.out.println(num1 + ": " + num2);
	}
	/**
	 * Raises a number to the power of another number.
	 * @param number
	 * @param power has to be >= 0
	 * @return number ^ power
	 * @throws ArithmeticException whenever the power is less than 1
	 */
	//@ requires power > -1;
	public static int pow(int number, int power) throws ArithmeticException {
		//System.out.println("myMath");
		if (power >= 0) {
			int result = 1;
			for (int i = 0; i < power; i++) {
				result *= number;
			}
			return result;
		} else {
			throw new ArithmeticException("This method does NOT allow powers lower than 0!");
		}
	}
	
	/**
	 * Takes a num, divides by mod and returns the remainder.
	 * @param num number
	 * @param mod modulo
	 * @return remainder 
	 */
	//@ requires mod > 0;
	public static int modulo(int num, int mod) {
		int result;
		result = num;
		while (result < 0) {
			result += mod;
		}
		while (result >= mod) {
			result -= mod;
		}
		return result;
	}
	
	/**
	 * Calculates the factorial of a number.
	 * @param number argument
	 * @return number!
	 */
	public static int factorial(int number) {
		if (number < 2) {
			return 1;
		} else {
			return number * factorial(number - 1);
		}
	}
	
	/**
	 * Calculates the number of non-repeating variations.
	 * @param numbers number of subject elements
	 * @param totalNumbers total number of elements
	 * @return number of non-repeating variations
	 */
	public static int variations(int numbers, int totalNumbers) {
		return factorial(totalNumbers) / (factorial(numbers) * factorial(totalNumbers - numbers));
	}
	
	/**
	 * Calculates the number of all diagonals in an N dimensional HyperCube.
	 * @param dimension of the HyperCube
	 * @param length of the HyperCube
	 * @return total number of diagonals
	 */
	public static int calculateNumberOfDiagonals(int dimension, int length) {
		int total = 0;
		int diagonals = 1;
		int variations;
		int rotations;
		int otherDimensions;
		for (int i = 2; i <= dimension; i++) {
			otherDimensions = dimension - i;
			diagonals *= 2;
			variations = pow(length, otherDimensions);
			rotations = variations(i, dimension);
			total += diagonals * variations * rotations;
		}
		return total;
	}
}
