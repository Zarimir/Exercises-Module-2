package game.geometry;

/**
 * Represents a coordinate of a point.
 * The dimension represents which coordinate it is (x,y,z...etc.).
 * The value represents its value.
 * For example (dimension = 3, value = 7) is the equivalent of (z = 7)
 * @author Zarimir Mitev
 * @version 3.0
 */
public class Coordinate {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension the dimension of this coordinate
	 * @param value the value of this coordinate
	 */
	private int dimension;
	private int value;
	
	// ------------------------ Constructor ------------------------
	
	/**
	 * Constructs a coordinate based on a dimension argument and a value argument.
	 * @param dimension
	 * @param value
	 */
	//@ requires dimension > 0;
	//@ requires value > 0;
	public Coordinate(int dimension, int value) {
		this.dimension = dimension;
		this.value = value;
	}
	
	public String toString() {
		return "" + this.value;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Makes a copy of this Coordinate with the same dimension and value.
	 * @return new Coordinate
	 */
	public Coordinate copy() {
		Coordinate metaCoordinate = new Coordinate(dimension, value);
		return metaCoordinate;
	}
	
	/**
	 * Gets the dimension of this Coordinate.
	 * @return this.dimension
	 */
	public int getDimension() {
		return this.dimension;
	}
	
	/**
	 * Gets the value of this Coordinate.
	 * @return this.value
	 */
	public int getValue() {
		return this.value;
	}	
	
	// ------------------------ Comparisons ------------------------
	
	/**
	 * Coordinates are equal if they have the same dimension and value.
	 * @param coordinate argument
	 * @return true if they have the same dimension and value, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Coordinate)) {
			return false;
		} else {
			Coordinate coordinate = (Coordinate) obj;
			return this.sameDimension(coordinate) && this.sameValue(coordinate);
		}
	}
	
	/**
	 * Compares the dimension with an argument Coordinate.
	 * @param coordinate argument
	 * @return true if they have the same dimension, false otherwise
	 */
	public boolean sameDimension(Coordinate coordinate) {
		if (coordinate != null && this.dimension == coordinate.getDimension()) {
			return true;
		}
		return false;
	}
	
	/**
	 * Compares the value with an argument Coordinate.
	 * @param coordinate argument
	 * @return true if they have the same value, false otherwise
	 */
	public boolean sameValue(Coordinate coordinate) {
		if (coordinate != null && this.value == coordinate.getValue()) {
			return true;
		}
		return false;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the value of this coordinate.
	 * @param value the new value of this coordinate
	 */
	public void setValue(int value) {
		this.value = value;
	}
	
	// ------------------------ Static Commands ------------------------
	
	/**
	 * Returns a copy of a list of coordinates by copying each of its coordinates.
	 * @param coordinates argument
	 * @return new Coordinate[]
	 */
	public static Coordinate[] copy(Coordinate[] coordinates) {
		Coordinate[] copies = new Coordinate[coordinates.length];
		for (int i = 0; i < copies.length; i++) {
			copies[i] = (coordinates[i]).copy();
		}
		return copies;
	}
	
	/**
	 * Converts an array of ints into an array of coordinates.
	 * @param coordinates argument
	 * @return new Coordinate[]
	 */
	public static Coordinate[] copy(int[] coordinates) {
		Coordinate[] metaCoordinates = new Coordinate[coordinates.length]; 
		for (int i = 0; i < coordinates.length; i++) {
			metaCoordinates[i] = new Coordinate(i + 1, coordinates[i]);
		}
		return metaCoordinates;
	}
}