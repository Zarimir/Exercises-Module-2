package game.geometry;

import game.logic.Mark;

/**
 * Represents a point in space.
 * A point has coordinates and a mark.
 * It is used to represent fields on the board.
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public class Point {

	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension the dimensions of the points
	 * @param coordinates the coordinates of the point
	 * @param mark the mark of the point
	 */
	//@ private invariant coordinates.length > 0;
	//@ private invariant mark != null;
	private Coordinate[] coordinates;
	private Mark mark = Mark.EMPTY;
	
	// ------------------------ Constructor ------------------------

	/**
	 * Constructor takes an array of integers as coordinates and creates a point with those coordinates.
	 * @param coordinates the coordinates of the point
	 */
	//@ requires coordinates != null;
	//@ requires coordinates.length > 0;
	public Point(Coordinate[] coordinates) {
		this.coordinates = Coordinate.copy(coordinates);
	}
	
	/**
	 * Constructs a point based on an array of ints.
	 * @param coordinates
	 */
	public Point(int[] coordinates) {
		this(Coordinate.copy(coordinates));
	}
	
	/**
	 * Constructs default point which has values -1 for each coordinate.
	 * @param dimension the dimensions of the point
	 */
	//@ requires dimension > 0;
	public Point(int dimension) {
		Coordinate[] coordinates = new Coordinate[dimension];
		for (int i = 1; i <= dimension; i++) {
			coordinates[i - 1] = new Coordinate(i, -1);
		}
		this.coordinates = coordinates;
	}
	
	/**
	 * The String of this class returns its coordinates in brackets.
	 */
	public String toString() {
		String s = "";
		s += "(";
		for (int i = 0; i < this.coordinates.length - 1; i++) {
			s += this.coordinates[i] + ", ";
		}
		s += this.coordinates[this.coordinates.length - 1];
		s += ")";
		return s;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Returns a copy of this point. It also copies this point's mark.
	 * @return new Point()
	 */
	//@ ensures \result.equals(this);
	/*@ pure */ public Point copy() {
		Coordinate[] metaCoordinates = this.coordinates.clone();
		for (int i = 0; i < metaCoordinates.length; i++) {
			metaCoordinates[i] = coordinates[i].copy();
		}
		Point point = new Point(metaCoordinates);
		point.setMark(this.mark);
		return point;
	}
	
	/**
	 * Gets the coordinate of this point which has the same dimension as the integer argument.
	 * @param dimension argument
	 * @return coordinate with this dimension or null if there aren't any
	 */
	//@ requires dimension > 0;
	/*@ pure */ public Coordinate getCoordinate(int dimension) {
		for (int i = 0; i < coordinates.length; i++) {
			if (coordinates[i].getDimension() == dimension) {
				return coordinates[i];
			}
		}
		return null;
	}
	
	/**
	 * Gets the coordinates of this point.
	 * @return this.coordinates
	 */
	//@ ensures \result != null;
	/*@ pure */ public Coordinate[] getCoordinates() {
		return this.coordinates;
	}
	
	/**
	 * Gets the Mark of the point.
	 * @return the mark of this point
	 */
	//@ ensures \result != null;
	/*@ pure */ public Mark getMark() {
		return this.mark;
	}
	
	// ------------------------ Comparisons ------------------------
	
	/**
	 * Two points are equal if they have the same coordinate dimensions and values.
	 * @param point argument
	 * @return true if equal, false otherwise
	 */
	@Override
	/*@ pure */ public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Point)) {
			return false;
		} else {
			Point point = (Point) obj;
			if (coordinates.length != point.getCoordinates().length) {
				return false;
			}
			
			Coordinate[] myCoords = this.getCoordinates();
			Coordinate[] otherCoords = point.getCoordinates();
			for (int i = 0; i < coordinates.length; i++) {
				if (!myCoords[i].equals(otherCoords[i])) {
					return false;
				}
			}
			return true;
		}
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Sets the point to belong to a player.
	 * @param ownedBy the player who marks this point
	 */
	//@ ensures this.getMark() == ownedBy;
	public void setMark(Mark ownedBy) {
		this.mark = ownedBy;
	}
	
	// ------------------------ Static Commands ------------------------
	
	/**
	 * Makes a copy of a Point[] list, by copying each of the points.
	 * @param points argument
	 * @return new Point[] with copies of points in the argument
	 */
	//@ requires points != null;
	//@ ensures points.length == \result.length;
	/*@ pure */ public static Point[] copy(Point[] points) {
		Point[] copies = new Point[points.length];
		for (int i = 0; i < points.length; i ++) {
			copies[i] = (points[i]).copy();
		}
		return copies;
	}
}