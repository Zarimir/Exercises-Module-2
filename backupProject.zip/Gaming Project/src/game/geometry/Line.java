package game.geometry;

import java.util.ArrayList;
import java.util.List;

import game.logic.Mark;

/**
 * Represents a line in space.
 * Contains points.
 * It is used to represent a winning set of fields on the board.
 * In other words, it is the model of a winning field combination.
 * @author Zarimir Mitev
 * @version 3.0
 */
public class Line {
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param points the points of this <code>Line</code>
	 */
	//@ private invariant points != null;
	private Point[] points;
	
	// ------------------------ Constructors ------------------------
	
	/**
	 * Constructs a <code>Line</code> with an argument points.
	 * @param points a list of points
	 */
	//@ requires points != null;
	public Line(Point[] points) {
		this.points = Point.copy(points);
	}
	
	/**
	 * Constructs a <code>Line</code> with an argument points.
	 * @param points an array list of points
	 */
	public Line(List<Point> points) {
		this.points = new Point[points.size()];
		for (int i = 0; i < points.size(); i++) {
			this.points[i] = points.get(i).copy();
		}
	}
	
	/**
	 * Constructs a default line with given dimension and length.
	 * @param dimension
	 * @param length
	 */
	//@ requires length > 0;
	public Line(int dimension, int length) {
		Point[] temp = new Point[length];
		for (int i = 0; i < length; i++) {
			temp[i] = new Point(dimension);
		}
		this.points = temp;
	}
	
	public String toString() {
		String s = "";
		for (int i = 0; i < this.points.length - 1; i++) {
			s += this.points[i] + ",";
		}
		s += this.points[this.points.length - 1] + ";";
		return s;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
	 * Makes a copy of this line with copy of this line's points.
	 * @return new Line()
	 */
	public Line copy() {
		List<Point> metaPoints = new ArrayList<Point>();
		for (int i = 0; i < points.length; i++) {
			metaPoints.add(points[i].copy());
		}
		return new Line(metaPoints);
	}
	
	/**
	 * Gets the points of this line.
	 * @return Point[]
	 */
	public Point[] getPoints() {
		return this.points;
	}
	
	/**
	 * Checks who owns this line.
	 * Returns null if irrelevant.
	 * Returns owner mark if it has a winner.
	 * Returns Mark.EMPTY if it is homogeneous.
	 * @return owner
	 */
	public Mark getOwner() {	
		Mark owner = Mark.EMPTY;
		Mark current;
		boolean hasWinner = true;
		
		for (int i = 0; i < this.points.length; i++) {
			current = this.points[i].getMark();
			
			// if there is one mark that is empty, hasWinner is false
			if (current == Mark.EMPTY) {
				hasWinner = false;
			
			// if this is the first found player who has a mark on this line.
			// set the owner to be equal to this player's mark.
			} else if (owner == Mark.EMPTY) {
				owner = current;
				
			// If 2 points from this line are owned by different players, return null
			} else if (current != owner) {
				return null;
			}
			
		}
		// If there is a winner return his mark
		if (hasWinner) {
			return owner;
		} else {
			// If the line is owned by only 1 player, but is not filled completely
			return Mark.EMPTY;
		}
	}
	
	// ------------------------ Comparisons ------------------------
	
	/**
	 * Two <code>Line</code> objects are equal if they are the same length
	 * and their points are equal.
	 * @param line argument
	 * @return true if equal, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Line)) {
			return false;
		} else {
			Line line = (Line) obj;
			if (points.length != line.getPoints().length) {
				return false;
			}
			
			for (int i = 0; i < points.length; i++) {
				if (!points[i].equals(line.getPoints()[i])) {
					return false;
				}
			}
			return true;
		}
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Finds the equivalent point to a target point in a line and
	 * sets it's mark to be of the same as the target point.
	 * @param target point argument
	 */
	public void setMark(Point target) {
		for (int i = 0; i < points.length; i++) {
			if (points[i].equals(target)) {
				points[i].setMark(target.getMark());
				break;
			}
		}
	}
	
	/**
	 * If <code>increasing</code> is true, sets the value of
	 * the coordinate of dimension <code>dimension</code> in every point
	 * starting from 0 ending in the length of the line - 1.
	 * If <code>increasing</code> is false, it will decrease.
	 * @param dimension specifies which coordinates
	 * @param increasing specifies whether it should increase or decrease
	 */
	public void setIteratableCoordinateAt(int dimension, boolean increasing) {
		if (increasing) {
			for (int i = 0; i < points.length; i++) {
				points[i].getCoordinate(dimension).setValue(i);
			}
		} else {
			for (int i = 0; i < points.length; i++) {
				points[i].getCoordinate(dimension).setValue(points.length - i - 1);
			}
		}
	}
	
	// ------------------------ Static Commands ------------------------
	
	/**
	 * Makes a copy of a <code>List<Line></code>.
	 * Then removes the last elements one by one, and checks for each if there is a
	 * match in the rest of the elements
	 * @param l a list of lines
	 * @return true if there is a duplicate, false otherwise
	 */
	public static boolean hasDuplicates(List<Line> l) {
		List<Line> lines = new ArrayList<Line>();
		for (int i = 0; i < l.size(); i++) {
			lines.add(l.get(i).copy());
		}
		Line holder;
		while(lines.size() > 0) {
			holder = lines.remove(lines.size() - 1);
			for (int i = 0; i < lines.size(); i++) {
				if (holder.equals(lines.get(i))) {
					return true;
				}
			}
		}
		return false;
	}
}