package game.geometry;

///////////////////////////////////////////////////////////////////////////////////////
//////////OBSERVER, CUTLINES, MVC, MULTIPLAYER
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import game.logic.Mark;

/**
 * The board of the classic tic-tac-toe is represented by a 2-dimensional square.
 * It is logical to represent a multi-dimensional tic-tac-toe with
 * a multi-dimensional square also known as a HyperCube.
 * The HyperCube has all the self-managing methods required by the Game class.
 * 
 * @author Zarimir Mitev
 * @version 3.0
 */
public class HyperCube {
	
	public static void main(String[] args) {
		HyperCube cube = new HyperCube(3,4);
		cube.initialize();
		System.out.println(cube);
	}
	
	// ------------------------ Instance Variables ------------------------
	
	/**
	 * Instance Variables.
	 * @param dimension of this cube
	 * @param length of this cube
	 * @param points of this cube
	 * @param lines of this cube
	 * @param metaPoints the current state of the points of this cube
	 * @param metaLines the current state of the lines of this cube
	 * @param winner the current state of this cube
	 */
	//@ private invariant dimension > 1;
	//@ private invariant length > 1;
	private int dimension;
	private int length;
	private List<Point> points;
	private List<Line> lines;
	
	private List<Point> metaPoints;
	private List<Line> metaLines;
	private Mark winner = null;
	
	// ------------------------ Constructors ------------------------
	
	/**
	 * Constructs a HyperCube of <code>dimension</code> and <code>length</code> parameters.
	 * @param dimension of the HyperCube
	 * @param length of the HyperCube
	 */
	//@ requires dimension > 1;
	//@ requires length > 1;
	//@ ensures this.getDimension() == dimension;
	//@ ensures this.getLength() == length;
	public HyperCube(int dimension, int length) {
		this.dimension = dimension;
		this.length = length;
	}
	
	// ------------------------ Queries ------------------------
	
	/**
     * Makes a new <code>HyperCube</code> with the dimension and length of this one.
     * Then sets the status of the metaPoints and metaLines to be the same as this one.
     * @return new HyperCube()
     */
	//@ ensures \result.equals(this);
	/*@ pure */ public HyperCube copy() {
    	HyperCube cube = new HyperCube(dimension, length);
    	cube.setStatus(this.metaPoints, this.metaLines);
        return cube;
    }
	
	/**
	 * Gets the <code>dimension</code>.
	 * @return this.dimension
	 */
	//@ ensures \result > 1;
	/*@ pure */ public int getDimension() {
		return this.dimension;
	}
	
	/**
	 * Gets the <code>length</code>.
	 * @return this.length
	 */
	//@ ensures \result > 1;
	/*@ pure */ public int getLength() {
		return this.length;
	}
	
	/**
	 * Gets the <code>points</code>.
	 * @return this.points
	 */
	/*@ pure */ public List<Point> getPoints() {
		return this.points;
	}
	
	/**
	 * Gets the <code>lines</code>.
	 * @return this.lines
	 */
	/*@ pure */ public List<Line> getLines() {
		return this.lines;
	}
	
	/**
	 * Gets the <code>metaPoints</code>.
	 * @return this.metaPoints
	 */
	/*@ pure */ public List<Point> getMetaPoints() {
		return this.metaPoints;
	}
	
	/**
	 * Gets the <code>metaLines</code>.
	 * @return this.metaLines
	 */
	/*@ pure */ public List<Line> getMetaLines() {
		return this.metaLines;
	}
	
	/**
	 * Gets the point at index from points.
	 * Returns null if index is out of range.
	 * Returns null if all points are used up on this pillar.
	 * Works correctly in 2 and 3 dimensions only.
	 * @param index
	 * @return Point() or null
	 */
	//@ requires index >= 0;
	//@ requires index < this.getLength() * this.getLength();
	/*@ pure */ public Point getPoint(int index) {
		boolean valid = 0 <= index && index < length * length;
		if (!valid) {
			return null;
		}
		
		int i = index;
		while (i < metaPoints.size() && 0 <= i && i < MyMath.pow(length, dimension)) {
			Point current = metaPoints.get(i);
			
			if (current.getMark() == Mark.EMPTY) {
				return current;
			}
			i += length * length;
		}
		return null;
	}
	
	/**
	 * Gets the point from points which is equal to the point argument.
	 * @param target argument
	 * @return Point() which is equal to the argument and is empty or null otherwise
	 */
	//@ requires target != null;
	//@ ensures \result == null || \result.equals(target);
	/*@ pure */ public Point getPoint(Point target) {
		for (int i = 0; i < metaPoints.size(); i++) {
			Point current = metaPoints.get(i);
			if (target != null &&
					target.equals(current)) {
				
				if (current.getMark() == Mark.EMPTY) {
					return current;
				} else {
					return null;
				}
			}
		}
		return null;
	}
	
	/**
	 * Gets the winner of this HyperCube.
	 * Returns null if the game is not over.
	 * Returns Mark.EMPTY if there is a draw.
	 * Returns the mark of the winner if a player wins.
	 * @return null if the game is not over, or Mark if it's over
	 */
	/*@ pure */ public Mark getWinner() {
		return this.winner;
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Two HyperCubes are equal if they have the same dimension and length and
	 * their current metaPoins and metaLines are equal.
	 * @param cube argument
	 * @return true if equal, false otherwise
	 */
	@Override
	/*@ pure */ public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof HyperCube)) {
			return false;
		} else {
			HyperCube cube = (HyperCube) obj;
			if (this.getDimension() != cube.getDimension() ||
					this.getLength() != cube.getLength()) {
				return false;
			}
			Point myPoint;
			Point otherPoint;
			for (int i = 0; i < metaPoints.size(); i++) {
				myPoint = metaPoints.get(i);
				otherPoint = cube.getMetaPoints().get(i);
				if (!myPoint.equals(otherPoint) || myPoint.getMark() != otherPoint.getMark()) {
					return false;
				}
			}
			Line myLine;
			Line otherLine;
			for (int i = 0; i < metaLines.size(); i++) {
				myLine = metaLines.get(i);
				otherLine = cube.getMetaLines().get(i);
				if (!myLine.equals(otherLine) || myLine.getOwner() != otherLine.getOwner()) {
					return false;
				}
			}
			return true;
		}
	}
	
	// ------------------------ Commands ------------------------
	
	/**
	 * Initializes the list of points and lines of this HyperCube.
	 * After it has been initialized, the same method can be used to reset it.
	 * Sets the winner to null;
	 */
	//@ ensures this.getMetaPoints().size() == this.getPoints().size();
	//@ ensures this.getMetaLines().size() == this.getLines().size();
	//@ ensures this.getWinner() == null;
	public void initialize() {
		if (this.points == null || this.lines == null) {
			Matrix matrix = new Matrix(this);
			matrix.extract();
			this.points = matrix.getPoints();
			this.lines = matrix.getLines();
		}
		setStatus(this.points, this.lines);
		this.winner = null;
	}
	
	/**
	 * Sets the current status of the HyperCube, which is
	 * the metaPoints with all their marks and the metaLines with all their lines and marks
	 * @param points
	 * @param lines
	 */
	//@ requires points != null;
	//@ requires lines != null;
	//@ ensures this.getMetaPoints().size() == points.size();
	//@ ensures this.getMetaLines().size() == lines.size();
	public void setStatus(List<Point> points, List<Line> lines) {
		this.metaPoints = HyperCube.copyPoints(points);
		this.metaLines = HyperCube.copyLines(lines);
	}
	
	/**
	 * Marks a point from the points list and updates all the lines.
	 * @param target
	 * @param player
	 */
	//@ requires target != null;
	//@ requires player != null;
	//@ ensures this.getPoint(target).getMark() == player;
	public void mark(Point target, Mark player) {
		if (target != null && player != null && target.getMark() == Mark.EMPTY && player != Mark.EMPTY) {
			target.setMark(player);
			updateLines(target);
		}
	}
	
	/**
     * Updates the lines.
     * If the current line contains the same point, sets the mark to be of the player who marked it.
     * Sets the winner if the game is over. Removes irrelevant lines.
     * The game is over if there is a winner or there aren't any relevant lines left.
     * @param move the current move
     */
	//@ requires choice != null;
    public void updateLines(Point choice) {
		Line line;
		Mark mark;
		for (Iterator<Line> it = this.metaLines.iterator(); it.hasNext();) {
			line = it.next();
			line.setMark(choice);
			mark = line.getOwner();
			if (mark == null) {
				it.remove();
			} else if (mark != Mark.EMPTY) {
				winner = mark;
				break;
			}
		}
		if (metaLines.size() == 0) {
			winner = Mark.EMPTY;
		}
	}
    
	// ------------------------ Static Commands ------------------------
    
	/**
	 * Makes a copy of an ArrayList of points, by copying each point separately.
	 * @param points argument
	 * @return new ArrayList<Point> containing all points of <code>points</code>
	 */
    //@ requires points != null;
    //@ ensures \result.size() == points.size();
    /*@ pure */ public static List<Point> copyPoints(List<Point> points) {
		List<Point> result = new ArrayList<Point>();
		if (points != null) {
			for (int i = 0; i < points.size(); i++) {
				result.add(points.get(i).copy());
			}
		}
		return result;
	}
	
	/**
	 * Makes a copy of an ArrayList of lines, by copying each line separately.
	 * @param lines argument
	 * @return new ArrayList<Line> containing all lines of <code>lines</code>
	 */
    //@ requires lines != null;
    //@ ensures \result.size() == lines.size();
    /*@ pure */ public static List<Line> copyLines(List<Line> lines) {
		List<Line> result = new ArrayList<Line>();
		if (lines != null) {
			for (int i = 0; i < lines.size(); i++) {
				result.add(lines.get(i).copy());
			}
		}
		return result;
	}
    
    public String rowToString(int index) {
    	String row = "";
    	for (int i = index; i < index + length; i++) {
    		row += "|" + metaPoints.get(i).getMark();
    	}
    	return row + "|\n";
    }
    
    public String squareToString(int index) {
    	String square = "";
    	for (int i = index; i < index + length; i++) {
    		square += rowToString(i);
    	}
    	for (int i = 0; i < length; i ++) {
    		square += "-------";
    	}
    	return square + "\n";
    }
    
    public String toString() {
    	String cube = "";
    	int squareIndex = metaPoints.size() / (length * length);
    	for (int i = 0; i < squareIndex; i++) {
    		cube += squareToString(i);
    	}
    	return cube;
    }
}